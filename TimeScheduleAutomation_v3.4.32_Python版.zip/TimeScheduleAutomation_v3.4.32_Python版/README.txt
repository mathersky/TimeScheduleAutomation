TimeScheduleAutomation v3.4.32｜Python 版

功能：依使用者授權的 PHIS 作業流程，自動登入 PHIS、查詢健保卡日上傳資料並執行上傳；支援多個每日時段與各時段獨立設定星期，並記錄每次執行結果。

安裝：解壓縮整個資料夾後，雙擊「安裝軟體.cmd」。程式會安裝至目前 Windows 使用者的 LocalAppData\Programs，並建立桌面捷徑。為保留原 PHIS AutoUploader 使用者設定與排程識別，安裝目錄及設定目錄仍沿用舊路徑。
首次啟動：需要 Windows 10/11、Python 3.12 以上版本、Chrome、PHIS 與 PhisSocket。首次啟動會建立專用虛擬環境並從 PyPI 安裝必要套件，因此首次安裝與缺少套件時需要網路。
排程：每個時段可分別設定週一至週日；選取時段後修改其星期，按「同步排程」建立 Windows 工作排程。排程只在此使用者登入且桌面可互動時執行。
記錄：「LOG」保存詳細流程記錄；「每日執行紀錄」記錄手動及排程流程的時間、狀態與耗時，不記錄病患資料。
移除：先關閉程式，再雙擊「移除軟體.cmd」。使用者設定與記錄會保留。

更新及發布：更新清單位於本 GitHub Repository 的 updates/manifest.json。開發者可使用「GitHub發布主控台.pyw」發布 ZIP 與 SHA-256，並更新清單。發布主控台需安裝 GitHub CLI，並先執行 gh auth login。

注意：本程式只應在具有 PHIS 帳號、資料及自動化操作適當授權的環境使用。請先確認機構規範及每次執行結果。
