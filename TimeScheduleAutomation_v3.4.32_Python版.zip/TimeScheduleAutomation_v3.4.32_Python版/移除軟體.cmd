@echo off
setlocal EnableExtensions
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0SetupFiles\uninstall.ps1"
if errorlevel 1 goto failed
echo.
echo Removal completed. User settings and LOG files were kept.
pause
exit /b 0
:failed
echo Removal failed. Review the error above.
pause
exit /b 1
