﻿$ErrorActionPreference = 'Stop'
$source = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\Application'))
$target = Join-Path $env:LOCALAPPDATA 'Programs\PHIS_AutoUploader'
if (-not (Test-Path -LiteralPath (Join-Path $source 'phis_auto.py'))) {
    throw "找不到 Application\phis_auto.py，請重新解壓完整安裝包。"
}
New-Item -ItemType Directory -Path $target -Force | Out-Null
Write-Host "TimeScheduleAutomation 安裝程式至：$target"
& robocopy.exe $source $target /E /IS /IT /R:2 /W:1
$copyCode = $LASTEXITCODE
if ($copyCode -ge 8) { throw "複製程式失敗，robocopy code=$copyCode" }
& (Join-Path $PSScriptRoot 'create_shortcuts.ps1') -InstallDir $target
Write-Host '安裝完成，桌面及程式資料夾捷徑已建立。'
Write-Host '首次啟動需要 Python 3.12 以上版本；套件安裝需要網路。'
$launcher = '"' + (Join-Path $target 'setup_and_run.bat') + '"'
Start-Process -FilePath $env:ComSpec -ArgumentList @('/c', $launcher) -WorkingDirectory $target
