﻿$ErrorActionPreference = 'Stop'
$installDir = Join-Path $env:LOCALAPPDATA 'Programs\PHIS_AutoUploader'
$dataDir = Join-Path $env:LOCALAPPDATA 'PHIS_AutoUploader\UserData'
$running = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
  $_.CommandLine -and $_.CommandLine.Contains((Join-Path $installDir 'phis_auto.py'))
}
if ($running) { Write-Error '請先關閉 TimeScheduleAutomation及其排程執行視窗，再重新移除。'; exit 1 }
Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object { $_.TaskName -like 'PHIS_AutoUploader_*' } | ForEach-Object {
  Unregister-ScheduledTask -TaskName $_.TaskName -TaskPath $_.TaskPath -Confirm:$false -ErrorAction SilentlyContinue
}
$desktopShortcut = Join-Path ([Environment]::GetFolderPath('Desktop')) 'TimeScheduleAutomation.lnk'
Remove-Item -LiteralPath $desktopShortcut -Force -ErrorAction SilentlyContinue
$oldDesktopShortcut = Join-Path ([Environment]::GetFolderPath('Desktop')) 'PHIS 自動日上傳工具.lnk'
Remove-Item -LiteralPath $oldDesktopShortcut -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath (Join-Path $installDir 'TimeScheduleAutomation.lnk') -Force -ErrorAction SilentlyContinue
if (Test-Path -LiteralPath $installDir) { Remove-Item -LiteralPath $installDir -Recurse -Force }
Write-Host 'TimeScheduleAutomation、捷徑及本工具排程已移除；設定與 LOG 已保留。'
