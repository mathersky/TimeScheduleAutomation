﻿param([Parameter(Mandatory=$true)][string]$InstallDir)
$ErrorActionPreference = 'Stop'
$target = Join-Path $InstallDir 'run_app.bat'
if (-not (Test-Path -LiteralPath $target)) { throw "找不到啟動程式：$target" }
$shell = New-Object -ComObject WScript.Shell
$locations = @(
  (Join-Path ([Environment]::GetFolderPath('Desktop')) 'TimeScheduleAutomation.lnk'),
  (Join-Path $InstallDir 'TimeScheduleAutomation.lnk')
)
$oldShortcut = Join-Path ([Environment]::GetFolderPath('Desktop')) 'PHIS 自動日上傳工具.lnk'
Remove-Item -LiteralPath $oldShortcut -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath (Join-Path $InstallDir 'PHIS 自動日上傳工具.lnk') -Force -ErrorAction SilentlyContinue
foreach ($path in $locations) {
  $shortcut = $shell.CreateShortcut($path)
  $shortcut.TargetPath = $target
  $shortcut.WorkingDirectory = $InstallDir
  $shortcut.Description = 'TimeScheduleAutomation'
  $shortcut.WindowStyle = 7
  $shortcut.Save()
}
