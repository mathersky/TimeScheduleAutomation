@echo off
setlocal EnableExtensions
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0SetupFiles\install.ps1"
if errorlevel 1 goto failed
echo.
echo Installation complete. The application startup is running in a separate window.
pause
exit /b 0
:failed
echo Installation failed. Review the error above.
pause
exit /b 1
