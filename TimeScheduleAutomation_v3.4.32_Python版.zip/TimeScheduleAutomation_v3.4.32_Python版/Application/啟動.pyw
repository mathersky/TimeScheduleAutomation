# -*- coding: utf-8 -*-
"""Silent Python launcher: creates the venv, installs dependencies and starts GUI without a console."""
from __future__ import annotations
import os
from pathlib import Path
import queue
import shutil
import subprocess
import sys
import threading
import tkinter as tk
from tkinter import ttk, messagebox

BASE = Path(__file__).resolve().parent
VENV = BASE / ".venv"
VENV_PY = VENV / "Scripts" / "python.exe"
VENV_PYW = VENV / "Scripts" / "pythonw.exe"
LOG_DIR = BASE / "logs"
LOG_DIR.mkdir(exist_ok=True)
SETUP_LOG = LOG_DIR / "startup.log"
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def record(text: str) -> None:
    with SETUP_LOG.open("a", encoding="utf-8") as f:
        f.write(text.rstrip() + "\n")


def quiet_run(command, timeout=360):
    try:
        result = subprocess.run(
            command, cwd=BASE, capture_output=True, text=True,
            encoding="utf-8", errors="replace", timeout=timeout,
            creationflags=NO_WINDOW,
        )
        if result.stdout:
            record(result.stdout)
        if result.stderr:
            record(result.stderr)
        return result
    except Exception as exc:
        record(f"執行失敗：{command!r}；{exc}")
        raise


def find_base_python() -> str:
    launcher = shutil.which("py")
    if launcher:
        for version in ("3.14", "3.13", "3.12"):
            try:
                result = quiet_run([launcher, f"-{version}", "-c", "import sys;print(sys.executable)"], timeout=12)
                if result.returncode == 0 and result.stdout.strip():
                    return result.stdout.strip().splitlines()[-1].strip()
            except Exception:
                continue
    candidate = Path(sys.executable).with_name("python.exe")
    if candidate.is_file():
        return str(candidate)
    found = shutil.which("python")
    if found:
        return found
    raise RuntimeError("找不到 Python 3.12–3.14。請安裝 Python 後再執行「啟動.pyw」。")


def ensure_environment(set_status):
    if not VENV_PY.is_file():
        set_status("首次啟動：建立 Python 環境…")
        base_python = find_base_python()
        result = quiet_run([base_python, "-m", "venv", str(VENV)], timeout=180)
        if result.returncode != 0:
            raise RuntimeError("建立 Python 環境失敗。詳情請查看 logs\\startup.log。")

    check = quiet_run([
        str(VENV_PY), "-c",
        "import pywinauto, pyautogui, pyperclip, PIL, win32api, pystray",
    ], timeout=30)
    if check.returncode == 0:
        return

    set_status("正在自動安裝缺少的套件…")
    quiet_run([str(VENV_PY), "-m", "ensurepip", "--upgrade"], timeout=120)
    install = quiet_run([
        str(VENV_PY), "-m", "pip", "install", "--disable-pip-version-check",
        "--prefer-binary", "--timeout", "20", "--retries", "2",
        "-r", str(BASE / "requirements.txt"),
    ], timeout=420)
    if install.returncode != 0:
        raise RuntimeError("套件安裝失敗。請確認網路後重試；詳情請查看 logs\\startup.log。")
    verify = quiet_run([
        str(VENV_PY), "-c",
        "import pywinauto, pyautogui, pyperclip, PIL, win32api, pystray",
    ], timeout=30)
    if verify.returncode != 0:
        raise RuntimeError("套件安裝後仍無法載入。請查看 logs\\startup.log。")


def main():
    root = tk.Tk()
    root.title("TimeScheduleAutomation")
    root.geometry("440x150")
    root.resizable(False, False)
    root.configure(bg="#F2F5FA")
    try:
        root.eval("tk::PlaceWindow . center")
    except tk.TclError:
        pass
    label = tk.Label(root, text="準備啟動…", font=("Microsoft JhengHei UI", 12, "bold"),
                     bg="#F2F5FA", fg="#173B68", padx=20, pady=16)
    label.pack(fill="x")
    bar = ttk.Progressbar(root, mode="indeterminate")
    bar.pack(fill="x", padx=24, pady=(0, 18))
    bar.start(10)
    updates = queue.Queue()

    def set_status(text):
        updates.put(("status", text))

    def worker():
        try:
            ensure_environment(set_status)
            if not VENV_PYW.is_file():
                raise RuntimeError("找不到虛擬環境的 pythonw.exe。")
            target = BASE / "phis_auto.py"
            if not target.is_file():
                raise RuntimeError("找不到 phis_auto.py。請重新解壓完整程式包。")
            subprocess.Popen(
                [str(VENV_PYW), str(target)], cwd=BASE,
                creationflags=NO_WINDOW, close_fds=True,
            )
            updates.put(("done", None))
        except Exception as exc:
            record(f"啟動錯誤：{exc}")
            updates.put(("error", str(exc)))

    threading.Thread(target=worker, daemon=True).start()

    def poll():
        try:
            while True:
                kind, payload = updates.get_nowait()
                if kind == "status":
                    label.configure(text=payload)
                elif kind == "done":
                    root.destroy()
                    return
                elif kind == "error":
                    bar.stop()
                    messagebox.showerror("啟動失敗", f"{payload}\n\n記錄：logs\\startup.log")
                    root.destroy()
                    return
        except queue.Empty:
            pass
        root.after(100, poll)

    root.after(100, poll)
    root.mainloop()


if __name__ == "__main__":
    main()
