# -*- coding: utf-8 -*-
"""
PHIS 自動日上傳工具
- 依照使用者提供的操作影片建立
- Chrome：使用本機 DevTools/DOM 直接填寫並送出 PHIS 登入表單，不使用登入座標；登入成功後不再點四層網頁功能選單
- 官方啟動鏈：登入成功後，透過本機 PhisSocket WebSocket (127.0.0.1:7788/CIP) 送出與 PHIS 網頁相同格式的 GetMessage，交由 InetLoader 啟動健保卡日上傳2.0
- 原生程式「IC卡資料上傳作業(2.0)」：直接取得 VCL Form/TAction 物件並送 CM_ACTIONEXECUTE，執行查詢 / 全選 / 一鍵上傳 / 結束，不使用滑鼠座標
- Server Error：透過 Chrome DevTools 重新導向 PHIS 首頁，再由 DOM 正常登入
- 支援每日多時段 Windows 工作排程器

注意：此工具僅在 Windows 10/11 + Chrome 上使用。
"""
from __future__ import annotations

import argparse
import base64
import csv
import hashlib
import ctypes
from ctypes import wintypes
import json
import os
from pathlib import Path
import re
import queue
import shutil
import socket
import struct
import subprocess
import sys
import threading
import time
import traceback
from datetime import datetime
from typing import Iterable, Optional, Sequence
from urllib.parse import urlparse
from urllib.request import Request, urlopen

# Python-only edition: keep settings and logs beside the source project.
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("LOCALAPPDATA", str(BASE_DIR))) / "PHIS_AutoUploader" / "UserData"
DATA_DIR.mkdir(parents=True, exist_ok=True)
CONFIG_FILE = DATA_DIR / "settings.json"
LOG_DIR = DATA_DIR / "logs"
LOG_DIR.mkdir(exist_ok=True)
DAILY_RUN_LOG = LOG_DIR / "daily_runs.log"
LEGACY_CONFIG_FILE = BASE_DIR / "settings.json"
if not CONFIG_FILE.exists() and LEGACY_CONFIG_FILE.is_file():
    try:
        shutil.copy2(LEGACY_CONFIG_FILE, CONFIG_FILE)
    except OSError:
        pass

DEFAULT_URL = "http://192.168.1.2/phis2000/"
APP_NAME = "TimeScheduleAutomation"
TASK_PREFIX = "PHIS_AutoUploader_"
APP_VERSION = "3.4.32-Python"
UPDATE_MANIFEST_URL = (
    "https://raw.githubusercontent.com/mathersky/TimeScheduleAutomation/"
    "main/updates/manifest.json"
)

# v3.2.10 效率加速：
# 只縮短固定空等；Server Error / 查詢資料 / 全選 / 上傳結果仍採狀態判斷。
# PHIS 正常登入已由 DOM 確認；保留 0.5 秒 Launcher 緩衝。
ACTION_DELAY_SECONDS = 0.50
POST_LOGIN_LAUNCH_DELAY = 0.5
LOGIN_STATE_POLL_SECONDS = 0.06
SERVER_ERROR_FAST_POLL_SECONDS = 0.08
SERVER_ERROR_RECOVERY_WINDOW_SECONDS = 0.45
SERVER_ERROR_RELOAD_GAP_SECONDS = 0.03

# 依使用者提供之環境：1920x1080、Windows 縮放 125%。
REFERENCE_W = 1920
REFERENCE_H = 1080
FALLBACK_POINTS = {
    # Chrome 登入頁（僅在 UIA 無法辨識欄位時使用）
    "login_user": (342, 402),
    "login_pass": (342, 436),
    "login_submit": (285, 503),
    # PHIS 功能頁層級選單（依使用者提供 1920x1080 / 125% 操作影片量測）。
    # 平常仍優先用畫面文字關鍵字尋找；只有舊式網頁未暴露 UIA 目標時才使用。
    "menu_outpatient": (170, 338),
    "menu_registration": (205, 372),
    "menu_ic_registration": (310, 611),
    "menu_daily_upload": (390, 762),
    # IC卡資料上傳作業(2.0) 上方工具列（原生程式）
    # Q查詢：實際啟動區是最左上角的放大鏡圖示，不是下方文字。
    # v2.1.3 保留 v2.1 的快速登入流程；原生上傳程式則直接對工具列圖示送 Windows 系統訊息。
    # 這些座標是工具列「圖示中心」而非文字區。
    "native_query": (31, 39),
    "native_select_all": (180, 39),
    "native_one_click": (310, 39),
    "native_exit": (392, 39),
}

# IC卡資料上傳作業(2.0) 的畫面偵測區域（1920x1080 參考座標）。
# v3.2.2 同時支援目前實機版面與較舊版面。只做記憶體內畫面判定，
# 不保存、不輸出病患資料畫面。
NATIVE_DATA_ROW_ROIS = (
    (90, 238, 1740, 270),    # 目前實機版面：第一筆資料列約 y=240~260
    (100, 345, 1740, 380),   # 舊版面備援
)
NATIVE_GRID_ROIS = (
    (90, 238, 1740, 760),    # 目前實機版面
    (100, 345, 1740, 760),   # 舊版面
)
NATIVE_FIRST_CHECKBOX_ROIS = (
    (55, 238, 85, 268),      # 目前實機版面第一筆「選取」框
    (78, 349, 98, 369),      # 舊版面備援
)
NATIVE_SELECTION_COLUMN_ROIS = (
    (42, 238, 88, 760),      # 目前實機版面：整個「選取」欄
    (68, 345, 102, 760),     # 舊版面備援
)
NATIVE_BUSY_ROIS = (
    (700, 420, 1200, 560),   # 目前實機版面
    (780, 500, 1140, 575),   # 舊版面
)


def now_text() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def normalize_text(s: str) -> str:
    s = (s or "").strip().lower()
    s = s.replace("臺", "台")
    s = re.sub(r"[\s\u3000\-_:：．。\.、()（）【】\[\]]+", "", s)
    return s


def version_tuple(value: str):
    parts = re.findall(r"\d+", str(value or ""))
    return tuple(int(x) for x in parts) or (0,)


def fetch_update_manifest(timeout=8):
    request = Request(
        UPDATE_MANIFEST_URL,
        headers={"User-Agent": f"TimeScheduleAutomation/{APP_VERSION}", "Accept": "application/json"},
    )
    with urlopen(request, timeout=timeout) as response:
        raw = response.read(256 * 1024 + 1)
    if len(raw) > 256 * 1024:
        raise RuntimeError("更新資訊檔案過大。")
    manifest = json.loads(raw.decode("utf-8-sig"))
    if manifest.get("product") != "TimeScheduleAutomation" or manifest.get("channel") != "stable":
        raise RuntimeError("更新來源或產品識別不符。")
    return manifest


def download_update_package(manifest, logger):
    url = str(manifest.get("download_url") or "")
    parsed = urlparse(url)
    if parsed.scheme != "https" or not (
        parsed.hostname == "raw.githubusercontent.com"
        or (parsed.hostname == "github.com" and "/releases/download/" in parsed.path)
    ):
        raise RuntimeError("更新檔網址不在允許的 GitHub HTTPS 網域。")
    expected = str(manifest.get("sha256") or "").lower()
    if not re.fullmatch(r"[0-9a-f]{64}", expected):
        raise RuntimeError("更新資訊缺少有效的 SHA-256。")
    request = Request(url, headers={"User-Agent": f"TimeScheduleAutomation/{APP_VERSION}"})
    with urlopen(request, timeout=30) as response:
        data = response.read(100 * 1024 * 1024 + 1)
    if not data or len(data) > 100 * 1024 * 1024:
        raise RuntimeError("更新 ZIP 為空或超過 100 MB。")
    actual = hashlib.sha256(data).hexdigest()
    if actual != expected:
        raise RuntimeError("更新檔 SHA-256 驗證失敗，已停止安裝。")
    safe_name = Path(str(manifest.get("asset") or "update.zip")).name
    if not safe_name.lower().endswith(".zip"):
        raise RuntimeError("更新檔格式不是 ZIP。")
    staged = Path(os.environ.get("TEMP", str(BASE_DIR))) / f"phis_uploader_update_{safe_name}"
    staged.write_bytes(data)
    logger.write(f"更新檔已下載並通過 SHA-256 驗證：{safe_name}")
    return staged


class Logger:
    def __init__(self, callback=None):
        self.callback = callback
        self.path = LOG_DIR / f"run_{datetime.now():%Y%m%d}.log"
        self.lock = threading.Lock()

    def write(self, msg: str):
        line = f"[{now_text()}] {msg}"
        with self.lock:
            with self.path.open("a", encoding="utf-8") as f:
                f.write(line + "\n")
        if self.callback:
            try:
                self.callback(line)
            except Exception:
                pass


class DailyRunRecorder:
    """Short, patient-free outcome history for scheduled invocations."""
    def write(self, started_at, status, elapsed_seconds, detail=""):
        duration = max(0, int(elapsed_seconds))
        hours, remainder = divmod(duration, 3600)
        minutes, seconds = divmod(remainder, 60)
        line = (
            f"[{started_at:%Y-%m-%d %H:%M:%S}] {status}"
            f"｜耗時 {hours:02d}:{minutes:02d}:{seconds:02d}"
        )
        if detail:
            line += f"｜{detail}"
        with DAILY_RUN_LOG.open("a", encoding="utf-8") as stream:
            stream.write(line + "\n")


# ----------------------- Windows DPAPI -----------------------
class DATA_BLOB(ctypes.Structure):
    _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]


def _blob_from_bytes(data: bytes):
    buf = ctypes.create_string_buffer(data)
    blob = DATA_BLOB(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_byte)))
    return blob, buf


def dpapi_encrypt(text: str) -> str:
    if not text:
        return ""
    raw = text.encode("utf-8")
    if os.name != "nt":
        return "plain:" + base64.b64encode(raw).decode("ascii")
    in_blob, in_buf = _blob_from_bytes(raw)
    out_blob = DATA_BLOB()
    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    CRYPTPROTECT_UI_FORBIDDEN = 0x01
    ok = crypt32.CryptProtectData(
        ctypes.byref(in_blob),
        APP_NAME,
        None,
        None,
        None,
        CRYPTPROTECT_UI_FORBIDDEN,
        ctypes.byref(out_blob),
    )
    if not ok:
        raise ctypes.WinError()
    try:
        encrypted = ctypes.string_at(out_blob.pbData, out_blob.cbData)
        return "dpapi:" + base64.b64encode(encrypted).decode("ascii")
    finally:
        kernel32.LocalFree(out_blob.pbData)


def dpapi_decrypt(value: str) -> str:
    if not value:
        return ""
    if value.startswith("plain:"):
        return base64.b64decode(value[6:]).decode("utf-8")
    if not value.startswith("dpapi:"):
        return ""
    if os.name != "nt":
        return ""
    encrypted = base64.b64decode(value[6:])
    in_blob, in_buf = _blob_from_bytes(encrypted)
    out_blob = DATA_BLOB()
    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    CRYPTPROTECT_UI_FORBIDDEN = 0x01
    ok = crypt32.CryptUnprotectData(
        ctypes.byref(in_blob),
        None,
        None,
        None,
        None,
        CRYPTPROTECT_UI_FORBIDDEN,
        ctypes.byref(out_blob),
    )
    if not ok:
        return ""
    try:
        raw = ctypes.string_at(out_blob.pbData, out_blob.cbData)
        return raw.decode("utf-8")
    finally:
        kernel32.LocalFree(out_blob.pbData)


class Settings:
    def __init__(self):
        self.url = DEFAULT_URL
        self.username = ""
        self.password = ""
        self.display_name = ""
        self.permission_level = "5"
        self.times: list[str] = []
        # Per-time weekdays. Legacy `weekdays` is retained as the union for
        # compatibility with older settings and older application versions.
        self.schedule_days: dict[str, list[str]] = {}
        self.weekdays: list[str] = ["MON", "TUE", "WED", "THU", "FRI"]
        self.run_as_admin = True
        self.server_retry_seconds = 2.0
        self.native_wait_seconds = 90
        self.auto_close_native = True
        self.load()

    def load(self):
        if not CONFIG_FILE.exists():
            return
        try:
            data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
            self.url = data.get("url", DEFAULT_URL)
            self.username = data.get("username", "")
            self.password = dpapi_decrypt(data.get("password", ""))
            self.display_name = data.get("display_name", "")
            self.permission_level = str(data.get("permission_level", "5") or "5")
            self.times = sorted(set(data.get("times", [])))
            day_order = ("MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN")
            saved_days = data.get("weekdays", ["MON", "TUE", "WED", "THU", "FRI"])
            legacy_days = [day for day in day_order if day in saved_days]
            raw_schedule_days = data.get("schedule_days")
            if isinstance(raw_schedule_days, dict):
                self.schedule_days = {
                    t: [day for day in day_order if day in raw_schedule_days.get(t, [])]
                    for t in self.times
                }
            else:
                # Existing installations had one weekday set shared by all times.
                self.schedule_days = {t: list(legacy_days) for t in self.times}
            self.weekdays = [
                day for day in day_order
                if any(day in self.schedule_days.get(t, []) for t in self.times)
            ] or legacy_days
            self.run_as_admin = bool(data.get("run_as_admin", True))
            self.server_retry_seconds = float(data.get("server_retry_seconds", 2.0))
            self.native_wait_seconds = int(data.get("native_wait_seconds", 90))
            # v2.0 完整循環定義固定包含「X結束」關閉上傳程式。
            self.auto_close_native = True
        except Exception:
            pass

    def save(self):
        data = {
            "url": self.url,
            "username": self.username,
            "password": dpapi_encrypt(self.password),
            "display_name": self.display_name,
            "permission_level": self.permission_level,
            "times": sorted(set(self.times)),
            "schedule_days": {
                t: list(self.schedule_days.get(t, self.weekdays))
                for t in sorted(set(self.times))
            },
            # Keep the old shared field as the union for safe downgrade behavior.
            "weekdays": [
                day for day in ("MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN")
                if any(day in self.schedule_days.get(t, self.weekdays) for t in self.times)
            ] or list(self.weekdays),
            "run_as_admin": self.run_as_admin,
            "server_retry_seconds": self.server_retry_seconds,
            "native_wait_seconds": self.native_wait_seconds,
            "auto_close_native": self.auto_close_native,
        }
        # Replace atomically so an interrupted write cannot leave a truncated
        # settings.json and lose credentials or schedule configuration.
        temp_file = CONFIG_FILE.with_suffix(CONFIG_FILE.suffix + ".tmp")
        temp_file.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(temp_file, CONFIG_FILE)



# ----------------------- Dependency self-repair -----------------------
def ensure_runtime_dependencies(logger=None):
    """Ensure automation packages are available and show installation progress.

    v1.2 installed missing packages with stdout/stderr captured until pip exited,
    which made the GUI look frozen at "正在自動修復".  v1.3 streams pip output into
    the execution log, uses short network timeouts, verifies imports afterwards,
    and gives a clear recovery command if the office network blocks PyPI.
    """
    import importlib

    modules = {
        "pywinauto": "pywinauto==0.6.9",
        "pyautogui": "pyautogui==0.9.54",
        "pyperclip": "pyperclip==1.9.0",
        "PIL": "Pillow>=10.0",
        "win32api": "pywin32>=306",
        "pystray": "pystray>=0.19",
    }

    def get_missing():
        out = []
        for mod, pkg in modules.items():
            try:
                importlib.import_module(mod)
            except Exception:
                out.append((mod, pkg))
        return out

    missing = get_missing()
    if not missing:
        return

    pkgs = [pkg for _, pkg in missing]
    if logger:
        logger.write("偵測到自動化元件缺少：" + ", ".join(pkgs))
        logger.write("開始自動安裝；安裝進度會直接顯示在這裡，請勿關閉程式。")

    # Make sure pip exists in older / partially-created venvs.
    try:
        subprocess.run(
            [sys.executable, "-m", "pip", "--version"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            timeout=15, check=True,
        )
    except Exception:
        if logger:
            logger.write("pip 不完整，先修復 pip…")
        cp = subprocess.run(
            [sys.executable, "-m", "ensurepip", "--upgrade"],
            capture_output=True, text=True, encoding="utf-8", errors="ignore",
            timeout=120,
        )
        if cp.returncode != 0:
            raise RuntimeError("目前 Python 環境的 pip 無法修復。請執行「完全修復環境.bat」。")

    cmd = [
        sys.executable, "-m", "pip", "install",
        "--disable-pip-version-check",
        "--prefer-binary",
        "--timeout", "20",
        "--retries", "2",
        *pkgs,
    ]

    try:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="ignore",
            bufsize=1,
        )
        if proc.stdout is not None:
            for raw in iter(proc.stdout.readline, ""):
                line = raw.strip()
                if line and logger:
                    logger.write("[安裝] " + line)
        rc = proc.wait(timeout=360)
    except subprocess.TimeoutExpired:
        try:
            proc.kill()
        except Exception:
            pass
        raise RuntimeError(
            "自動安裝超過 6 分鐘仍未完成。可能是網路或 PyPI 被阻擋。"
            "請關閉程式後執行「完全修復環境.bat」。"
        )
    except Exception as e:
        raise RuntimeError(f"自動安裝自動化元件失敗：{e}")

    if rc != 0:
        raise RuntimeError(
            "自動化元件安裝失敗。請關閉程式後執行「完全修復環境.bat」。"
            "若修復視窗仍失敗，請把最後 20 行訊息截圖給我。"
        )

    importlib.invalidate_caches()
    still_missing = get_missing()
    if still_missing:
        names = "；".join(f"{m} ({p})" for m, p in still_missing)
        raise RuntimeError(
            "套件已安裝，但目前 Python 仍無法載入：" + names +
            "。請關閉程式後重新開啟；若仍相同，執行「完全修復環境.bat」。"
        )

    if logger:
        logger.write("自動化元件安裝完成，繼續執行 PHIS 流程。")

def press_key(key: str):
    import pyautogui
    pyautogui.press(key)


def hotkey(*keys: str):
    import pyautogui
    pyautogui.hotkey(*keys)

# ----------------------- Windows helpers -----------------------
def require_windows():
    if os.name != "nt":
        raise RuntimeError("此工具只能在 Windows 10/11 執行。")


def hide_console_window():
    """Hide the launcher console; the GUI and its system-tray icon remain usable."""
    if os.name != "nt":
        return
    try:
        hwnd = ctypes.windll.kernel32.GetConsoleWindow()
        if hwnd:
            ctypes.windll.user32.ShowWindow(hwnd, 0)  # SW_HIDE
    except Exception:
        pass


def set_dpi_aware():
    if os.name != "nt":
        return
    try:
        # Per-monitor DPI aware，讓 pyautogui 使用實際 1920x1080 像素座標。
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


def initialize_com_for_thread(logger=None):
    """Initialize COM on the *current* thread.

    pywinauto's UIA backend depends on COM.  The GUI intentionally runs the
    workflow on a background thread so Tkinter stays responsive; COM must be
    initialized separately on that worker thread or Desktop(backend="uia")
    can fail to enumerate any windows.
    """
    if os.name != "nt":
        return None
    try:
        import pythoncom
        pythoncom.CoInitialize()
        if logger:
            logger.write("已初始化 Windows UI Automation (COM)。")
        return ("pythoncom", pythoncom)
    except Exception as e:
        # pywin32 normally comes with pywinauto.  Keep a ctypes fallback so a
        # partially installed environment still has a chance to work.
        try:
            COINIT_APARTMENTTHREADED = 0x2
            hr = ctypes.windll.ole32.CoInitializeEx(None, COINIT_APARTMENTTHREADED)
            # S_OK(0), S_FALSE(1), RPC_E_CHANGED_MODE(0x80010106) are all
            # acceptable here: the last means COM was already initialized in
            # another apartment model on this thread.
            if hr in (0, 1) or (hr & 0xFFFFFFFF) == 0x80010106:
                if logger:
                    logger.write("已初始化 Windows UI Automation (COM/ctypes)。")
                return ("ctypes", hr in (0, 1))
        except Exception:
            pass
        if logger:
            logger.write(f"警告：COM 初始化未確認成功：{e}")
        return None


def uninitialize_com_for_thread(token):
    if not token or os.name != "nt":
        return
    try:
        kind, obj = token
        if kind == "pythoncom":
            obj.CoUninitialize()
        elif kind == "ctypes" and obj:
            ctypes.windll.ole32.CoUninitialize()
    except Exception:
        pass


def enum_chrome_windows():
    """Enumerate visible top-level Chrome windows without UI Automation.

    This Win32 fallback is deliberately independent of pywinauto/UIA.  It lets
    us find the Chrome HWND first and then attach UIA to that exact window.
    """
    if os.name != "nt":
        return []
    user32 = ctypes.windll.user32
    kernel32 = ctypes.windll.kernel32
    results = []
    WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    @WNDENUMPROC
    def cb(hwnd, lparam):
        try:
            if not user32.IsWindowVisible(hwnd):
                return True
            cls_buf = ctypes.create_unicode_buffer(256)
            user32.GetClassNameW(hwnd, cls_buf, len(cls_buf))
            cls = cls_buf.value
            if cls != "Chrome_WidgetWin_1":
                return True
            length = user32.GetWindowTextLengthW(hwnd)
            title_buf = ctypes.create_unicode_buffer(max(1, length + 1))
            user32.GetWindowTextW(hwnd, title_buf, len(title_buf))
            pid = wintypes.DWORD()
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            results.append({
                "hwnd": int(hwnd),
                "title": title_buf.value or "",
                "pid": int(pid.value),
                "class_name": cls,
            })
        except Exception:
            pass
        return True

    user32.EnumWindows(cb, 0)
    return results


def enum_top_windows():
    """Enumerate visible top-level Windows using plain Win32.

    v1.9 uses this for the legacy IC uploader because that program can be
    plainly visible on screen/taskbar while still being absent from the UIA
    Desktop enumeration.  Searching by HWND/title avoids treating that as a
    launch timeout.
    """
    if os.name != "nt":
        return []
    user32 = ctypes.windll.user32
    results = []
    WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    @WNDENUMPROC
    def cb(hwnd, lparam):
        try:
            if not user32.IsWindowVisible(hwnd):
                return True
            length = user32.GetWindowTextLengthW(hwnd)
            title_buf = ctypes.create_unicode_buffer(max(1, length + 1))
            user32.GetWindowTextW(hwnd, title_buf, len(title_buf))
            title = title_buf.value or ""
            cls_buf = ctypes.create_unicode_buffer(256)
            user32.GetClassNameW(hwnd, cls_buf, len(cls_buf))
            pid = wintypes.DWORD()
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            rect = wintypes.RECT()
            user32.GetWindowRect(hwnd, ctypes.byref(rect))
            results.append({
                "hwnd": int(hwnd),
                "title": title,
                "pid": int(pid.value),
                "class_name": cls_buf.value or "",
                "rect": (int(rect.left), int(rect.top), int(rect.right), int(rect.bottom)),
            })
        except Exception:
            pass
        return True

    user32.EnumWindows(cb, 0)
    return results


def win32_window_texts(hwnd: int) -> list[str]:
    """Collect title/text exposed through Win32 for a window and its children."""
    if os.name != "nt" or not hwnd:
        return []
    user32 = ctypes.windll.user32
    out = []

    def add_text(h):
        try:
            length = user32.GetWindowTextLengthW(h)
            if length <= 0:
                return
            buf = ctypes.create_unicode_buffer(length + 1)
            user32.GetWindowTextW(h, buf, len(buf))
            t = (buf.value or "").strip()
            if t and t not in out:
                out.append(t)
        except Exception:
            pass

    add_text(hwnd)
    WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    @WNDENUMPROC
    def cb(child, lparam):
        add_text(child)
        return True

    try:
        user32.EnumChildWindows(hwnd, cb, 0)
    except Exception:
        pass
    return out


def activate_hwnd(hwnd: int, maximize: bool = False) -> bool:
    """Best-effort foreground switch for old desktop programs.

    Uses several Win32 calls because SetForegroundWindow alone is sometimes
    refused when automation is running from a background worker thread.
    """
    if os.name != "nt" or not hwnd:
        return False
    user32 = ctypes.windll.user32
    kernel32 = ctypes.windll.kernel32
    SW_RESTORE = 9
    SW_MAXIMIZE = 3
    SW_SHOW = 5
    try:
        if user32.IsIconic(hwnd):
            user32.ShowWindow(hwnd, SW_RESTORE)
        user32.ShowWindow(hwnd, SW_MAXIMIZE if maximize else SW_SHOW)
        user32.BringWindowToTop(hwnd)

        fg = user32.GetForegroundWindow()
        cur_tid = kernel32.GetCurrentThreadId()
        target_tid = user32.GetWindowThreadProcessId(hwnd, None)
        fg_tid = user32.GetWindowThreadProcessId(fg, None) if fg else 0
        attached_target = False
        attached_fg = False
        try:
            if target_tid and target_tid != cur_tid:
                attached_target = bool(user32.AttachThreadInput(cur_tid, target_tid, True))
            if fg_tid and fg_tid not in (cur_tid, target_tid):
                attached_fg = bool(user32.AttachThreadInput(cur_tid, fg_tid, True))
            user32.SetForegroundWindow(hwnd)
            user32.SetActiveWindow(hwnd)
            user32.SetFocus(hwnd)
            user32.BringWindowToTop(hwnd)
        finally:
            if attached_fg:
                user32.AttachThreadInput(cur_tid, fg_tid, False)
            if attached_target:
                user32.AttachThreadInput(cur_tid, target_tid, False)
        time.sleep(0.15)
        return int(user32.GetForegroundWindow() or 0) == int(hwnd)
    except Exception:
        try:
            user32.SetForegroundWindow(hwnd)
            return True
        except Exception:
            return False


def foreground_window_title() -> str:
    if os.name != "nt":
        return ""
    try:
        user32 = ctypes.windll.user32
        hwnd = user32.GetForegroundWindow()
        length = user32.GetWindowTextLengthW(hwnd)
        buf = ctypes.create_unicode_buffer(max(1, length + 1))
        user32.GetWindowTextW(hwnd, buf, len(buf))
        return buf.value or ""
    except Exception:
        return ""


def acquire_run_mutex():
    if os.name != "nt":
        return None
    kernel32 = ctypes.windll.kernel32
    handle = kernel32.CreateMutexW(None, False, "Local\\PHIS_AutoUploader_RunLock")
    ERROR_ALREADY_EXISTS = 183
    if kernel32.GetLastError() == ERROR_ALREADY_EXISTS:
        kernel32.CloseHandle(handle)
        return None
    return handle


def release_run_mutex(handle):
    if handle and os.name == "nt":
        ctypes.windll.kernel32.ReleaseMutex(handle)
        ctypes.windll.kernel32.CloseHandle(handle)


def find_chrome_exe() -> Optional[str]:
    candidates = []
    if shutil.which("chrome"):
        candidates.append(shutil.which("chrome"))
    for envname in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA"):
        root = os.environ.get(envname)
        if root:
            candidates.append(str(Path(root) / "Google" / "Chrome" / "Application" / "chrome.exe"))
    for c in candidates:
        if c and Path(c).exists():
            return c
    return None


def paste_text(text: str):
    # Clipboard + pyautogui is intentionally independent of pywinauto's
    # keyboard module. This keeps the fixed-coordinate fallback usable even
    # while UI Automation is being repaired.
    import pyperclip
    pyperclip.copy(text)
    hotkey("ctrl", "v")


def scaled_point(name: str):
    import pyautogui
    w, h = pyautogui.size()
    x, y = FALLBACK_POINTS[name]
    return round(x * w / REFERENCE_W), round(y * h / REFERENCE_H)


def click_fallback(name: str, logger: Logger):
    import pyautogui
    pt = scaled_point(name)
    logger.write(f"UIA 未辨識到目標，使用固定環境備援點擊：{name} {pt}")
    pyautogui.click(*pt)


# ----------------------- UIA generic search -----------------------
def _safe_name(ctrl) -> str:
    try:
        return ctrl.element_info.name or ctrl.window_text() or ""
    except Exception:
        return ""


def _safe_rect(ctrl):
    try:
        r = ctrl.rectangle()
        return r, max(0, r.width()), max(0, r.height())
    except Exception:
        return None, 0, 0


def visible_controls(scope, control_types: Optional[Sequence[str]] = None):
    try:
        ctrls = scope.descendants()
    except Exception:
        return []
    out = []
    for c in ctrls:
        try:
            ctype = c.element_info.control_type
            if control_types and ctype not in control_types:
                continue
            r, w, h = _safe_rect(c)
            if not r or w < 2 or h < 2:
                continue
            if r.right <= 0 or r.bottom <= 0:
                continue
            out.append(c)
        except Exception:
            continue
    return out


def find_keyword_control(scope, keywords: Sequence[str], control_types: Optional[Sequence[str]] = None):
    targets = [normalize_text(x) for x in keywords if x]
    candidates = []
    for c in visible_controls(scope, control_types):
        name = _safe_name(c)
        nn = normalize_text(name)
        if not nn:
            continue
        if all(t in nn for t in targets):
            candidates.append((len(nn), c, name))
    if not candidates:
        return None
    candidates.sort(key=lambda t: t[0])
    return candidates[0][1]


def click_keyword(scope, keywords: Sequence[str], logger: Logger,
                  control_types: Optional[Sequence[str]] = None,
                  timeout: float = 12.0) -> bool:
    deadline = time.time() + timeout
    last_names = []
    while time.time() < deadline:
        ctrl = find_keyword_control(scope, keywords, control_types)
        if ctrl:
            try:
                logger.write(f"偵測到關鍵字目標：{' / '.join(keywords)} -> {_safe_name(ctrl)}")
                ctrl.click_input()
                return True
            except Exception:
                try:
                    r = ctrl.rectangle()
                    ctrl.parent().click_input(coords=(r.mid_point().x, r.mid_point().y))
                    return True
                except Exception:
                    pass
        time.sleep(0.4)
    logger.write(f"找不到關鍵字目標：{' / '.join(keywords)}")
    return False


def scope_contains(scope, keywords: Sequence[str]) -> bool:
    ctrl = find_keyword_control(scope, keywords)
    return ctrl is not None


# ----------------------- Chrome automation -----------------------
class ChromePHIS:
    def __init__(self, settings: Settings, logger: Logger):
        self.s = settings
        self.log = logger
        self.win = None
        self.hwnd = 0
        self._uia_attach_error_logged = False
        # v3.0.3: Chrome DevTools Protocol is used for PHIS web login.
        # This avoids screen coordinates / DPI / UIA exposure issues entirely.
        self.cdp_host = "127.0.0.1"
        # v3.0.4: let Chrome choose a free localhost DevTools port every run.
        # This avoids the fixed-9223 failure seen on the user's PC.
        self.cdp_port = 0
        self.cdp_browser_path = ""
        self._cdp_last_discovery_error = ""
        self.chrome_pid = 0
        self._last_login_submit_at = 0.0
        run_tag = f"{os.getpid()}_{int(time.time() * 1000)}"
        self.cdp_profile = BASE_DIR / "chrome_auto_profiles" / f"run_{run_tag}"

    @staticmethod
    def _recv_exact(sock_obj: socket.socket, count: int) -> bytes:
        data = bytearray()
        while len(data) < count:
            chunk = sock_obj.recv(count - len(data))
            if not chunk:
                raise RuntimeError("Chrome DevTools WebSocket 連線提前關閉。")
            data.extend(chunk)
        return bytes(data)

    @classmethod
    def _recv_ws_payload(cls, sock_obj: socket.socket) -> tuple[int, bytes]:
        head = cls._recv_exact(sock_obj, 2)
        opcode = head[0] & 0x0F
        masked = bool(head[1] & 0x80)
        length = head[1] & 0x7F
        if length == 126:
            length = struct.unpack("!H", cls._recv_exact(sock_obj, 2))[0]
        elif length == 127:
            length = struct.unpack("!Q", cls._recv_exact(sock_obj, 8))[0]
        mask = cls._recv_exact(sock_obj, 4) if masked else b""
        payload = cls._recv_exact(sock_obj, length) if length else b""
        if masked:
            payload = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
        return opcode, payload

    @staticmethod
    def _ws_client_frame(payload: bytes, opcode: int = 0x1) -> bytes:
        fin_opcode = 0x80 | (opcode & 0x0F)
        mask = os.urandom(4)
        length = len(payload)
        if length < 126:
            header = bytes([fin_opcode, 0x80 | length])
        elif length <= 0xFFFF:
            header = bytes([fin_opcode, 0x80 | 126]) + struct.pack("!H", length)
        else:
            header = bytes([fin_opcode, 0x80 | 127]) + struct.pack("!Q", length)
        masked = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
        return header + mask + masked

    def _wait_dynamic_cdp_port(self, timeout: float = 15.0) -> int:
        """Read port + browser websocket path from Chrome's DevToolsActivePort."""
        port_file = self.cdp_profile / "DevToolsActivePort"
        deadline = time.time() + timeout
        last_error = ""
        while time.time() < deadline:
            try:
                if port_file.exists():
                    lines = [
                        line.strip()
                        for line in port_file.read_text(
                            encoding="utf-8", errors="replace"
                        ).splitlines()
                        if line.strip()
                    ]
                    if lines:
                        port = int(lines[0])
                        if 1 <= port <= 65535:
                            self.cdp_port = port
                            if len(lines) >= 2:
                                self.cdp_browser_path = lines[1]
                            return port
            except Exception as e:
                last_error = str(e)
            time.sleep(0.06)
        raise RuntimeError(
            "Chrome 已開啟，但沒有產生有效的 DevToolsActivePort。"
            + (f" 最後錯誤：{last_error}" if last_error else "")
        )

    @staticmethod
    def _parse_http_body(raw: bytes) -> bytes:
        sep = raw.find(b"\r\n\r\n")
        if sep < 0:
            raise RuntimeError("DevTools HTTP 回應缺少標頭結束符號。")
        header_blob = raw[:sep].decode("latin1", errors="replace")
        body = raw[sep + 4:]
        first = header_blob.split("\r\n", 1)[0]
        if " 200 " not in f" {first} ":
            raise RuntimeError(f"DevTools HTTP 回應失敗：{first}")

        headers = {}
        for line in header_blob.split("\r\n")[1:]:
            if ":" in line:
                k, v = line.split(":", 1)
                headers[k.strip().lower()] = v.strip().lower()

        # Chrome normally returns Content-Length here, but support chunked too.
        if headers.get("transfer-encoding") == "chunked":
            out = bytearray()
            pos = 0
            while True:
                line_end = body.find(b"\r\n", pos)
                if line_end < 0:
                    raise RuntimeError("DevTools chunked HTTP 回應格式不完整。")
                size_text = body[pos:line_end].split(b";", 1)[0].strip()
                size = int(size_text or b"0", 16)
                pos = line_end + 2
                if size == 0:
                    break
                out.extend(body[pos:pos + size])
                pos += size + 2
            return bytes(out)
        return body

    def _raw_http_json(self, path: str, timeout: float = 2.0):
        """Read Chrome DevTools HTTP endpoint through raw localhost TCP.

        This deliberately avoids urllib/WinHTTP/proxy environment handling.
        """
        last_error = ""
        hosts = [self.cdp_host, "localhost", "::1"]
        for host in hosts:
            try:
                family = socket.AF_INET6 if ":" in host else socket.AF_UNSPEC
                infos = socket.getaddrinfo(
                    host, self.cdp_port, family, socket.SOCK_STREAM
                )
                for af, socktype, proto, _, sockaddr in infos:
                    try:
                        with socket.socket(af, socktype, proto) as s:
                            s.settimeout(timeout)
                            s.connect(sockaddr)
                            host_header = (
                                f"[{host}]:{self.cdp_port}"
                                if ":" in host else f"{host}:{self.cdp_port}"
                            )
                            req = (
                                f"GET {path} HTTP/1.1\r\n"
                                f"Host: {host_header}\r\n"
                                "Connection: close\r\n"
                                "Accept: application/json\r\n"
                                "\r\n"
                            ).encode("ascii")
                            s.sendall(req)
                            chunks = []
                            while True:
                                try:
                                    chunk = s.recv(65536)
                                except socket.timeout:
                                    break
                                if not chunk:
                                    break
                                chunks.append(chunk)
                            raw = b"".join(chunks)
                            if not raw:
                                raise RuntimeError("DevTools HTTP 沒有回應資料。")
                            body = self._parse_http_body(raw)
                            return json.loads(body.decode("utf-8", errors="replace"))
                    except Exception as e:
                        last_error = f"{host}: {e}"
            except Exception as e:
                last_error = f"{host}: {e}"
        raise RuntimeError(last_error or "無法直連 Chrome DevTools HTTP。")

    def _cdp_ws_request(
        self,
        path: str,
        method: str,
        params=None,
        timeout: float = 4.0,
        host: str | None = None,
    ):
        """Send one CDP request over a direct localhost WebSocket."""
        host = host or self.cdp_host
        key = base64.b64encode(os.urandom(16)).decode("ascii")
        host_header = (
            f"[{host}]:{self.cdp_port}"
            if ":" in host else f"{host}:{self.cdp_port}"
        )
        req = (
            f"GET {path} HTTP/1.1\r\n"
            f"Host: {host_header}\r\n"
            "Upgrade: websocket\r\n"
            "Connection: Upgrade\r\n"
            f"Sec-WebSocket-Key: {key}\r\n"
            "Sec-WebSocket-Version: 13\r\n"
            f"Origin: http://127.0.0.1:{self.cdp_port}\r\n"
            "\r\n"
        ).encode("ascii")

        with socket.create_connection((host, self.cdp_port), timeout=timeout) as s:
            s.settimeout(timeout)
            s.sendall(req)

            headers = bytearray()
            while b"\r\n\r\n" not in headers and len(headers) < 65536:
                chunk = s.recv(4096)
                if not chunk:
                    break
                headers.extend(chunk)
            first = bytes(headers).split(b"\r\n", 1)[0].decode(
                "latin1", errors="replace"
            )
            if " 101 " not in f" {first} ":
                raise RuntimeError(
                    f"Chrome DevTools WebSocket 握手失敗：{first or '沒有回應'}"
                )

            request_id = 1
            payload = json.dumps(
                {
                    "id": request_id,
                    "method": method,
                    "params": params or {},
                },
                ensure_ascii=False,
            ).encode("utf-8")
            s.sendall(self._ws_client_frame(payload))

            deadline = time.time() + timeout
            while time.time() < deadline:
                opcode, data = self._recv_ws_payload(s)
                if opcode == 0x8:
                    break
                if opcode == 0x9:
                    s.sendall(self._ws_client_frame(data, opcode=0xA))
                    continue
                if opcode != 0x1:
                    continue
                try:
                    msg = json.loads(data.decode("utf-8", errors="replace"))
                except Exception:
                    continue
                if msg.get("id") == request_id:
                    if "error" in msg:
                        raise RuntimeError(
                            f"Chrome DevTools 呼叫失敗：{msg['error']}"
                        )
                    return msg.get("result", {})
            raise RuntimeError(f"Chrome DevTools 呼叫逾時：{method}")

    def _cdp_targets(self):
        """Discover PHIS page targets without urllib/proxy dependencies."""
        errors = []

        # Preferred: raw localhost HTTP, first /json/list then legacy /json.
        for endpoint in ("/json/list", "/json"):
            try:
                data = self._raw_http_json(endpoint, timeout=2.0)
                if isinstance(data, list):
                    pages = [
                        x for x in data
                        if x.get("type") == "page"
                        and x.get("webSocketDebuggerUrl")
                    ]
                    if pages:
                        self._cdp_last_discovery_error = ""
                        return pages
            except Exception as e:
                errors.append(f"{endpoint}: {e}")

        # Fallback: talk to Chrome's browser-level websocket path from
        # DevToolsActivePort and ask Target.getTargets directly.
        if self.cdp_browser_path:
            try:
                result = self._cdp_ws_request(
                    self.cdp_browser_path,
                    "Target.getTargets",
                    {},
                    timeout=3.0,
                )
                pages = []
                for info in result.get("targetInfos", []):
                    if info.get("type") != "page":
                        continue
                    target_id = info.get("targetId")
                    if not target_id:
                        continue
                    pages.append({
                        "id": target_id,
                        "type": "page",
                        "title": info.get("title", ""),
                        "url": info.get("url", ""),
                        "webSocketDebuggerUrl":
                            f"ws://127.0.0.1:{self.cdp_port}/devtools/page/{target_id}",
                    })
                if pages:
                    self._cdp_last_discovery_error = ""
                    return pages
            except Exception as e:
                errors.append(f"Target.getTargets: {e}")

        self._cdp_last_discovery_error = "；".join(errors[-3:])
        return []

    def _cdp_target(self):
        targets = self._cdp_targets()
        if not targets:
            return None
        wanted = urlparse(self.s.url)
        host = (wanted.hostname or "").lower()
        path = (wanted.path or "/").lower()
        # Prefer the PHIS tab; fall back to the most recently exposed page target.
        for item in reversed(targets):
            u = (item.get("url") or "").lower()
            if host and host in u and (not path or path in u):
                return item
        for item in reversed(targets):
            title = normalize_text(item.get("title") or "")
            if any(x in title for x in ("phis", "門診醫", "servererror", "500")):
                return item
        return targets[-1]

    def _cdp_call(self, method: str, params=None, timeout: float = 4.0):
        target = self._cdp_target()
        if not target:
            detail = self._cdp_last_discovery_error or "沒有取得任何 page target"
            raise RuntimeError(f"找不到 PHIS Chrome 的 DevTools 分頁：{detail}")

        ws_url = target["webSocketDebuggerUrl"]
        parsed = urlparse(ws_url)
        path = parsed.path or "/"
        if parsed.query:
            path += "?" + parsed.query

        # The page websocket is local and uses the same dynamic DevTools port.
        return self._cdp_ws_request(
            path,
            method,
            params or {},
            timeout=timeout,
            host=parsed.hostname or self.cdp_host,
        )

    def _cdp_eval(self, expression: str, timeout: float = 5.0):
        result = self._cdp_call(
            "Runtime.evaluate",
            {
                "expression": expression,
                "returnByValue": True,
                "awaitPromise": True,
                "userGesture": True,
            },
            timeout=timeout,
        )
        obj = result.get("result", {})
        if obj.get("subtype") == "error":
            raise RuntimeError(obj.get("description") or "JavaScript 執行失敗")
        return obj.get("value")

    def _wait_cdp_ready(self, timeout: float = 15.0) -> bool:
        deadline = time.time() + timeout
        last_error = ""
        while time.time() < deadline:
            try:
                target = self._cdp_target()
                if target:
                    value = self._cdp_eval("document.readyState", timeout=2.0)
                    if value:
                        return True
                else:
                    last_error = self._cdp_last_discovery_error
            except Exception as e:
                last_error = str(e)
            time.sleep(0.25)
        if last_error:
            self.log.write("DevTools 尚未就緒，最後診斷：" + last_error)
        return False

    def _dom_snapshot(self):
        """Read PHIS page state from DOM, including same-origin frames."""
        script = r"""
(() => {
  const docs = [];
  const walk = (w) => {
    try {
      if (w.document) docs.push(w.document);
      for (let i = 0; i < w.frames.length; i++) {
        try { walk(w.frames[i]); } catch (e) {}
      }
    } catch (e) {}
  };
  walk(window);
  const text = docs.map(d => {
    try { return (d.body && (d.body.innerText || d.body.textContent)) || ""; }
    catch (e) { return ""; }
  }).join("\\n");
  let hasPassword = false;
  let hasUser = false;
  let inputCount = 0;
  for (const d of docs) {
    try {
      const inputs = Array.from(d.querySelectorAll("input"));
      inputCount += inputs.length;
      if (inputs.some(el => (el.type || "").toLowerCase() === "password")) hasPassword = true;
      if (inputs.some(el => {
        const t = (el.type || "text").toLowerCase();
        const k = `${el.name||""} ${el.id||""} ${el.placeholder||""}`.toLowerCase();
        return (t === "text" || t === "" || t === "email") &&
               (/user|account|login|userid|username|uid|帳號|代號/.test(k) || inputs.length <= 5);
      })) hasUser = true;
    } catch (e) {}
  }
  return {
    title: document.title || "",
    url: location.href,
    text: text.slice(0, 30000),
    hasPassword,
    hasUser,
    inputCount
  };
})()
"""
        try:
            value = self._cdp_eval(script, timeout=4.0)
            return value if isinstance(value, dict) else {}
        except Exception:
            return {}

    def _dom_submit_login(self) -> dict:
        """Fill and submit PHIS login directly through the page DOM.

        Credentials are never logged.  The password exists only in the local CDP
        command sent over 127.0.0.1 to this dedicated Chrome instance.
        """
        if not self.s.username or not self.s.password:
            raise RuntimeError("PHIS 帳號或密碼尚未設定。")

        user_js = json.dumps(self.s.username, ensure_ascii=False)
        pass_js = json.dumps(self.s.password, ensure_ascii=False)
        script = r"""
((USER, PASS) => {
  const docs = [];
  const walk = (w) => {
    try {
      if (w.document) docs.push(w.document);
      for (let i = 0; i < w.frames.length; i++) {
        try { walk(w.frames[i]); } catch (e) {}
      }
    } catch (e) {}
  };
  const visible = (el) => {
    try {
      const st = el.ownerDocument.defaultView.getComputedStyle(el);
      const r = el.getBoundingClientRect();
      return st.display !== "none" && st.visibility !== "hidden" &&
             Number(st.opacity || 1) !== 0 && r.width >= 0 && r.height >= 0;
    } catch (e) { return true; }
  };
  const setValue = (el, value) => {
    try {
      const proto = el instanceof HTMLTextAreaElement
        ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const desc = Object.getOwnPropertyDescriptor(proto, "value");
      if (desc && desc.set) desc.set.call(el, value);
      else el.value = value;
    } catch (e) { el.value = value; }
    for (const ev of ["input", "change", "keyup"]) {
      try { el.dispatchEvent(new Event(ev, {bubbles:true})); } catch (e) {}
    }
  };
  const words = (el) => [
    el.name, el.id, el.value, el.alt, el.title,
    el.getAttribute && el.getAttribute("aria-label"),
    el.src, el.textContent
  ].filter(Boolean).join(" ").toLowerCase();

  walk(window);

  for (const d of docs) {
    let inputs = [];
    try { inputs = Array.from(d.querySelectorAll("input")).filter(visible); }
    catch (e) { continue; }

    const pass = inputs.find(el => (el.type || "").toLowerCase() === "password");
    if (!pass) continue;

    const texts = inputs.filter(el => {
      const t = (el.type || "text").toLowerCase();
      return t === "text" || t === "" || t === "email";
    });
    if (!texts.length) continue;

    const scoredUsers = texts.map((el, idx) => {
      const k = words(el);
      let score = 0;
      if (/user|account|login|userid|username|uid|帳號|代號/.test(k)) score += 100;
      if (el.form && pass.form && el.form === pass.form) score += 40;
      try {
        const pr = pass.getBoundingClientRect(), ur = el.getBoundingClientRect();
        score += Math.max(0, 30 - Math.abs(pr.top - ur.top) / 10);
      } catch (e) {}
      score -= idx * 0.01;
      return {el, score};
    }).sort((a,b) => b.score - a.score);

    const user = scoredUsers[0].el;
    setValue(user, USER);
    setValue(pass, PASS);

    const form = pass.form || user.form || user.closest("form") || pass.closest("form");
    let candidates = [];
    try {
      const root = form || d;
      candidates = Array.from(root.querySelectorAll("input,button,a,img")).filter(visible);
    } catch (e) {}

    const ranked = candidates.map((el, idx) => {
      const tag = (el.tagName || "").toLowerCase();
      const type = (el.type || "").toLowerCase();
      const k = words(el);
      let score = 0;
      if (type === "submit") score += 90;
      if (type === "image") score += 85;
      if (tag === "button") score += 55;
      if (/login|logon|signin|submit|enter|登入|登錄|確定|確認|check|ok/.test(k)) score += 120;
      if (/reset|clear|cancel|取消|清除|重設|exit|close/.test(k)) score -= 200;
      if (el.form && form && el.form === form) score += 30;
      score -= idx * 0.01;
      return {el, score, desc: k.slice(0,160)};
    }).sort((a,b) => b.score - a.score);

    const best = ranked.find(x => x.score > 0);
    if (best) {
      try {
        best.el.focus();
        best.el.click();
        return {
          ok:true,
          action:"click",
          userField:user.name || user.id || "(text input)",
          passField:pass.name || pass.id || "(password input)",
          submit:best.desc
        };
      } catch (e) {}
    }

    if (form) {
      try {
        if (typeof form.requestSubmit === "function") {
          form.requestSubmit();
          return {ok:true, action:"requestSubmit",
                  userField:user.name||user.id||"(text input)",
                  passField:pass.name||pass.id||"(password input)"};
        }
      } catch (e) {}
      try {
        HTMLFormElement.prototype.submit.call(form);
        return {ok:true, action:"form.submit",
                userField:user.name||user.id||"(text input)",
                passField:pass.name||pass.id||"(password input)"};
      } catch (e) {}
    }

    return {ok:false, error:"找到帳號/密碼欄，但找不到可送出的登入 form/button"};
  }

  return {ok:false, error:"DOM 中找不到 PHIS 密碼欄"};
})(%s, %s)
""" % (user_js, pass_js)

        result = self._cdp_eval(script, timeout=5.0)
        if not isinstance(result, dict):
            raise RuntimeError("PHIS DOM 登入沒有回傳有效結果。")
        return result

    def _cdp_navigate(self, url: str):
        self._cdp_call("Page.navigate", {"url": url}, timeout=4.0)

    def _cdp_reload_phis(self, reason: str = ""):
        """立即刷新 PHIS，不再固定等待 0.8~2 秒。"""
        msg = "重新整理 PHIS 頁面"
        if reason:
            msg += f"（{reason}）"
        self.log.write(msg + "。")
        try:
            self._cdp_call(
                "Page.reload",
                {"ignoreCache": False},
                timeout=3.0,
            )
        except Exception as e:
            self.log.write(f"DevTools Page.reload 失敗，改重新導向 PHIS 首頁：{e}")
            self._cdp_navigate(self.s.url)

    def _desktop(self):
        from pywinauto import Desktop
        return Desktop(backend="uia")

    def _ensure_maximized(self, log_once: bool = False):
        """把本次 PHIS Chrome 視窗切到前景並最大化。

        v2.1.4 依使用者指定：所有頁面狀態判斷與 PHIS 點按前，先確保
        Chrome 已最大化，讓 1920x1080 / 125% 的備援位置與影片一致。
        """
        if not self.hwnd:
            try:
                self.hwnd = int(self.win.handle) if self.win is not None else 0
            except Exception:
                self.hwnd = 0
        if self.hwnd:
            activate_hwnd(self.hwnd, maximize=True)
            if log_once and not getattr(self, "_maximized_logged", False):
                self.log.write("已將本次 PHIS Chrome 視窗自動最大化；後續判斷與點按均以最大化畫面進行。")
                self._maximized_logged = True
        else:
            try:
                if self.win is not None:
                    self.win.maximize()
                    self.win.set_focus()
            except Exception:
                pass
        time.sleep(0.08)

    def _window_rect(self):
        """Return the current Chrome top-level window rectangle in physical pixels.

        v2.1.4 maximizes Chrome before page judgement and clicking.  The PHIS page
        uses a fixed left-anchored layout, so the old 1920x1080 fallback points
        remain valid as *offsets from the Chrome window's top-left corner*.
        """
        if os.name == "nt" and self.hwnd:
            try:
                rect = wintypes.RECT()
                if ctypes.windll.user32.GetWindowRect(int(self.hwnd), ctypes.byref(rect)):
                    return int(rect.left), int(rect.top), int(rect.right), int(rect.bottom)
            except Exception:
                pass
        try:
            if self.win is not None:
                r = self.win.rectangle()
                return int(r.left), int(r.top), int(r.right), int(r.bottom)
        except Exception:
            pass
        return None

    def _browser_point(self, name: str):
        """Translate a PHIS fallback point to the current Chrome window position.

        This remains compatible with window-relative fallback; v2.1.4 normally maximizes Chrome first, so no full-screen coordinate is
        used for login/menu fallback clicks.  Moving/resizing the browser no longer
        shifts the click target away from the PHIS controls.
        """
        import pyautogui
        rect = self._window_rect()
        ox, oy = FALLBACK_POINTS[name]
        if rect:
            left, top, right, bottom = rect
            x = left + ox
            y = top + oy
            # Keep the point inside the current Chrome window.
            x = min(max(x, left + 4), right - 4)
            y = min(max(y, top + 4), bottom - 4)
            return int(x), int(y)
        # Last-resort compatibility with the original v2.1 behavior.
        return scaled_point(name)

    def _click_browser_fallback(self, name: str):
        import pyautogui
        self._ensure_maximized()
        pt = self._browser_point(name)
        self.log.write(f"UIA 未辨識到目標，改用目前 Chrome 視窗相對位置備援點擊：{name} {pt}")
        pyautogui.click(*pt)

    def _browser_screenshot(self):
        """Capture only the visible Chrome window, regardless of maximized state."""
        import pyautogui
        self._ensure_maximized()
        rect = self._window_rect()
        if not rect:
            return pyautogui.screenshot(), (0, 0)
        left, top, right, bottom = rect
        sw, sh = pyautogui.size()
        left = max(0, min(left, sw - 1))
        top = max(0, min(top, sh - 1))
        right = max(left + 1, min(right, sw))
        bottom = max(top + 1, min(bottom, sh))
        return pyautogui.screenshot(region=(left, top, right-left, bottom-top)), (left, top)

    def start(self):
        chrome = find_chrome_exe()
        if not chrome:
            raise RuntimeError("找不到 Google Chrome。請先安裝 Chrome。")

        before = {w["hwnd"] for w in enum_chrome_windows()}
        self.cdp_profile.mkdir(parents=True, exist_ok=True)

        self.log.write(
            "開啟 PHIS 專用 Chrome；v3.0.4 使用每次執行獨立 Chrome Profile，"
            "並讓 Chrome 自動選擇可用的本機 DevTools Port；登入仍直接操作 DOM。"
        )
        proc = subprocess.Popen([
            chrome,
            "--new-window",
            "--force-renderer-accessibility",
            "--disable-session-crashed-bubble",
            "--no-first-run",
            "--no-default-browser-check",
            "--remote-debugging-address=127.0.0.1",
            "--remote-debugging-port=0",
            "--remote-allow-origins=*",
            f"--user-data-dir={self.cdp_profile}",
            self.s.url,
        ])
        self.chrome_pid = int(proc.pid)
        self.log.write(f"Chrome 啟動指令已送出（PID {proc.pid}），等待 PHIS 視窗與 DevToolsActivePort。")

        # Read Chrome's real ephemeral port instead of assuming 9223.
        port = self._wait_dynamic_cdp_port(20.0)
        self.log.write(f"Chrome DevTools 已啟動於本機 127.0.0.1:{port}。")

        self.win = self._wait_chrome_window(30, before_handles=before, launched_pid=proc.pid)
        if not self.win:
            discovered = enum_chrome_windows()
            if discovered:
                brief = "；".join(
                    f"HWND={w['hwnd']} PID={w['pid']} 標題={w['title'][:60] or '(空白)'}"
                    for w in discovered[-6:]
                )
                self.log.write(f"目前可見 Chrome 視窗：{brief}")
            raise RuntimeError("Chrome 已啟動，但無法取得 PHIS 自動化視窗。")
        try:
            self.hwnd = int(self.win.handle)
        except Exception:
            self.hwnd = 0
        # PHIS credentials are entered through local CDP; foreground focus and
        # maximizing are deferred until login is confirmed.
        if not self._wait_cdp_ready(15.0):
            raise RuntimeError(
                f"PHIS Chrome 已開啟，但無法連上本機 DevTools {self.cdp_port}。"
                "本版已使用 Chrome 自動分配 Port，且以 raw TCP/Browser WebSocket 雙路徑讀取 DevTools；請把『最後診斷』一行與執行記錄傳回。"
            )
        self.log.write(
            f"已連上 PHIS Chrome DevTools（127.0.0.1:{self.cdp_port}）；"
            "網頁帳密將直接透過 DOM 填寫與送出，不使用登入座標。"
        )

    def _uia_from_hwnd(self, hwnd):
        """Return a UIA wrapper for an already-known top-level HWND."""
        try:
            from pywinauto import Desktop
            w = Desktop(backend="uia").window(handle=hwnd)
            # Force wrapper resolution now so failures happen here, not later.
            _ = w.element_info
            return w
        except Exception as e1:
            try:
                from pywinauto import Application
                app = Application(backend="uia").connect(handle=hwnd, timeout=3)
                w = app.window(handle=hwnd)
                _ = w.element_info
                return w
            except Exception as e2:
                # Avoid flooding the log once per Chrome HWND every 0.4 sec.
                if not self._uia_attach_error_logged:
                    self.log.write(f"UIA 連接 Chrome 失敗：{e2}")
                    self._uia_attach_error_logged = True
                return None

    def _wait_chrome_window(self, timeout=15, before_handles=None, launched_pid=None):
        """Find the newly launched Chrome HWND quickly, then attach UIA once."""
        deadline = time.time() + timeout
        before_handles = set(before_handles or ())
        last_attach_attempt = {}
        next_uia_scan = 0.0
        uia_error_logged = False

        def score(info):
            hwnd = int(info.get("hwnd") or 0)
            title_n = normalize_text(info.get("title", ""))
            value = 0
            if hwnd not in before_handles:
                value += 100
            if launched_pid and int(info.get("pid") or 0) == int(launched_pid):
                value += 80
            if any(normalize_text(k) in title_n for k in (
                "PHIS", "門診醫", "500", "Server Error", "192.168.1.2"
            )):
                value += 20
            return value

        while time.time() < deadline:
            now = time.time()
            # EnumWindows is much lighter than a full UIA Desktop scan. Prefer
            # this process/new handles so an already-open personal Chrome is ignored.
            candidates = [
                item for item in enum_chrome_windows()
                if int(item.get("hwnd") or 0) not in before_handles
                or (launched_pid and int(item.get("pid") or 0) == int(launched_pid))
            ]
            for info in sorted(candidates, key=score, reverse=True):
                hwnd = int(info.get("hwnd") or 0)
                if not hwnd or now - last_attach_attempt.get(hwnd, 0.0) < 0.6:
                    continue
                last_attach_attempt[hwnd] = now
                wrapper = self._uia_from_hwnd(hwnd)
                if wrapper is not None:
                    title = info.get("title") or "(標題尚未載入)"
                    self.log.write(f"以 Win32 HWND 快速連接本次 Chrome：{title}")
                    return wrapper

            # UIA is retained as a recovery path, but does not block every poll.
            if now >= next_uia_scan:
                next_uia_scan = now + 0.7
                try:
                    windows = self._desktop().windows()
                    matching = []
                    for win in windows:
                        try:
                            if (win.element_info.class_name or "") != "Chrome_WidgetWin_1":
                                continue
                            hwnd = int(win.handle)
                            if hwnd in before_handles:
                                continue
                            info = next((x for x in candidates if int(x.get("hwnd") or 0) == hwnd), {})
                            matching.append((score(info) if info else 100, win))
                        except Exception:
                            continue
                    if matching:
                        matching.sort(key=lambda item: item[0], reverse=True)
                        win = matching[0][1]
                        self.log.write(f"以 UIA 備援找到本次新 Chrome 視窗：{win.window_text() or '(標題尚未載入)'}")
                        return win
                except Exception as e:
                    if not uia_error_logged:
                        self.log.write(f"UIA 視窗備援暫不可用，持續使用 Win32 HWND 偵測：{e}")
                        uia_error_logged = True
            time.sleep(0.08)
        return None

    def title(self) -> str:
        try:
            return self.win.window_text() or ""
        except Exception:
            return ""

    def document(self):
        if not self.win:
            return None
        try:
            docs = self.win.descendants(control_type="Document")
            docs = [d for d in docs if _safe_rect(d)[1] > 100 and _safe_rect(d)[2] > 100]
            return docs[-1] if docs else self.win
        except Exception:
            return self.win

    def _wait_page(self, seconds=12):
        deadline = time.time() + seconds
        while time.time() < deadline:
            title = self.title()
            if title:
                return
            time.sleep(0.12)

    def _submit_login_form(self, pass_edit=None):
        """Submit the legacy PHIS login form without relying on one fixed screen coordinate.

        Primary route: the password field remains focused after typing, so move to the
        next focusable control (the green submit image) and press Enter.
        If the page is still unmistakably the Login page after a short wait and UIA gave
        us the password-field rectangle, click the submit image relative to that field.
        """
        import pyautogui

        # Keep Chrome in front; the automation window must not steal the keystrokes.
        try:
            self.win.set_focus()
        except Exception:
            pass
        time.sleep(0.15)

        # On the old PHIS form the next focusable item after password is the green tick.
        self.log.write("送出登入：不再使用舊固定座標，先以 Tab → Enter 觸發綠色勾勾。")
        pyautogui.press("tab")
        time.sleep(0.18)
        pyautogui.press("enter")

        # Allow the local PHIS page time to leave the login form.
        time.sleep(2.2)

        try:
            still_login = self._is_login_page()
        except Exception:
            still_login = False

        if not still_login:
            return

        # Second route: derive the tick position from the actual password field that UIA
        # detected in THIS Chrome window.  This survives different DPI / effective
        # resolutions much better than the historical 1920x1080 point.
        if pass_edit is not None:
            try:
                r, w, h = _safe_rect(pass_edit)
                if w > 30 and h > 10:
                    x = int(r.left + max(24, min(42, round(w * 0.25))))
                    y = int(r.bottom + max(24, min(32, round(h * 1.25))))
                    self.log.write(
                        f"Login 頁仍存在，改依密碼欄實際位置點擊綠色勾勾備援：({x}, {y})。"
                    )
                    try:
                        self.win.set_focus()
                    except Exception:
                        pass
                    time.sleep(0.10)
                    pyautogui.click(x, y)
                    return
            except Exception as e:
                self.log.write(f"依 UIA 欄位推算登入勾勾位置失敗：{e}")

        # Last resort only when the old page exposes no useful element geometry.
        # Kept for backwards compatibility with the user's original 1920x1080 setup.
        pt = self._browser_point("login_submit")
        self.log.write(f"最後備援：使用舊版 Chrome 視窗相對登入點 {pt}。")
        pyautogui.click(*pt)

    def _recover_server_error_fast(self, stage: str = "") -> str:
        """快速處理 PHIS 500。

        回傳 login / function / other / server。
        一刷新後每 0.18 秒讀一次 DOM；一恢復就立刻往下跑。
        """
        self._cdp_reload_phis(reason=stage or "Server Error 快速恢復")
        deadline = time.time() + SERVER_ERROR_RECOVERY_WINDOW_SECONDS

        while time.time() < deadline:
            time.sleep(SERVER_ERROR_FAST_POLL_SECONDS)
            snap = self._dom_snapshot()
            if not snap:
                continue

            body = snap.get("text", "") or ""
            nt = normalize_text(body)
            title_nt = normalize_text(snap.get("title", ""))

            if "門診醫療子系統" in body or (
                "功能選單" in body and ("門診醫療" in body or "保健個案子系統" in body)
            ):
                return "function"

            if snap.get("hasPassword"):
                return "login"

            is_500 = (
                "500" in title_nt
                or "servererror" in title_nt
                or "servererror" in nt
                or "internalservererror" in nt
                or "內部伺服器錯誤" in nt
            )
            if not is_500:
                return "other"

        # Still 500 after the short window: return immediately so the caller
        # can issue another reload without a noticeable pause.
        if SERVER_ERROR_RELOAD_GAP_SECONDS > 0:
            time.sleep(SERVER_ERROR_RELOAD_GAP_SECONDS)
        return "server"

    def fill_login(self, force_fixed: bool = False, reason: str = ""):
        """快速 DOM 登入；Server Error 立即刷新，不做長時間固定等待。"""
        if not self.s.username or not self.s.password:
            raise RuntimeError("PHIS 帳號或密碼尚未設定。")

        if reason:
            self.log.write(f"準備重新登入 PHIS（{reason}）：使用快速 DOM 登入。")
        else:
            self.log.write("正在使用快速 DOM 登入 PHIS。")

        deadline = time.time() + 45.0
        last_snapshot = {}
        server_error_count = 0

        while time.time() < deadline:
            snap = self._dom_snapshot()
            if snap:
                last_snapshot = snap
                body = snap.get("text", "") or ""
                nt = normalize_text(body)
                title_nt = normalize_text(snap.get("title", ""))

                if self._is_function_page(snapshot=snap, dom_only=True):
                    self.log.write("已由 PHIS 正常功能頁 DOM 特徵確認登入，略過帳密送出。")
                    return

                if "門診醫療子系統" in body or (
                    "功能選單" in body and ("門診醫療" in body or "保健個案子系統" in body)
                ):
                    self.log.write("PHIS 已在功能頁，直接沿用登入狀態。")
                    return

                if snap.get("hasPassword"):
                    break

                is_500 = (
                    "500" in title_nt
                    or "servererror" in title_nt
                    or "servererror" in nt
                    or "internalservererror" in nt
                    or "內部伺服器錯誤" in nt
                )
                if is_500:
                    server_error_count += 1
                    if server_error_count > 20:
                        raise RuntimeError(
                            "PHIS 已連續 20 次顯示 Server Error，為避免無限刷新已停止。"
                        )

                    self.log.write(
                        f"偵測到 PHIS Server Error，第 {server_error_count} 次立即刷新。"
                    )
                    state = self._recover_server_error_fast(
                        stage=f"Server Error 第 {server_error_count} 次"
                    )
                    if state == "function":
                        self.log.write("刷新後已直接回到 PHIS 功能頁，立即繼續。")
                        return
                    if state == "login":
                        self.log.write("刷新後登入表單已恢復，立即送出 DOM 登入。")
                        break
                    continue

            time.sleep(0.06)
        else:
            raise RuntimeError(
                "等待 PHIS 登入頁逾時；"
                f"目前標題={last_snapshot.get('title','(未知)')}。"
            )

        result = self._dom_submit_login()
        if not result.get("ok"):
            raise RuntimeError(
                "PHIS DOM 登入送出失敗：" + str(result.get("error") or "未知原因")
            )

        self.log.write(
            "已由 DOM 立即送出 PHIS 登入"
            f"（方式={result.get('action','unknown')}；"
            f"帳號欄={result.get('userField','?')}；密碼欄={result.get('passField','?')}）。"
        )
        self._last_login_submit_at = time.time()

    def _visual_page_state(self):
        """用畫面色塊做 PHIS 頁面狀態的「輔助判斷」。

        v2.1.5 修正：v2.1.4 只要偵測到一條較寬的灰色列就可能把正常的
        PHIS 功能頁誤判成 Server Error，造成登入成功後仍持續 Ctrl+R。

        新規則同時檢查：
        - 正常功能頁大量的淡綠色背景 / 藍色功能連結
        - Server Error 頁大量白底 + 深灰橫列，且淡綠色/藍色比例很低

        視覺判斷只作保險；若 UIA 已明確看到 PHIS 功能選單文字，會優先
        視為正常功能頁，不會因色塊誤判而重新整理。
        """
        try:
            shot, _origin = self._browser_screenshot()
            w, h = shot.size
            left = 0
            right = max(1, min(w, max(520, int(w * 0.58))))
            top = max(0, min(h - 1, 90))
            bottom = max(top + 1, min(h, max(520, int(h * 0.78))))
            roi = shot.crop((left, top, right, bottom)).convert("RGB")
            rw, rh = roi.size
            pix = roi.load()

            blue = 0
            pale_green = 0
            white = 0
            max_gray_row_ratio = 0.0
            step = 2
            sampled_cols = max(1, (rw + step - 1) // step)
            sampled_rows = max(1, (rh + step - 1) // step)

            for y in range(0, rh, step):
                gray_row = 0
                for x in range(0, rw, step):
                    r, g, b = pix[x, y]
                    if 50 < r < 145 and abs(r - g) < 14 and abs(r - b) < 14:
                        gray_row += 1
                    if b > 130 and b > r * 1.25 and b > g * 1.10:
                        blue += 1
                    # PHIS 正常頁的主背景是偏淡綠；條件刻意放寬以容忍螢幕/縮放差異。
                    if g > 145 and r > 100 and g >= r * 0.95 and g > b * 1.03:
                        pale_green += 1
                    if r > 235 and g > 235 and b > 235:
                        white += 1
                max_gray_row_ratio = max(max_gray_row_ratio, gray_row / sampled_cols)

            sampled_total = max(1, sampled_cols * sampled_rows)
            blue_ratio = blue / sampled_total
            green_ratio = pale_green / sampled_total
            white_ratio = white / sampled_total
            stats = {
                "gray_row": max_gray_row_ratio,
                "blue": blue_ratio,
                "green": green_ratio,
                "white": white_ratio,
            }

            # 正常功能頁：綠底或藍色功能連結很明顯。先判正常，避免灰線誤判。
            if green_ratio >= 0.20 or blue_ratio >= 0.018:
                return "menu_like", stats

            # Server Error：必須同時具有大片白底、寬灰列，且缺乏 PHIS 正常綠/藍特徵。
            if (
                max_gray_row_ratio >= 0.48
                and white_ratio >= 0.52
                and green_ratio < 0.18
                and blue_ratio < 0.018
            ):
                return "server_error", stats

            return "unknown", stats
        except Exception:
            return "unknown", {}

    @staticmethod
    def _snapshot_is_server_error(snap) -> bool:
        if not snap:
            return False
        dom_title = normalize_text(snap.get("title", ""))
        dom_text = normalize_text(snap.get("text", ""))
        return bool(
            "500" in dom_title or "servererror" in dom_title
            or "servererror" in dom_text or "internalservererror" in dom_text
            or "內部伺服器錯誤" in dom_text
        )

    def _is_server_error(self, snapshot=None) -> bool:
        """判斷是否真的為 Server Error；v3.0.3 先讀 DOM。"""
        snap = self._dom_snapshot() if snapshot is None else snapshot
        if snap:
            dom_title = normalize_text(snap.get("title", ""))
            dom_text = normalize_text(snap.get("text", ""))
            if ("500" in dom_title or "servererror" in dom_title or
                    "servererror" in dom_text or "internalservererror" in dom_text or
                    "內部伺服器錯誤" in dom_text):
                return True
            if "門診醫療子系統" in (snap.get("text", "") or ""):
                return False

        title = normalize_text(self.title())
        if "500" in title or "servererror" in title or "內部伺服器錯誤" in title:
            return True

        doc = self.document()
        if doc:
            # 明確錯誤文字永遠優先。
            if scope_contains(doc, ["Server Error"]) or scope_contains(doc, ["Internal server error"]):
                return True

            # v2.1.5 關鍵修正：只要實際 DOM/UIA 已看到正常 PHIS 功能選單，
            # 就不再因畫面色塊誤判而 Ctrl+R。
            try:
                if scope_contains(doc, ["門診醫療子系統"]):
                    return False
                if scope_contains(doc, ["功能選單"]) and (
                    scope_contains(doc, ["門診醫療子系統"])
                    or scope_contains(doc, ["保健個案子系統"])
                ):
                    return False
            except Exception:
                pass

        visual, stats = self._visual_page_state()
        if visual == "menu_like":
            return False
        if visual == "server_error":
            self.log.write(
                "畫面符合 Server Error 強特徵"
                f"（白底={stats.get('white', 0):.2f}, 綠底={stats.get('green', 0):.2f}, "
                f"藍色={stats.get('blue', 0):.3f}, 灰列={stats.get('gray_row', 0):.2f}）。"
            )
            return True
        return False

    def _is_function_page(self, snapshot=None, dom_only=False) -> bool:
        """判斷 PHIS 已正常登入。

        v3.1.6 除了舊版功能選單，也直接辨識使用者實機截圖中的 PHIS 首頁。
        只要已離開 Login/Server Error 且出現正常首頁特徵，就立即視為登入成功，
        不再傻等舊的「門診醫療子系統」文字。
        """
        snap = self._dom_snapshot() if snapshot is None else snapshot
        if snap:
            body = snap.get("text", "") or ""
            nt = normalize_text(body)
            title_raw = snap.get("title", "") or ""
            title_nt = normalize_text(title_raw)

            # 明確錯誤 / 登入頁先排除。
            if (
                "servererror" in nt
                or "internalservererror" in nt
                or "內部伺服器錯誤" in nt
                or "500" in title_nt
            ):
                return False

            if snap.get("hasPassword"):
                return False

            # 舊版明確功能選單。
            if "門診醫療子系統" in body or (
                "功能選單" in body
                and ("保健個案子系統" in body or "門診醫療" in body)
            ):
                return True

            # v3.1.6：直接辨識目前實機正常 PHIS 首頁。
            # 使用多個首頁特徵組合，避免單一文字誤判。
            homepage_markers = (
                "下載專區",
                "總醫令庫版本",
                "PHIS主機",
                "PHIS 安裝申請單下載",
                "PHIS 報修單下載",
                "每日備份結果",
                "檢驗值匯入excel空白檔",
                "巡診筆電操作手冊",
            )
            homepage_hits = sum(
                1 for marker in homepage_markers
                if normalize_text(marker) in nt
            )

            # 畫面截圖的頁面標題通常是「PHIS門診醫療及保健個案系統」。
            title_markers = (
                "PHIS門診醫療及保健個案系統",
                "門診醫療及保健個案系統",
                "衛生所醫療保健資訊服務系統",
                "PrimaryHealthInformationSystem",
            )
            title_hit = any(
                normalize_text(marker) in title_nt
                for marker in title_markers
            )

            if homepage_hits >= 2 or (title_hit and homepage_hits >= 1):
                self.log.write(
                    f"已由 PHIS 正常首頁特徵立即確認登入成功"
                    f"（首頁特徵命中 {homepage_hits} 項）。"
                )
                return True

        # Fast polling uses DOM markers only; slower UIA/visual fallback is
        # invoked periodically when the page state remains ambiguous.
        if dom_only:
            return False

        # UIA/title fallback.
        title = normalize_text(self.title())
        function_title_markers = (
            "門診醫保健個案子系統",
            "門診醫療保健個案子系統",
            "保健個案子系統",
            "個案子系統",
            "PHIS門診醫療及保健個案系統",
            "門診醫療及保健個案系統",
        )
        title_ok = any(
            normalize_text(marker) in title
            for marker in function_title_markers
        )

        doc = self.document()
        if doc:
            try:
                if scope_contains(doc, ["門診醫療子系統"]):
                    return True
                if scope_contains(doc, ["下載專區"]) and (
                    scope_contains(doc, ["總醫令庫版本"])
                    or scope_contains(doc, ["PHIS 安裝申請單下載"])
                ):
                    self.log.write("已由 UIA 首頁特徵立即確認 PHIS 登入成功。")
                    return True
            except Exception:
                pass

        if self._is_server_error():
            return False

        visual, _ = self._visual_page_state()
        return bool(title_ok and visual == "menu_like")

    def _wait_for_function_click_page(self, timeout: float = 20.0, context: str = "") -> bool:
        """先確認真的在 PHIS 功能點選畫面，才允許後續關鍵字搜尋。

        連續兩次（間隔 1 秒）都判定正常才算通過，避免剛換頁的瞬間誤判。
        """
        self._ensure_maximized()
        deadline = time.time() + timeout
        stable = 0
        last_state_log = 0.0
        while time.time() < deadline:
            if self._is_server_error():
                if time.time() - last_state_log > 1.5:
                    prefix = f"（{context}）" if context else ""
                    self.log.write(prefix + "目前不是 PHIS 功能點選畫面：偵測到 Server Error，暫停關鍵字搜尋。")
                    last_state_log = time.time()
                return False

            if self._is_function_page():
                stable += 1
                if stable >= 2:
                    prefix = f"（{context}）" if context else ""
                    self.log.write(prefix + "已確認正確進入 PHIS 功能點選畫面，現在才開始搜尋/點擊關鍵字。")
                    return True
            else:
                stable = 0
            time.sleep(1.0)
        return False

    def _recover_function_click_page(self):
        """從 Server Error/未知頁返回設定的 PHIS，重新登入到功能點選頁。"""
        self.log.write("功能點選頁檢查未通過，返回設定的 PHIS 網址重新恢復，不在錯誤頁操作關鍵字。")
        self.reopen_configured_phis()
        time.sleep(1.5)

        # 若直接回到正常功能頁（例如 session 尚有效），不需要重新輸入帳密。
        if self._wait_for_function_click_page(timeout=5.0, context="重新返回 PHIS 後"):
            return

        # 若此刻是 Server Error，交給既有登入等待流程反覆重新載入；
        # Server Error 消失後它會在舊頁面 UIA 不可見時使用固定登入欄位。
        if self._is_server_error():
            self.wait_login_with_server_retry()
            return

        if self._is_login_page():
            self.fill_login()
        elif self._is_login_rejected_page():
            self.reopen_configured_phis()
            time.sleep(1.2)
            if not self._is_server_error():
                self.fill_login(force_fixed=True, reason="恢復功能點選頁")
        else:
            # 根網址常能看到登入畫面，但舊 ASP 不一定暴露 UIA 欄位。
            self.fill_login(force_fixed=True, reason="恢復功能點選頁")
        self.wait_login_with_server_retry()

    def _is_login_page(self, snapshot=None) -> bool:
        """Return True for the actual PHIS login form; v3.0.3 uses DOM first."""
        snap = self._dom_snapshot() if snapshot is None else snapshot
        if snap and snap.get("hasPassword"):
            txt = normalize_text(snap.get("text", ""))
            if "使用者代號或密碼輸入錯誤" not in txt and "帳號已停用" not in txt:
                return True

        doc = self.document()
        if not doc:
            return False
        # The original login form exposes Login + 帳號/密碼.  Some Chrome/UIA
        # builds expose only part of the text, so accept either 帳號 or 密碼.
        has_login = scope_contains(doc, ["Login"])
        has_field_label = scope_contains(doc, ["帳號"]) or scope_contains(doc, ["密碼"])
        return bool(has_login and has_field_label)

    def _is_login_rejected_page(self, snapshot=None) -> bool:
        """Detect the PHIS page shown after a rejected/disabled login.

        User-provided screenshot contains:
        「使用者代號或密碼輸入錯誤,請重新登錄。」以及
        「帳號已停用，請詢問業務承辦人。」
        The page has no login controls, so older versions waited forever.
        """
        snap = self._dom_snapshot() if snapshot is None else snapshot
        if snap:
            raw = snap.get("text", "") or ""
            nt = normalize_text(raw)
            if ("使用者代號或密碼輸入錯誤" in raw or "請重新登錄" in raw or
                    "帳號已停用" in raw or "請詢問業務承辦人" in raw or
                    ("使用者代號" in raw and "密碼" in raw and "輸入錯誤" in raw)):
                return True

        doc = self.document()
        if not doc:
            return False
        phrases = (
            ("使用者代號", "密碼", "輸入錯誤"),
            ("請重新登錄",),
            ("帳號已停用",),
            ("請詢問業務承辦人",),
        )
        for phrase in phrases:
            try:
                if scope_contains(doc, list(phrase)):
                    return True
            except Exception:
                pass
        return False

    def reopen_configured_phis(self):
        """Navigate back to PHIS through Chrome DevTools, without keyboard/coordinates."""
        self._ensure_maximized()
        self.log.write(f"透過瀏覽器底層導向設定的 PHIS 網址：{self.s.url}")
        try:
            self._cdp_navigate(self.s.url)
        except Exception as e:
            raise RuntimeError(f"DevTools 導向 PHIS 失敗：{e}")
        time.sleep(0.12)

    def wait_login_with_server_retry(self):
        self.log.write(
            "快速檢查 PHIS 登入狀態；DOM 每 0.06 秒輪詢，只有狀態不明時才執行 UIA/畫面備援。"
        )
        attempt = 0
        rejected_attempt = 0
        saw_server_error = False
        unknown_since = None
        last_forced_login = 0.0
        forced_login_count = 0
        last_full_check = 0.0

        while True:
            time.sleep(LOGIN_STATE_POLL_SECONDS)
            now = time.time()
            snap = self._dom_snapshot()

            if self._is_function_page(snapshot=snap, dom_only=True):
                self.log.write(
                    f"DOM 已確認 PHIS 登入成功；Server Error 重試次數：{attempt}；"
                    f"登入錯誤頁重試次數：{rejected_attempt}。"
                )
                return

            # Server Error is handled immediately from its DOM title/body.
            if self._snapshot_is_server_error(snap):
                attempt += 1
                saw_server_error = True
                unknown_since = None
                self.log.write(f"偵測到 Server Error，第 {attempt} 次立即刷新。")
                state = self._recover_server_error_fast(
                    stage=f"登入等待階段 Server Error 第 {attempt} 次"
                )
                if state == "function":
                    self.log.write("Server Error 恢復後已直接進入功能頁。")
                    return
                if state == "login":
                    self.fill_login(reason="Server Error 快速恢復後")
                continue

            # Give the submitted request time to complete before considering a
            # retry. This prevents rapid duplicate credential submissions.
            if snap and snap.get("hasPassword"):
                if now - self._last_login_submit_at >= 1.2:
                    saw_server_error = False
                    unknown_since = None
                    self.log.write("登入表單仍在；逾時未跳頁，重新送出 DOM 登入。")
                    self.fill_login(reason="登入表單未離開")
                continue

            # Full UIA/visual checks are more expensive; throttle them while the
            # page is loading. DOM success and Server Error checks stay immediate.
            if now - last_full_check >= 0.45:
                last_full_check = now
                if self._is_function_page(snapshot=snap):
                    self.log.write(
                        f"PHIS 登入成功；Server Error 重試次數：{attempt}；"
                        f"登入錯誤頁重試次數：{rejected_attempt}"
                    )
                    return

                if self._is_server_error(snapshot=snap):
                    attempt += 1
                    saw_server_error = True
                    unknown_since = None
                    self.log.write(f"偵測到 PHIS Server Error，第 {attempt} 次立即刷新。")
                    state = self._recover_server_error_fast(
                        stage=f"登入等待階段 Server Error 第 {attempt} 次"
                    )
                    if state == "function":
                        self.log.write("Server Error 恢復後已直接進入功能頁。")
                        return
                    if state == "login":
                        self.fill_login(reason="Server Error 快速恢復後")
                    continue

                if self._is_login_rejected_page(snapshot=snap):
                    rejected_attempt += 1
                    saw_server_error = False
                    unknown_since = None
                    self.log.write(
                        f"偵測到 PHIS 帳密錯誤／帳號停用提示，第 {rejected_attempt} 次返回登入頁。"
                    )
                    if rejected_attempt > 5:
                        raise RuntimeError(
                            "已連續 5 次回到 PHIS 登入頁並重新登入，仍收到帳密錯誤/帳號停用提示。"
                            "為避免持續嘗試造成帳號鎖定，已停止。請先確認『基本設定』中的帳號密碼。"
                        )
                    self.reopen_configured_phis()
                    deadline = time.time() + 10
                    filled = False
                    while time.time() < deadline:
                        current = self._dom_snapshot()
                        if self._snapshot_is_server_error(current):
                            saw_server_error = True
                            break
                        if current.get("hasPassword"):
                            self.log.write("已回到 PHIS 登入頁，重新填入已儲存的帳號密碼。")
                            self.fill_login()
                            filled = True
                            break
                        time.sleep(0.10)
                    if not filled and not saw_server_error:
                        self.log.write("登入頁仍未辨識；改由 DOM 等待表單並重新送出登入。")
                        self.fill_login(reason="登入錯誤頁返回後")
                    continue

                if self._is_login_page(snapshot=snap):
                    saw_server_error = False
                    unknown_since = None
                    if now - self._last_login_submit_at >= 1.2:
                        self.log.write("偵測到 PHIS 登入頁；重新送出帳密。")
                        self.fill_login()
                    continue

            if saw_server_error:
                if unknown_since is None:
                    unknown_since = now
                    self.log.write("Server Error 已消失，等待登入頁或功能頁 DOM 就緒。")
                    continue
                if now - unknown_since >= 1.0 and now - last_forced_login >= 8.0:
                    forced_login_count += 1
                    last_forced_login = now
                    unknown_since = None
                    saw_server_error = False
                    self.log.write(
                        f"Server Error 後頁面已恢復；第 {forced_login_count} 次直接以 DOM 重新檢查登入表單。"
                    )
                    self.fill_login(reason="Server Error 恢復後")
                    continue

            if now - last_full_check < 0.10:
                continue
            self.log.write(f"等待 PHIS 登入狀態：{self.title() or '頁面載入中'}")

    def _click_phis_menu_item(self, label: str, variants: Sequence[str], fallback_name: str) -> bool:
        """先確認功能點選頁，再以文字名稱點 PHIS 選單。

        回傳 False 代表頁面在搜尋/點擊前已失效（例如變成 Server Error），
        呼叫端會回到 PHIS 重新登入並從第一層重新開始。
        """
        self._ensure_maximized()
        if not self._wait_for_function_click_page(timeout=8.0, context=f"準備操作 {label}"):
            return False

        self._ensure_maximized()
        try:
            self.win.set_focus()
        except Exception:
            pass
        time.sleep(0.25)

        # 只有通過上面的功能點選頁確認後，才開始關鍵字搜尋。
        self.log.write(f"頁面確認正常，開始搜尋關鍵字「{label}」。")
        clicked = False
        doc = self.document()
        if doc:
            # 先找完整、含編號的文字，可避免「掛號作業」匹配到其下層其他項目。
            for text in variants:
                if click_keyword(
                    doc, [text], self.log,
                    control_types=("Hyperlink", "Text", "Button", "Custom"),
                    timeout=2.5,
                ):
                    clicked = True
                    self.log.write(f"已依畫面文字點擊「{label}」。")
                    break

            # 某些舊式 ASP 連結 control_type 很怪，再不限制類型快速試一次。
            if not clicked:
                for text in variants:
                    if click_keyword(doc, [text], self.log, timeout=1.2):
                        clicked = True
                        self.log.write(f"已依畫面文字點擊「{label}」（舊式控制項）。")
                        break

        # 關鍵字搜尋期間若頁面剛好變成 Server Error，絕對不做備援點擊。
        if self._is_server_error():
            self.log.write(f"搜尋「{label}」期間頁面變成 Server Error，取消本次點擊。")
            return False

        if not clicked:
            # 再確認一次仍在正常功能頁，才允許使用固定位置備援。
            if not self._wait_for_function_click_page(timeout=4.0, context=f"{label} 備援點擊前"):
                return False
            self.log.write(
                f"已確認仍在 PHIS 功能點選頁；網頁未暴露「{label}」可點控制項，"
                "才改用 1920×1080 / 125% 影片位置備援。"
            )
            self._click_browser_fallback(fallback_name)

        self.log.write(f"「{label}」已操作，等待 {ACTION_DELAY_SECONDS:g} 秒再進行下一步。")
        time.sleep(ACTION_DELAY_SECONDS)

        # 每一步完成後立即檢查，避免前一步引發 Server Error 卻仍一路點到底。
        if self._is_server_error():
            self.log.write(f"「{label}」操作後偵測到 Server Error，停止後續關鍵字搜尋並準備恢復。")
            return False
        return True

    def click_menu_path(self):
        """先確認功能點選頁，再依影片四層順序展開；失效則恢復後重頭開始。"""
        steps = [
            (
                "1.門診醫療子系統",
                ("1.門診醫療子系統", "門診醫療子系統"),
                "menu_outpatient",
            ),
            (
                "1.掛號作業",
                ("1.掛號作業",),
                "menu_registration",
            ),
            (
                "1.IC健保卡掛號作業",
                ("1.IC健保卡掛號作業", "IC健保卡掛號作業"),
                "menu_ic_registration",
            ),
            (
                "7.IC 健保卡日上傳2.0",
                ("7.IC 健保卡日上傳2.0", "7.IC健保卡日上傳2.0", "IC健保卡日上傳2.0"),
                "menu_daily_upload",
            ),
        ]

        self._ensure_maximized()
        try:
            self.win.set_focus()
        except Exception:
            pass
        press_key("esc")
        time.sleep(0.5)

        recovery_count = 0
        while True:
            # 使用者指定：一定要先確認真的看到 PHIS 功能點選畫面，才做任何關鍵字搜尋。
            if not self._wait_for_function_click_page(timeout=10.0, context="開始功能選單流程前"):
                recovery_count += 1
                self.log.write(f"第 {recovery_count} 次功能頁恢復：尚未確認正常功能點選畫面。")
                self._recover_function_click_page()
                continue

            self.log.write(
                "已確認 PHIS 功能點選頁正常，現在開始依影片操作："
                "1.門診醫療子系統 → 1.掛號作業 → 1.IC健保卡掛號作業 → "
                f"7.IC 健保卡日上傳2.0。主要步驟間隔約 {ACTION_DELAY_SECONDS:g} 秒。"
            )

            ok = True
            for label, variants, fallback_name in steps:
                if not self._click_phis_menu_item(label, variants, fallback_name):
                    ok = False
                    break

            if ok:
                self.log.write("已點按「7.IC 健保卡日上傳2.0」，等待 IC卡資料上傳作業(2.0) 啟動。")
                return

            recovery_count += 1
            self.log.write(
                f"第 {recovery_count} 次：功能選單操作途中頁面失效/Server Error。"
                "不再繼續搜尋後續關鍵字，回到 PHIS 重新登入後從第一層重做。"
            )
            self._recover_function_click_page()


    def close_opened_window(self, timeout: float = 6.0):
        """Close every Chrome window in this cycle's isolated PHIS profile."""
        hwnd = int(self.hwnd or 0)
        pid = int(self.chrome_pid or 0)
        if os.name != "nt":
            return False
        user32 = ctypes.windll.user32

        def owned_windows():
            found = []
            for item in enum_chrome_windows():
                if pid and int(item.get("pid") or 0) == pid:
                    found.append(int(item.get("hwnd") or 0))
            if hwnd and user32.IsWindow(hwnd) and hwnd not in found:
                found.append(hwnd)
            return [h for h in found if h]

        windows = owned_windows()
        if windows:
            self.log.write(
                f"關閉本次專用 Chrome 的 PHIS 頁面／視窗（共 {len(windows)} 個）。"
            )
            for target in windows:
                try:
                    user32.PostMessageW(target, 0x0010, 0, 0)  # WM_CLOSE
                except Exception:
                    pass

        deadline = time.time() + max(0.5, timeout)
        while time.time() < deadline:
            if not owned_windows():
                self.log.write("本次專用 Chrome 的 PHIS 頁面與視窗已全部關閉。")
                return True
            time.sleep(0.10)

        # The Chrome profile is unique to this run. If pages/windows remain,
        # terminate only the process tree launched for this profile.
        if pid and owned_windows():
            self.log.write(
                f"仍有 PHIS Chrome 視窗未關閉；結束本次專用 PID {pid} 的程序樹。"
            )
            for force in (False, True):
                try:
                    cmd = ["taskkill", "/PID", str(pid), "/T"]
                    if force:
                        cmd.append("/F")
                    subprocess.run(cmd, capture_output=True, text=True, timeout=4)
                except Exception:
                    pass
                deadline = time.time() + 2.0
                while time.time() < deadline:
                    if not owned_windows():
                        self.log.write("本次專用 Chrome 的 PHIS 頁面與視窗已全部關閉。")
                        return True
                    time.sleep(0.10)

        if not owned_windows():
            return True
        self.log.write("錯誤：仍有本次專用 PHIS Chrome 頁面或視窗未關閉。")
        return False



# ----------------------- Official PhisSocket / InetLoader launcher -----------------------
class PhisSocketLauncher:
    """Use the same local launcher chain as the PHIS web page.

    This class is intentionally called only AFTER ChromePHIS has confirmed a
    successful, normal PHIS login.  It does not bypass PHIS authentication.
    It replaces only the fragile four-level web-menu clicking step.

    Captured official wire format:
      GetMessage:<host>,Clinic\\ExchNHIMgrDMU.exe,<display_name>,<base64_password>,<user_id>,<level>,7.IC 健保卡日上傳2.0
    """

    HOST = "127.0.0.1"
    PORT = 7788
    PATH = "/CIP"
    MODULE = r"Clinic\ExchNHIMgrDMU.exe"
    FUNCTION_LABEL = "7.IC 健保卡日上傳2.0"

    def __init__(self, settings: Settings, logger: Logger):
        self.s = settings
        self.log = logger

    def _server_host(self) -> str:
        raw = (self.s.url or DEFAULT_URL).strip()
        try:
            parsed = urlparse(raw if "://" in raw else "http://" + raw)
            host = (parsed.hostname or "").strip()
        except Exception:
            host = ""
        if not host:
            m = re.search(r"(?:(?:https?://)?)([^/:]+)", raw, re.I)
            host = m.group(1).strip() if m else ""
        if not host:
            raise RuntimeError("無法從 PHIS 網址判斷伺服器 Host。")
        return host

    @staticmethod
    def _port_open(host="127.0.0.1", port=7788, timeout=0.4) -> bool:
        try:
            with socket.create_connection((host, port), timeout=timeout):
                return True
        except OSError:
            return False

    def _find_phissocket(self) -> Optional[Path]:
        candidates = [
            Path(r"C:\phis2000\PhisSocket.exe"),
            Path(r"C:\phis2000\PHISSocket.exe"),
            BASE_DIR / "PhisSocket.exe",
        ]
        for candidate in candidates:
            try:
                if candidate.exists():
                    return candidate
            except Exception:
                pass

        root = Path(r"C:\phis2000")
        try:
            if root.exists():
                for candidate in root.rglob("PhisSocket.exe"):
                    if candidate.is_file():
                        return candidate
        except Exception:
            pass
        return None

    def ensure_running(self):
        if self._port_open(self.HOST, self.PORT):
            self.log.write("已確認官方 PhisSocket 正在監聽 127.0.0.1:7788。")
            return

        exe = self._find_phissocket()
        if not exe:
            raise RuntimeError(
                "未偵測到 PhisSocket 監聽服務，也找不到 C:\\phis2000\\PhisSocket.exe。"
                "請確認 PHISSocket 已安裝。"
            )

        self.log.write(f"PhisSocket 尚未啟動，正在啟動官方 Launcher：{exe}")
        try:
            subprocess.Popen(
                [str(exe)],
                cwd=str(exe.parent),
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
        except Exception as e:
            raise RuntimeError(f"啟動 PhisSocket 失敗：{e}")

        deadline = time.time() + 12.0
        while time.time() < deadline:
            if self._port_open(self.HOST, self.PORT):
                self.log.write("PhisSocket 已啟動並開始監聽。")
                return
            time.sleep(0.4)
        raise RuntimeError("已啟動 PhisSocket，但 12 秒內仍未開始監聽 127.0.0.1:7788。")

    @staticmethod
    def _recv_http_headers(sock_obj: socket.socket, timeout=4.0) -> bytes:
        sock_obj.settimeout(timeout)
        buf = bytearray()
        while b"\r\n\r\n" not in buf and len(buf) < 65536:
            chunk = sock_obj.recv(4096)
            if not chunk:
                break
            buf.extend(chunk)
        return bytes(buf)

    @staticmethod
    def _masked_frame(payload: bytes, opcode: int = 0x1) -> bytes:
        # RFC6455: client -> server frames MUST be masked.
        fin_opcode = 0x80 | (opcode & 0x0F)
        mask = os.urandom(4)
        length = len(payload)
        if length < 126:
            header = bytes([fin_opcode, 0x80 | length])
        elif length <= 0xFFFF:
            header = bytes([fin_opcode, 0x80 | 126]) + struct.pack("!H", length)
        else:
            header = bytes([fin_opcode, 0x80 | 127]) + struct.pack("!Q", length)
        masked = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
        return header + mask + masked

    def _send_websocket_text(self, message: str):
        host = self.HOST
        port = self.PORT
        server_host = self._server_host()
        ws_key = base64.b64encode(os.urandom(16)).decode("ascii")
        request = (
            f"GET {self.PATH} HTTP/1.1\r\n"
            f"Host: {host}:{port}\r\n"
            "Upgrade: websocket\r\n"
            "Connection: Upgrade\r\n"
            f"Sec-WebSocket-Key: {ws_key}\r\n"
            "Sec-WebSocket-Version: 13\r\n"
            f"Origin: http://{server_host}\r\n"
            "\r\n"
        ).encode("ascii", errors="ignore")

        try:
            with socket.create_connection((host, port), timeout=4.0) as s:
                s.sendall(request)
                resp = self._recv_http_headers(s)
                first = resp.split(b"\r\n", 1)[0].decode("latin1", errors="replace")
                if " 101 " not in f" {first} ":
                    raise RuntimeError(f"PhisSocket WebSocket 握手失敗：{first or '沒有回應'}")
                s.sendall(self._masked_frame(message.encode("utf-8"), opcode=0x1))
                # Give PhisSocket time to enter ProcessCommand/ExecuteInetloader.
                time.sleep(0.35)
                try:
                    s.sendall(self._masked_frame(b"", opcode=0x8))
                except Exception:
                    pass
        except RuntimeError:
            raise
        except Exception as e:
            raise RuntimeError(f"傳送官方 PhisSocket 啟動命令失敗：{e}")

    def launch_daily_upload(self):
        display_name = (self.s.display_name or "").strip()
        user_id = (self.s.username or "").strip()
        password = self.s.password or ""
        level = (self.s.permission_level or "5").strip()

        if not display_name:
            raise RuntimeError("尚未設定『PHIS 使用者姓名』，無法建立官方 Launcher 啟動參數。")
        if not user_id or not password:
            raise RuntimeError("PHIS 帳號或密碼為空，無法建立官方 Launcher 啟動參數。")
        if "," in display_name or "," in user_id or "," in level:
            raise RuntimeError("使用者姓名／帳號／權限代碼不可包含逗號。")

        self.ensure_running()
        server_host = self._server_host()
        encoded_password = base64.b64encode(password.encode("utf-8")).decode("ascii")
        message = (
            f"GetMessage:{server_host},{self.MODULE},"
            f"{display_name},{encoded_password},{user_id},{level},"
            f"{self.FUNCTION_LABEL}"
        )

        # Never log the recoverable password value.
        self.log.write(
            "已正常登入 PHIS；準備透過官方 PhisSocket / InetLoader 啟動健保卡日上傳2.0。"
        )
        self.log.write(
            f"官方啟動參數：Host={server_host}，Module={self.MODULE}，"
            f"UserName={display_name}，UserId={user_id}，Level={level}，Password=[已遮蔽]"
        )
        self._send_websocket_text(message)
        self.log.write("已送出官方 GetMessage 啟動命令；等待 IC卡資料上傳作業(2.0) 視窗。")


# ----------------------- Native uploader automation -----------------------
class NativeUploader:
    """Automate the legacy IC card uploader.

    Important v1.9 change: the uploader is not reliably exposed by Chrome/UIA.
    It may already be clearly visible while Desktop(backend="uia") returns no
    matching top-level window.  We therefore discover it by both UIA and raw
    Win32 HWND, attach whichever pywinauto backend works, explicitly switch it
    to foreground/maximized, and only then use toolbar-name or coordinate
    fallback clicks.
    """

    TITLE_KEYWORDS = ("IC卡資料上傳作業", "IC卡資料上傳")

    # Confirmed from the embedded Delphi TActionList in ExchNHIMgrDMU.exe.
    DELPHI_ACTIONS = {
        "查詢": ("actnQuery", "&Q查詢", "actnQueryExecute"),
        "全選": ("actnFunc1", "全選", "actnFunc1Execute"),
        "一鍵上傳": ("actnFunc3", "一鍵上傳", "actnFunc3Execute"),
        "結束": ("actnExit", "&X結束", "actnExitExecute"),
    }

    # These offsets were recovered from the exact ExchNHIMgrDMU.exe supplied by
    # the user.  We only use them when the on-disk EXE SHA-256 matches exactly.
    # They are fields on TServiceBaseForm/TFrmNHIMgrDMU and contain pointers to
    # the already-created TAction instances in the target process.
    VCL_ACTION_FIELD_OFFSETS = {
        "查詢": 0x03BC,       # actnQuery
        "結束": 0x03D8,       # actnExit
        "全選": 0x03DC,       # actnFunc1
        "一鍵上傳": 0x03E4,   # actnFunc3
    }

    EXPECTED_EXCH_SHA256 = (
        "a565a31f4dbe1bd2156a5c4d11676b6"
        "eb7cbca886c3871d08e4f730d7b7809f3"
    )

    # Vcl.Controls.CM_ACTIONEXECUTE
    CM_ACTIONEXECUTE = 0xB040

    # The recovered VCL contains the XE2+ registered-message name.
    RM_GET_OBJECT_INSTANCE_NAME = "DelphiRM_GetObjectInstance"

    def __init__(self, settings: Settings, logger: Logger):
        self.s = settings
        self.log = logger
        self.win = None          # best available wrapper, usually UIA
        self.win_uia = None
        self.win_win32 = None
        self.hwnd = 0
        self.title = ""
        # v3.0.4: runtime-discovered native toolbar command map.
        self.toolbar_hwnd = 0
        self.toolbar_commands = {}
        self.toolbar_button_dump = []
        self._vcl_form_ptr = 0
        self._vcl_target_pid = 0
        self._vcl_exe_path = ""
        self._vcl_hash_ok = None

    def _desktop(self, backend="uia"):
        from pywinauto import Desktop
        return Desktop(backend=backend)

    def _title_matches(self, title: str) -> bool:
        nt = normalize_text(title)
        return any(normalize_text(k) in nt for k in self.TITLE_KEYWORDS)

    def _attach_hwnd(self, hwnd: int, title: str = "") -> bool:
        if not hwnd:
            return False
        self.hwnd = int(hwnd)
        self.title = title or self.title
        self.toolbar_hwnd = 0
        self.toolbar_commands = {}
        self.toolbar_button_dump = []
        self._vcl_form_ptr = 0
        self._vcl_target_pid = 0
        self._vcl_exe_path = ""
        self._vcl_hash_ok = None
        self.win_uia = None
        self.win_win32 = None

        # First try UIA attached to the exact HWND.  This is more reliable than
        # enumerating the UIA desktop for this particular legacy application.
        try:
            self.win_uia = self._desktop("uia").window(handle=self.hwnd).wrapper_object()
        except Exception:
            self.win_uia = None

        # Always also try the Win32 backend; toolbar/buttons and modal dialogs
        # in this program are often exposed better through classic Win32.
        try:
            self.win_win32 = self._desktop("win32").window(handle=self.hwnd).wrapper_object()
        except Exception:
            self.win_win32 = None

        self.win = self.win_uia or self.win_win32
        return bool(self.win or self.hwnd)

    def _activate(self, maximize=True):
        if not self.hwnd and self.win is not None:
            try:
                self.hwnd = int(self.win.handle)
            except Exception:
                pass

        if self.hwnd:
            activate_hwnd(self.hwnd, maximize=maximize)
        for w in (self.win_uia, self.win_win32, self.win):
            if w is None:
                continue
            try:
                if maximize:
                    try:
                        w.maximize()
                    except Exception:
                        pass
                w.set_focus()
                break
            except Exception:
                continue
        if self.hwnd:
            activate_hwnd(self.hwnd, maximize=maximize)
        time.sleep(0.08)

    def _foreground_is_uploader(self) -> bool:
        title = foreground_window_title()
        if self._title_matches(title):
            return True
        if self.hwnd and os.name == "nt":
            try:
                return int(ctypes.windll.user32.GetForegroundWindow() or 0) == int(self.hwnd)
            except Exception:
                pass
        return False

    def wait_window(self, timeout=30):
        self.log.write(
            "已點開 IC 健保卡日上傳2.0；開始用 UIA + Win32 視窗標題雙重偵測「IC卡資料上傳作業(2.0)」。"
        )
        deadline = time.time() + timeout
        last_win32 = []
        while time.time() < deadline:
            # Route 1: regular UIA enumeration.
            try:
                for w in self._desktop("uia").windows():
                    title = _safe_name(w)
                    if self._title_matches(title):
                        try:
                            hwnd = int(w.handle)
                        except Exception:
                            hwnd = 0
                        self.win_uia = w
                        self.win = w
                        self.hwnd = hwnd
                        self.title = title
                        if hwnd:
                            self._attach_hwnd(hwnd, title)
                        self._activate(maximize=True)
                        self.log.write(
                            f"已偵測並切換到上傳軟體視窗：{title or 'IC卡資料上傳作業(2.0)'}"
                            + (f"（HWND={self.hwnd}）" if self.hwnd else "")
                        )
                        time.sleep(0.25)
                        return
            except Exception:
                pass

            # Route 2: raw Win32 EnumWindows.  This is the key v1.9 fallback.
            try:
                wins = enum_top_windows()
                last_win32 = wins
                matches = [x for x in wins if self._title_matches(x.get("title", ""))]
                if matches:
                    # Prefer an exact-looking title and the largest visible window.
                    matches.sort(
                        key=lambda x: (
                            "(2.0)" not in x.get("title", ""),
                            -max(0, x.get("rect", (0,0,0,0))[2] - x.get("rect", (0,0,0,0))[0])
                            * max(0, x.get("rect", (0,0,0,0))[3] - x.get("rect", (0,0,0,0))[1]),
                        )
                    )
                    hit = matches[0]
                    self._attach_hwnd(hit["hwnd"], hit.get("title", ""))
                    self._activate(maximize=True)
                    self.log.write(
                        f"UIA 未列出視窗，但 Win32 已找到並切換到上傳軟體："
                        f"{hit.get('title') or 'IC卡資料上傳作業(2.0)'}（HWND={hit['hwnd']}）"
                    )
                    time.sleep(0.25)
                    return
            except Exception:
                pass

            time.sleep(0.12)

        # Diagnostic titles help distinguish a title mismatch from enumeration failure.
        brief = []
        for x in (last_win32 or enum_top_windows())[-12:]:
            t = x.get("title", "").strip()
            if t:
                brief.append(f"{t} [HWND={x.get('hwnd')}]" )
        if brief:
            self.log.write("逾時前 Win32 可見視窗：" + "；".join(brief[:12]))
        raise RuntimeError("等待/切換到「IC卡資料上傳作業(2.0)」逾時。")

    def _enum_child_hwnds(self):
        if os.name != "nt" or not self.hwnd:
            return []
        user32 = ctypes.windll.user32
        out = []
        WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

        @WNDENUMPROC
        def cb(child, lparam):
            try:
                cls = ctypes.create_unicode_buffer(128)
                user32.GetClassNameW(child, cls, len(cls))
                rect = wintypes.RECT()
                user32.GetWindowRect(child, ctypes.byref(rect))
                out.append({
                    "hwnd": int(child),
                    "class_name": cls.value or "",
                    "rect": (int(rect.left), int(rect.top), int(rect.right), int(rect.bottom)),
                    "visible": bool(user32.IsWindowVisible(child)),
                })
            except Exception:
                pass
            return True

        user32.EnumChildWindows(int(self.hwnd), cb, 0)
        return out

    @staticmethod
    def _send_message_timeout(hwnd: int, msg: int, wparam=0, lparam=0, timeout_ms=500):
        """Return (ok, result) while avoiding hangs in legacy controls."""
        if os.name != "nt" or not hwnd:
            return False, 0
        user32 = ctypes.windll.user32
        result = ctypes.c_size_t(0)
        SMTO_ABORTIFHUNG = 0x0002
        try:
            ok = user32.SendMessageTimeoutW(
                int(hwnd), int(msg), int(wparam), int(lparam),
                SMTO_ABORTIFHUNG, int(timeout_ms), ctypes.byref(result)
            )
            return bool(ok), int(result.value)
        except Exception:
            return False, 0

    def _target_pid_tid(self):
        """Return (pid, GUI-thread-id) for the uploader top-level HWND."""
        if os.name != "nt" or not self.hwnd:
            return 0, 0
        try:
            pid = wintypes.DWORD(0)
            tid = ctypes.windll.user32.GetWindowThreadProcessId(
                int(self.hwnd), ctypes.byref(pid)
            )
            return int(pid.value), int(tid or 0)
        except Exception:
            return 0, 0

    def _target_exe_path(self, pid: int) -> str:
        """Resolve the target process image path without relying on a fixed C: path."""
        if os.name != "nt" or not pid:
            return ""
        kernel32 = ctypes.windll.kernel32
        PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
        kernel32.OpenProcess.restype = ctypes.c_void_p
        hproc = kernel32.OpenProcess(
            PROCESS_QUERY_LIMITED_INFORMATION, False, int(pid)
        )
        if not hproc:
            return ""
        try:
            size = wintypes.DWORD(32768)
            buf = ctypes.create_unicode_buffer(size.value)
            try:
                kernel32.QueryFullProcessImageNameW.argtypes = [
                    ctypes.c_void_p,
                    wintypes.DWORD,
                    wintypes.LPWSTR,
                    ctypes.POINTER(wintypes.DWORD),
                ]
                kernel32.QueryFullProcessImageNameW.restype = wintypes.BOOL
            except Exception:
                pass
            if kernel32.QueryFullProcessImageNameW(
                hproc, 0, buf, ctypes.byref(size)
            ):
                return buf.value
        finally:
            kernel32.CloseHandle(hproc)
        return ""

    @staticmethod
    def _sha256_file(path: str) -> str:
        h = hashlib.sha256()
        with open(path, "rb") as f:
            while True:
                chunk = f.read(1024 * 1024)
                if not chunk:
                    break
                h.update(chunk)
        return h.hexdigest().lower()

    def _verify_vcl_layout_binary(self, pid: int) -> bool:
        """Use hard-coded object-field offsets only for the exact analyzed EXE."""
        if self._vcl_hash_ok is not None and self._vcl_target_pid == pid:
            return bool(self._vcl_hash_ok)

        path = self._target_exe_path(pid)
        self._vcl_exe_path = path
        self._vcl_target_pid = pid
        if not path:
            self._vcl_hash_ok = False
            self.log.write(
                "無法取得 ExchNHIMgrDMU.exe 實際路徑；為安全起見不使用固定 VCL 欄位偏移。"
            )
            return False

        try:
            digest = self._sha256_file(path)
        except Exception as e:
            self._vcl_hash_ok = False
            self.log.write(f"無法驗證 ExchNHIMgrDMU.exe SHA-256：{e}")
            return False

        self._vcl_hash_ok = digest == self.EXPECTED_EXCH_SHA256
        if self._vcl_hash_ok:
            self.log.write(
                "已確認目前 ExchNHIMgrDMU.exe 與分析版本完全一致；"
                "可安全使用已解析的 VCL TAction 欄位偏移。"
            )
        else:
            self.log.write(
                "目前 ExchNHIMgrDMU.exe 與已分析版本不同；"
                "停用硬編碼 VCL Action 偏移，避免錯誤指標。"
            )
        return bool(self._vcl_hash_ok)

    @staticmethod
    def _send_message_timeout_ptr(hwnd: int, msg: int, wparam=0, lparam=0, timeout_ms=1500):
        """Pointer-safe SendMessageTimeoutW wrapper for 64-bit Python -> 32-bit VCL."""
        if os.name != "nt" or not hwnd:
            return False, 0
        user32 = ctypes.windll.user32
        try:
            fn = user32.SendMessageTimeoutW
            fn.argtypes = [
                wintypes.HWND,
                wintypes.UINT,
                wintypes.WPARAM,
                wintypes.LPARAM,
                wintypes.UINT,
                wintypes.UINT,
                ctypes.POINTER(ctypes.c_size_t),
            ]
            fn.restype = wintypes.LPARAM
        except Exception:
            pass

        result = ctypes.c_size_t(0)
        SMTO_ABORTIFHUNG = 0x0002
        try:
            ok = fn(
                int(hwnd),
                int(msg),
                int(wparam),
                int(lparam),
                SMTO_ABORTIFHUNG,
                int(timeout_ms),
                ctypes.byref(result),
            )
            return bool(ok), int(result.value)
        except Exception:
            return False, 0

    def _get_vcl_form_object_pointer(self) -> int:
        """Ask the target VCL window for its own TWinControl/TForm object pointer.

        Unicode VCL versions register the message name
        'DelphiRM_GetObjectInstance'.  The target window handles that message and
        returns Self.  No DLL injection and no remote code execution is used.
        """
        if os.name != "nt" or not self.hwnd:
            return 0
        if self._vcl_form_ptr:
            return int(self._vcl_form_ptr)

        pid, _tid = self._target_pid_tid()
        if not pid:
            return 0

        try:
            user32 = ctypes.windll.user32
            user32.RegisterWindowMessageW.argtypes = [wintypes.LPCWSTR]
            user32.RegisterWindowMessageW.restype = wintypes.UINT
            msg = int(
                user32.RegisterWindowMessageW(self.RM_GET_OBJECT_INSTANCE_NAME)
                or 0
            )
        except Exception:
            msg = 0

        if not msg:
            return 0

        ok, ptr = self._send_message_timeout_ptr(
            self.hwnd, msg, 0, 0, timeout_ms=1500
        )
        if ok and 0x10000 <= ptr <= 0xFFFFFFFF:
            self._vcl_form_ptr = int(ptr)
            self.log.write(
                f"已由 VCL RM_GetObjectInstance 取得 TFrmNHIMgrDMU 物件位址：0x{ptr:08X}。"
            )
            return int(ptr)

        self.log.write(
            "VCL RM_GetObjectInstance 未回傳有效 Form 物件指標。"
        )
        return 0

    @staticmethod
    def _open_process_read(pid: int):
        if os.name != "nt" or not pid:
            return 0
        kernel32 = ctypes.windll.kernel32
        PROCESS_VM_READ = 0x0010
        PROCESS_QUERY_INFORMATION = 0x0400
        PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
        kernel32.OpenProcess.restype = ctypes.c_void_p
        return int(
            kernel32.OpenProcess(
                PROCESS_VM_READ
                | PROCESS_QUERY_INFORMATION
                | PROCESS_QUERY_LIMITED_INFORMATION,
                False,
                int(pid),
            )
            or 0
        )

    @staticmethod
    def _read_process_u32(hproc: int, address: int):
        if not hproc or not address:
            return None
        kernel32 = ctypes.windll.kernel32
        value = ctypes.c_uint32(0)
        nread = ctypes.c_size_t(0)
        try:
            kernel32.ReadProcessMemory.argtypes = [
                ctypes.c_void_p,
                ctypes.c_void_p,
                ctypes.c_void_p,
                ctypes.c_size_t,
                ctypes.POINTER(ctypes.c_size_t),
            ]
            kernel32.ReadProcessMemory.restype = wintypes.BOOL
        except Exception:
            pass
        ok = kernel32.ReadProcessMemory(
            ctypes.c_void_p(hproc),
            ctypes.c_void_p(int(address)),
            ctypes.byref(value),
            ctypes.sizeof(value),
            ctypes.byref(nread),
        )
        if not ok or nread.value != ctypes.sizeof(value):
            return None
        return int(value.value)

    def _vcl_action_pointer(self, logical_name: str):
        """Read the existing target-process TAction pointer from the live Form."""
        offset = self.VCL_ACTION_FIELD_OFFSETS.get(logical_name)
        if offset is None:
            return 0

        pid, _tid = self._target_pid_tid()
        if not pid or not self._verify_vcl_layout_binary(pid):
            return 0

        form_ptr = self._get_vcl_form_object_pointer()
        if not form_ptr:
            return 0

        hproc = self._open_process_read(pid)
        if not hproc:
            self.log.write(
                "無法以唯讀方式開啟 ExchNHIMgrDMU.exe 行程以讀取 TAction 指標。"
            )
            return 0

        kernel32 = ctypes.windll.kernel32
        try:
            action_ptr = self._read_process_u32(
                hproc, int(form_ptr) + int(offset)
            )
            if not action_ptr or not (0x10000 <= action_ptr <= 0xFFFFFFFF):
                self.log.write(
                    f"VCL『{logical_name}』欄位 +0x{offset:04X} "
                    "沒有讀到有效 TAction 指標。"
                )
                return 0

            # Sanity check: every Delphi TObject starts with a readable VMT ptr.
            vmt_ptr = self._read_process_u32(hproc, action_ptr)
            if not vmt_ptr or not (0x10000 <= vmt_ptr <= 0xFFFFFFFF):
                self.log.write(
                    f"VCL『{logical_name}』TAction 指標 0x{action_ptr:08X} "
                    "未通過可讀物件檢查。"
                )
                return 0

            meta = self.DELPHI_ACTIONS.get(logical_name, ("?", "?", "?"))
            self.log.write(
                f"已取得 VCL『{logical_name}』Action：{meta[0]} "
                f"（Form+0x{offset:04X} → 0x{action_ptr:08X}）。"
            )
            return int(action_ptr)
        finally:
            try:
                kernel32.CloseHandle(ctypes.c_void_p(hproc))
            except Exception:
                pass

    def _invoke_vcl_action_direct(self, logical_name: str) -> bool:
        """Execute the real TAction via VCL CM_ACTIONEXECUTE ($B040).

        lParam is the target process' existing TAction pointer.  The receiving
        TCustomForm processes the pointer in its own address space and invokes
        the normal Action/OnExecute path.  We do not allocate or write any target
        memory and do not create a remote thread.
        """
        if os.name != "nt" or not self.hwnd:
            return False

        self._activate(maximize=True)
        action_ptr = self._vcl_action_pointer(logical_name)
        if not action_ptr:
            return False

        ok, result = self._send_message_timeout_ptr(
            self.hwnd,
            self.CM_ACTIONEXECUTE,
            0,
            action_ptr,
            timeout_ms=2500,
        )
        if not ok:
            self.log.write(
                f"送出 VCL CM_ACTIONEXECUTE 給『{logical_name}』失敗或逾時。"
            )
            return False

        meta = self.DELPHI_ACTIONS.get(logical_name, ("?", "?", "?"))
        self.log.write(
            f"已直接送出 VCL CM_ACTIONEXECUTE($B040) 執行『{logical_name}』"
            f"（{meta[0]} / {meta[2]}；Action=0x{action_ptr:08X}；Result={result}）。"
        )
        return True

    def _invoke_vcl_dialog_char(self, char: str, label: str) -> bool:
        """Mnemonic-only fallback for &Q查詢 / &X結束; no mouse involved."""
        if os.name != "nt" or not self.hwnd or not char:
            return False
        CM_DIALOGCHAR = 0xB006
        code = ord(char[0].upper())
        ok, result = self._send_message_timeout_ptr(
            self.hwnd, CM_DIALOGCHAR, code, 0, timeout_ms=1200
        )
        if ok:
            self.log.write(
                f"已送出 VCL CM_DIALOGCHAR『{char.upper()}』作為『{label}』非座標備援"
                f"（Result={result}）。"
            )
            return bool(result)
        return False

    @staticmethod
    def _msaa_norm_name(value) -> str:
        try:
            return normalize_text(str(value or "").replace("&", ""))
        except Exception:
            return ""

    def _msaa_accessible_from_window(self, hwnd: int, objid: int = -4):
        """Return IAccessible for a HWND using Microsoft Active Accessibility."""
        if os.name != "nt" or not hwnd:
            return None
        try:
            from comtypes.client import GetModule
            GetModule("oleacc.dll")
            from comtypes.gen.Accessibility import IAccessible
            ptr = ctypes.POINTER(IAccessible)()
            hr = ctypes.oledll.oleacc.AccessibleObjectFromWindow(
                int(hwnd),
                int(objid),
                ctypes.byref(IAccessible._iid_),
                ctypes.byref(ptr),
            )
            if hr != 0 or not ptr:
                return None
            return ptr
        except Exception:
            return None

    def _msaa_direct_children(self, acc):
        """Yield simple IAccessible child IDs with their name/default action.

        Old Win32/VCL toolbars commonly expose buttons as simple child IDs rather
        than separate HWNDs.  This is exactly the case where UIA/Win32 HWND
        enumeration tends to miss the buttons.
        """
        if acc is None:
            return []
        out = []
        try:
            count = int(acc.accChildCount or 0)
        except Exception:
            count = 0
        count = max(0, min(count, 128))
        for child_id in range(1, count + 1):
            name = ""
            role = None
            default_action = ""
            state = None
            try:
                name = acc.accName(child_id) or ""
            except Exception:
                pass
            try:
                role = acc.accRole(child_id)
            except Exception:
                pass
            try:
                default_action = acc.accDefaultAction(child_id) or ""
            except Exception:
                pass
            try:
                state = acc.accState(child_id)
            except Exception:
                pass
            out.append({
                "acc": acc,
                "child_id": child_id,
                "name": str(name or ""),
                "role": role,
                "default_action": str(default_action or ""),
                "state": state,
            })
        return out

    def _msaa_candidates(self):
        """Collect coordinate-free accessible button candidates from the uploader."""
        candidates = []
        seen = set()

        # The top-level client plus every real child HWND.  For each HWND try
        # both OBJID_CLIENT and OBJID_WINDOW because legacy VCL controls vary.
        hwnds = [int(self.hwnd)] if self.hwnd else []
        for item in self._enum_child_hwnds():
            h = int(item.get("hwnd") or 0)
            if h and h not in hwnds:
                hwnds.append(h)

        for hwnd in hwnds:
            for objid in (-4, 0):  # OBJID_CLIENT, OBJID_WINDOW
                acc = self._msaa_accessible_from_window(hwnd, objid)
                if acc is None:
                    continue

                # The object itself can occasionally be the actionable item.
                try:
                    self_name = acc.accName(0) or ""
                except Exception:
                    self_name = ""
                try:
                    self_action = acc.accDefaultAction(0) or ""
                except Exception:
                    self_action = ""
                key = (hwnd, objid, 0, str(self_name))
                if key not in seen:
                    seen.add(key)
                    candidates.append({
                        "hwnd": hwnd,
                        "objid": objid,
                        "acc": acc,
                        "child_id": 0,
                        "name": str(self_name or ""),
                        "default_action": str(self_action or ""),
                    })

                for child in self._msaa_direct_children(acc):
                    key = (hwnd, objid, child["child_id"], child["name"])
                    if key in seen:
                        continue
                    seen.add(key)
                    child.update({"hwnd": hwnd, "objid": objid})
                    candidates.append(child)

        return candidates

    def _msaa_match_score(self, logical_name: str, item) -> int:
        raw = str(item.get("name") or "")
        n = self._msaa_norm_name(raw)
        if not n:
            return -999

        aliases = {
            "查詢": ("Q查詢", "查詢", "actnQuery"),
            "全選": ("全選", "actnFunc1"),
            "一鍵上傳": ("一鍵上傳", "一鍵", "actnFunc3"),
            "結束": ("X結束", "結束", "actnExit"),
        }.get(logical_name, (logical_name,))

        score = -999
        for alias in aliases:
            a = self._msaa_norm_name(alias)
            if not a:
                continue
            if n == a:
                score = max(score, 200)
            elif a in n:
                score = max(score, 140)
            elif n in a and len(n) >= 2:
                score = max(score, 100)

        da = self._msaa_norm_name(item.get("default_action") or "")
        if da:
            score += 10
        # Prefer descendants over the whole window itself.
        if int(item.get("child_id") or 0) != 0:
            score += 10
        return score

    def _msaa_best_candidate(self, logical_name: str):
        """Return the best MSAA item for a named uploader toolbar command.

        MSAA is used only for discovery. v3.2.5 does NOT trust
        accDoDefaultAction as proof that the Delphi action actually executed.
        """
        candidates = self._msaa_candidates()
        ranked = sorted(
            (
                (self._msaa_match_score(logical_name, item), item)
                for item in candidates
            ),
            key=lambda x: x[0],
            reverse=True,
        )
        if not ranked or ranked[0][0] < 100:
            return None, -999
        return ranked[0][1], ranked[0][0]

    def _accessible_item_screen_rect(self, item):
        """Return the accessible child's screen rectangle.

        comtypes' generated IAccessible.accLocation signature differs from the
        raw COM signature. On this PC it is exposed as:
            left, top, width, height = acc.accLocation(varChild)
        rather than taking four output pointers.
        v3.2.6 supports both forms.
        """
        if not item:
            return None

        acc = item.get("acc")
        child_id = int(item.get("child_id") or 0)
        if acc is None:
            return None

        # Route 1: comtypes bound-method form seen on the user's PC.
        try:
            value = acc.accLocation(child_id)

            # Typical comtypes return: (left, top, width, height)
            if isinstance(value, (tuple, list)) and len(value) >= 4:
                left, top, width, height = [int(x) for x in value[:4]]
                if width > 0 and height > 0:
                    self.log.write(
                        f"已取得『{item.get('name') or '?'}』MSAA 位置："
                        f"left={left}, top={top}, width={width}, height={height}。"
                    )
                    return (
                        left,
                        top,
                        left + width,
                        top + height,
                    )

            # Some wrappers may return an object-like tuple/array.
            try:
                vals = list(value)
                if len(vals) >= 4:
                    left, top, width, height = [int(x) for x in vals[:4]]
                    if width > 0 and height > 0:
                        self.log.write(
                            f"已取得『{item.get('name') or '?'}』MSAA 位置："
                            f"left={left}, top={top}, width={width}, height={height}。"
                        )
                        return (
                            left,
                            top,
                            left + width,
                            top + height,
                        )
            except Exception:
                pass

        except Exception as e:
            self.log.write(
                f"comtypes accLocation(child_id) 方式失敗：{e}；"
                "改試原始 COM 輸出參數方式。"
            )

        # Route 2: raw COM-style output-pointer fallback.
        left = ctypes.c_long(0)
        top = ctypes.c_long(0)
        width = ctypes.c_long(0)
        height = ctypes.c_long(0)

        try:
            from comtypes.automation import VARIANT
            child_variant = VARIANT(child_id)

            # Some generated interfaces expose the underlying method through
            # the interface pointer but still accept output arguments.
            acc.accLocation(
                ctypes.byref(left),
                ctypes.byref(top),
                ctypes.byref(width),
                ctypes.byref(height),
                child_variant,
            )

            if width.value > 0 and height.value > 0:
                self.log.write(
                    f"已由原始 COM 方式取得『{item.get('name') or '?'}』位置："
                    f"left={left.value}, top={top.value}, "
                    f"width={width.value}, height={height.value}。"
                )
                return (
                    int(left.value),
                    int(top.value),
                    int(left.value + width.value),
                    int(top.value + height.value),
                )

        except Exception as e:
            self.log.write(
                f"取得『{item.get('name') or '?'}』MSAA 位置仍失敗：{e}"
            )

        return None

    def _invoke_toolbar_child_message(self, logical_name: str) -> bool:
        """Activate the real VCL toolbar child without moving the mouse.

        MSAA finds the actual child. We then send WM_LBUTTONDOWN/UP directly
        to the HWND that owns that accessible child, at the child's dynamically
        discovered client coordinate.

        This is not physical mouse automation:
        - cursor does not move
        - no fixed screen coordinate
        - no foreground/focus dependency
        - works independently of RDP pointer state
        """
        if os.name != "nt" or not self.hwnd:
            return False

        item, score = self._msaa_best_candidate(logical_name)
        if not item:
            self.log.write(
                f"找不到『{logical_name}』對應的 MSAA 工具列子項目。"
            )
            return False

        owner_hwnd = int(item.get("hwnd") or 0)
        child_id = int(item.get("child_id") or 0)
        name = str(item.get("name") or logical_name)
        rect = self._accessible_item_screen_rect(item)

        if not owner_hwnd or not rect:
            self.log.write(
                f"已找到『{logical_name}』，但無法取得可投遞訊息的 HWND/位置。"
            )
            return False

        user32 = ctypes.windll.user32

        # Get owner class for diagnostics.
        try:
            clsbuf = ctypes.create_unicode_buffer(128)
            user32.GetClassNameW(owner_hwnd, clsbuf, len(clsbuf))
            owner_class = clsbuf.value or "?"
        except Exception:
            owner_class = "?"

        l, t, r, b = rect
        sx = int((l + r) // 2)
        sy = int((t + b) // 2)

        class POINT(ctypes.Structure):
            _fields_ = [("x", wintypes.LONG), ("y", wintypes.LONG)]

        pt = POINT(sx, sy)
        try:
            if not user32.ScreenToClient(owner_hwnd, ctypes.byref(pt)):
                self.log.write(
                    f"『{logical_name}』ScreenToClient 失敗。"
                )
                return False
        except Exception as e:
            self.log.write(
                f"『{logical_name}』ScreenToClient 例外：{e}"
            )
            return False

        cx = int(pt.x)
        cy = int(pt.y)

        # Reject obviously bogus converted coordinates.
        try:
            rc = wintypes.RECT()
            user32.GetClientRect(owner_hwnd, ctypes.byref(rc))
            if not (0 <= cx < int(rc.right) and 0 <= cy < int(rc.bottom)):
                self.log.write(
                    f"『{logical_name}』轉換後座標不在控制項內："
                    f"client=({cx},{cy}) size={rc.right}x{rc.bottom}。"
                )
                return False
        except Exception:
            pass

        WM_MOUSEMOVE = 0x0200
        WM_LBUTTONDOWN = 0x0201
        WM_LBUTTONUP = 0x0202
        MK_LBUTTON = 0x0001

        def makelparam(x, y):
            return ((int(y) & 0xFFFF) << 16) | (int(x) & 0xFFFF)

        lp = makelparam(cx, cy)

        try:
            # IMPORTANT v3.2.8:
            # Use PostMessageW, not SendMessageW.
            #
            # Some Delphi toolbar actions (especially "一鍵上傳") open a modal
            # result dialog inside the click handler.  SendMessageW would block
            # this automation thread until that modal dialog is dismissed, so
            # the automation could never reach the code that dismisses it.
            #
            # PostMessageW queues the exact same mouse messages to the target
            # control and returns immediately, allowing this thread to continue
            # monitoring/closing modal dialogs.
            ok0 = bool(user32.PostMessageW(owner_hwnd, WM_MOUSEMOVE, 0, lp))
            ok1 = bool(user32.PostMessageW(owner_hwnd, WM_LBUTTONDOWN, MK_LBUTTON, lp))
            time.sleep(0.06)
            ok2 = bool(user32.PostMessageW(owner_hwnd, WM_LBUTTONUP, 0, lp))

            self.log.write(
                f"已非同步投遞 Delphi 工具列『{logical_name}』Click："
                f"name={name}；owner HWND={owner_hwnd}；class={owner_class}；"
                f"child={child_id}；score={score}；client=({cx},{cy})；"
                f"PostMessage={int(ok0)},{int(ok1)},{int(ok2)}。"
            )
            return ok1 and ok2
        except Exception as e:
            self.log.write(
                f"非同步投遞『{logical_name}』工具列 Click 訊息失敗：{e}"
            )
            return False

    def _invoke_exit_via_syschar(self) -> bool:
        """Execute &X結束 using the same VCL system-char route that works for Q."""
        if os.name != "nt" or not self.hwnd:
            return False

        user32 = ctypes.WinDLL("user32", use_last_error=True)
        WM_SYSCHAR = 0x0106
        VK_X = 0x58

        try:
            scan = int(user32.MapVirtualKeyW(VK_X, 0)) & 0xFF
        except Exception:
            scan = 0

        lparam = 1 | (scan << 16) | (1 << 29)

        result = ctypes.c_size_t(0)
        SMTO_ABORTIFHUNG = 0x0002
        try:
            fn = user32.SendMessageTimeoutW
            fn.argtypes = [
                wintypes.HWND, wintypes.UINT, wintypes.WPARAM,
                wintypes.LPARAM, wintypes.UINT, wintypes.UINT,
                ctypes.POINTER(ctypes.c_size_t),
            ]
            fn.restype = wintypes.LPARAM

            ctypes.set_last_error(0)
            ok = fn(
                int(self.hwnd),
                WM_SYSCHAR,
                ord("X"),
                lparam,
                SMTO_ABORTIFHUNG,
                1800,
                ctypes.byref(result),
            )
            err = int(ctypes.get_last_error())
            self.log.write(
                f"直接送 WM_SYSCHAR('X') 執行『X結束』："
                f"ok={int(bool(ok))} result={int(result.value)} error={err}。"
            )
            return bool(ok)
        except Exception as e:
            self.log.write(f"WM_SYSCHAR('X') 執行失敗：{e}")
            return False

    def _invoke_msaa_action(self, logical_name: str) -> bool:
        """Invoke the uploader button through IAccessible.accDoDefaultAction.

        This sends no screen coordinates and does not move the mouse.  For native
        toolbar buttons, Windows exposes their default action specifically for
        accessibility/automation clients.
        """
        if os.name != "nt" or not self.hwnd:
            return False

        self._activate(maximize=True)
        candidates = self._msaa_candidates()
        ranked = sorted(
            (
                (self._msaa_match_score(logical_name, item), item)
                for item in candidates
            ),
            key=lambda x: x[0],
            reverse=True,
        )

        # Diagnostic dump is intentionally limited to named objects only.
        named = [
            f"{x.get('name')}[{x.get('default_action') or '-'}]"
            for x in candidates if (x.get("name") or "").strip()
        ]
        if named:
            self.log.write(
                "MSAA 可見控制項：" + "；".join(named[:40])
            )

        if not ranked or ranked[0][0] < 100:
            action_meta = self.DELPHI_ACTIONS.get(logical_name)
            if action_meta:
                self.log.write(
                    f"已知 Delphi Action={action_meta[0]} / {action_meta[1]} / {action_meta[2]}，"
                    "但 MSAA 尚未找到對應的可執行控制項。"
                )
            return False

        score, item = ranked[0]
        acc = item["acc"]
        child_id = int(item.get("child_id") or 0)
        name = item.get("name") or logical_name
        try:
            acc.accDoDefaultAction(child_id)
            self.log.write(
                f"已直接透過 MSAA accDoDefaultAction 執行『{logical_name}』"
                f"（找到：{name}；child={child_id}；score={score}）。"
            )
            return True
        except Exception as e:
            self.log.write(
                f"MSAA 找到『{logical_name}』控制項，但 accDoDefaultAction 執行失敗：{e}"
            )
            return False

    def _find_native_toolbar_hwnd(self) -> int:
        """Locate the real VCL/common-control toolbar by TB_BUTTONCOUNT."""
        if self.toolbar_hwnd:
            try:
                if ctypes.windll.user32.IsWindow(int(self.toolbar_hwnd)):
                    return int(self.toolbar_hwnd)
            except Exception:
                pass

        TB_BUTTONCOUNT = 0x0400 + 24
        candidates = []
        for item in self._enum_child_hwnds():
            h = item["hwnd"]
            ok, count = self._send_message_timeout(h, TB_BUTTONCOUNT, 0, 0, 300)
            if not ok or not (4 <= count <= 20):
                continue
            l, t, r, b = item["rect"]
            width, height = max(0, r-l), max(0, b-t)
            cls = (item["class_name"] or "").lower()
            score = 0
            if "toolbar" in cls:
                score += 100
            # The uploader toolbar is a wide, shallow control near the top.
            if width >= 150:
                score += 30
            if 15 <= height <= 120:
                score += 30
            score += min(count, 10)
            candidates.append((score, h, count, item["class_name"], width, height))

        if not candidates:
            return 0
        candidates.sort(reverse=True)
        score, h, count, cls, width, height = candidates[0]
        self.toolbar_hwnd = int(h)
        self.log.write(
            f"已從上傳程式底層找到工具列：HWND={h}, class={cls or '?'}, "
            f"button_count={count}, size={width}x{height}。"
        )
        return int(h)

    def _read_toolbar_buttons(self):
        """Read TBBUTTON/idCommand directly from the uploader process.

        TB_GETBUTTON uses a pointer in the target process for messages >= WM_USER,
        so allocate a tiny remote buffer in ExchNHIMgrDMU.exe, let the toolbar fill
        it, then read it back.  The target is the known 32-bit uploader.
        """
        if os.name != "nt":
            return []
        toolbar = self._find_native_toolbar_hwnd()
        if not toolbar:
            return []

        user32 = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32

        TB_BUTTONCOUNT = 0x0400 + 24
        TB_GETBUTTON = 0x0400 + 23
        TB_GETBUTTONTEXTW = 0x0400 + 75

        ok, count = self._send_message_timeout(toolbar, TB_BUTTONCOUNT, 0, 0, 500)
        if not ok or not (1 <= count <= 50):
            return []

        pid = wintypes.DWORD(0)
        user32.GetWindowThreadProcessId(int(toolbar), ctypes.byref(pid))
        if not pid.value:
            return []

        PROCESS_VM_OPERATION = 0x0008
        PROCESS_VM_READ = 0x0010
        PROCESS_VM_WRITE = 0x0020
        PROCESS_QUERY_INFORMATION = 0x0400
        access = PROCESS_VM_OPERATION | PROCESS_VM_READ | PROCESS_VM_WRITE | PROCESS_QUERY_INFORMATION

        kernel32.OpenProcess.restype = ctypes.c_void_p
        kernel32.VirtualAllocEx.restype = ctypes.c_void_p
        process = kernel32.OpenProcess(access, False, int(pid.value))
        if not process:
            self.log.write("找到 TToolBar，但無法開啟 ExchNHIMgrDMU 行程讀取 button command ID。")
            return []

        class TBBUTTON32(ctypes.Structure):
            _fields_ = [
                ("iBitmap", ctypes.c_int32),
                ("idCommand", ctypes.c_int32),
                ("fsState", ctypes.c_ubyte),
                ("fsStyle", ctypes.c_ubyte),
                ("bReserved", ctypes.c_ubyte * 2),
                ("dwData", ctypes.c_uint32),
                ("iString", ctypes.c_int32),
            ]

        MEM_COMMIT = 0x1000
        MEM_RESERVE = 0x2000
        MEM_RELEASE = 0x8000
        PAGE_READWRITE = 0x04
        remote_size = 2048
        remote = kernel32.VirtualAllocEx(
            process, None, remote_size, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE
        )
        if not remote:
            kernel32.CloseHandle(process)
            return []

        items = []
        try:
            for index in range(int(count)):
                # Ask the target toolbar to write TBBUTTON into memory that belongs
                # to the target process.
                ok_get, got = self._send_message_timeout(
                    toolbar, TB_GETBUTTON, index, int(remote), 800
                )
                if not ok_get or got == 0:
                    continue

                raw = (ctypes.c_ubyte * ctypes.sizeof(TBBUTTON32))()
                nread = ctypes.c_size_t(0)
                ok_read = kernel32.ReadProcessMemory(
                    process, ctypes.c_void_p(remote),
                    ctypes.byref(raw), ctypes.sizeof(raw), ctypes.byref(nread)
                )
                if not ok_read or nread.value < ctypes.sizeof(TBBUTTON32):
                    continue
                btn = TBBUTTON32.from_buffer_copy(bytes(raw))

                caption = ""
                if btn.idCommand > 0:
                    # Clear the remote buffer before asking for text.
                    zeros = (ctypes.c_ubyte * remote_size)()
                    written = ctypes.c_size_t(0)
                    try:
                        kernel32.WriteProcessMemory(
                            process, ctypes.c_void_p(remote), ctypes.byref(zeros),
                            remote_size, ctypes.byref(written)
                        )
                    except Exception:
                        pass

                    ok_txt, txt_len = self._send_message_timeout(
                        toolbar, TB_GETBUTTONTEXTW, int(btn.idCommand), int(remote), 800
                    )
                    # SendMessageTimeout returns the message result in txt_len.
                    if ok_txt and txt_len not in (0xFFFFFFFF, 0xFFFFFFFFFFFFFFFF) and txt_len < 512:
                        size = min(remote_size, (int(txt_len) + 1) * 2)
                        buf = (ctypes.c_ubyte * max(2, size))()
                        nread2 = ctypes.c_size_t(0)
                        if kernel32.ReadProcessMemory(
                            process, ctypes.c_void_p(remote),
                            ctypes.byref(buf), len(buf), ctypes.byref(nread2)
                        ):
                            try:
                                caption = bytes(buf[:nread2.value]).decode("utf-16-le", errors="ignore")
                                caption = caption.split("\\x00", 1)[0].strip()
                            except Exception:
                                caption = ""

                items.append({
                    "index": index,
                    "idCommand": int(btn.idCommand),
                    "state": int(btn.fsState),
                    "style": int(btn.fsStyle),
                    "text": caption,
                })
        finally:
            try:
                kernel32.VirtualFreeEx(process, ctypes.c_void_p(remote), 0, MEM_RELEASE)
            except Exception:
                pass
            kernel32.CloseHandle(process)

        self.toolbar_button_dump = items
        if items:
            summary = "；".join(
                f"#{x['index']} id={x['idCommand']} text={x['text'] or '(無文字)'}"
                for x in items
            )
            self.log.write("已直接讀取 TToolBar button command：" + summary)
        return items

    def _discover_toolbar_commands(self, force=False):
        if self.toolbar_commands and not force:
            return dict(self.toolbar_commands)

        items = self._read_toolbar_buttons()
        if not items:
            return {}

        # First preference: match the caption returned by TB_GETBUTTONTEXTW.
        wanted = {
            "查詢": ("查詢",),
            "全選": ("全選",),
            "一鍵上傳": ("一鍵上傳", "一鍵"),
            "結束": ("結束",),
        }
        found = {}
        for logical, keys in wanted.items():
            for item in items:
                nt = normalize_text(item.get("text", ""))
                if nt and any(normalize_text(k) in nt for k in keys):
                    if item["idCommand"] > 0:
                        found[logical] = int(item["idCommand"])
                        break

        # If the old toolbar does not expose text, use the visually confirmed,
        # stable button order from this specific ExchNHIMgrDMU.exe:
        # 0 Q查詢, 1 上傳, 2 全選, 3 清除, 4 一鍵上傳, 5 X結束.
        by_index = {x["index"]: x["idCommand"] for x in items if x["idCommand"] > 0}
        fallback_index = {"查詢": 0, "全選": 2, "一鍵上傳": 4, "結束": 5}
        for logical, idx in fallback_index.items():
            if logical not in found and idx in by_index:
                found[logical] = int(by_index[idx])

        self.toolbar_commands = found
        if found:
            self.log.write(
                "原生工具列 command 對應：" +
                "；".join(f"{k}=ID {v}" for k, v in found.items())
            )
        return dict(found)

    def _send_native_toolbar_command(self, logical_name: str) -> bool:
        """Execute one toolbar command without mouse coordinates or mouse input."""
        if os.name != "nt" or not self.hwnd:
            return False
        commands = self._discover_toolbar_commands()
        command_id = commands.get(logical_name)
        toolbar = self._find_native_toolbar_hwnd()
        if not command_id or not toolbar:
            self.log.write(f"無法取得『{logical_name}』的原生 toolbar command ID。")
            return False

        user32 = ctypes.windll.user32
        WM_COMMAND = 0x0111

        # A standard toolbar sends WM_COMMAND to its immediate parent.
        parent = int(user32.GetParent(int(toolbar)) or 0)
        if not parent:
            parent = int(self.hwnd)

        try:
            user32.SendMessageW(parent, WM_COMMAND, int(command_id) & 0xFFFF, int(toolbar))
            self.log.write(
                f"已直接送出原生『{logical_name}』命令："
                f"WM_COMMAND ID={command_id} → parent HWND={parent}。"
            )
            return True
        except Exception as e:
            self.log.write(f"送出原生『{logical_name}』command ID={command_id} 失敗：{e}")
            return False

    def _find_keyword_control_any_backend(self, keyword: str):
        """Return the best control matching *keyword* without clicking it.

        The legacy uploader is an old native application.  Some toolbar items
        are exposed through UIA, some through classic Win32, and some are
        custom-drawn.  Query activation therefore uses a system-level invoke
        chain instead of moving the user's mouse.
        """
        for scope in (self.win_uia, self.win_win32, self.win):
            if scope is None:
                continue
            try:
                ctrl = find_keyword_control(scope, [keyword], control_types=None)
                if ctrl is not None:
                    return ctrl
            except Exception:
                pass
        return None

    def _invoke_control_system(self, ctrl, keyword: str) -> bool:
        """Invoke a native control without moving/clicking the physical mouse."""
        if ctrl is None:
            return False

        name = _safe_name(ctrl) or keyword

        # 1) UI Automation InvokePattern: closest equivalent to the user
        # activating the control, but entirely through the accessibility API.
        try:
            inv = getattr(ctrl, "invoke", None)
            if callable(inv):
                inv()
                self.log.write(f"已用 Windows/UIA Invoke 啟動『{name}』。")
                return True
        except Exception:
            pass
        try:
            iface = getattr(ctrl, "iface_invoke", None)
            if iface is not None:
                iface.Invoke()
                self.log.write(f"已用 UIA InvokePattern 啟動『{name}』。")
                return True
        except Exception:
            pass

        # 2) Old Delphi/VCL controls often expose MSAA rather than UIA.
        # DoDefaultAction activates the control without moving the physical mouse.
        try:
            legacy = getattr(ctrl, "iface_legacy_iaccessible", None)
            if legacy is not None:
                legacy.DoDefaultAction()
                self.log.write(f"已用 MSAA DoDefaultAction 啟動『{name}』。")
                return True
        except Exception:
            pass

        # 3) pywinauto Win32 click() is a message-based click (unlike
        # click_input(), it does not need to move the real pointer).
        try:
            click = getattr(ctrl, "click", None)
            if callable(click):
                click()
                self.log.write(f"已用 Win32 系統訊息啟動『{name}』。")
                return True
        except Exception:
            pass

        # 4) Standard button fallback: BM_CLICK directly to the child HWND.
        try:
            hwnd = int(getattr(ctrl, "handle", 0) or 0)
        except Exception:
            hwnd = 0
        if hwnd and os.name == "nt":
            try:
                BM_CLICK = 0x00F5
                ctypes.windll.user32.SendMessageW(hwnd, BM_CLICK, 0, 0)
                self.log.write(f"已對『{name}』送出 BM_CLICK 系統訊息。")
                return True
            except Exception:
                pass
        return False

    @staticmethod
    def _make_lparam(x: int, y: int) -> int:
        return ((int(y) & 0xFFFF) << 16) | (int(x) & 0xFFFF)

    def _physical_click_reference_point(self, fallback_name: str, label: str) -> bool:
        """Reliably activate an old Delphi/VCL toolbar item with real input.

        The uploader's TToolBar can receive WM_LBUTTONDOWN/UP without actually
        firing its internal button command.  For this legacy window, a genuine
        foreground mouse click is more reliable.  Coordinates are offsets from
        the maximized uploader window, not absolute desktop calibration.
        """
        try:
            import pyautogui
        except Exception as e:
            self.log.write(f"無法載入滑鼠自動點擊模組：{e}")
            return False

        self._activate(maximize=True)
        if not self._foreground_is_uploader():
            self.log.write(f"『{label}』實體點擊前無法確認上傳程式位於前景。")
            return False

        rx, ry = FALLBACK_POINTS[fallback_name]
        left = top = 0

        if os.name == "nt" and self.hwnd:
            try:
                rect = wintypes.RECT()
                if ctypes.windll.user32.GetWindowRect(int(self.hwnd), ctypes.byref(rect)):
                    left, top = int(rect.left), int(rect.top)
            except Exception:
                left = top = 0

        # In the user's fixed 1920x1080 / 125% environment these are window
        # offsets measured from the supplied workflow.  If Windows reports a
        # maximized border at -8/-8, using the real window origin compensates it.
        sx = int(left + rx)
        sy = int(top + ry)

        try:
            pyautogui.moveTo(sx, sy, duration=0.12)
            time.sleep(0.08)
            pyautogui.click(sx, sy)
            self.log.write(
                f"已用程式控制實體滑鼠點擊『{label}』"
                f"（上傳程式視窗相對位置 {rx},{ry}；實際 {sx},{sy}）。"
            )
            return True
        except Exception as e:
            self.log.write(f"實體滑鼠自動點擊『{label}』失敗：{e}")
            return False

    def _system_click_reference_point(self, fallback_name: str, label: str) -> bool:
        """Send a Windows mouse-message click to a point, without moving cursor.

        This is intentionally *not* pyautogui.click/click_input.  It locates
        the native child HWND under the reference point and sends
        WM_LBUTTONDOWN/WM_LBUTTONUP directly to that window.  This works well
        with the uploader's old custom-drawn toolbar while keeping the fast
        v2.1 login path untouched.
        """
        if os.name != "nt" or not self.hwnd:
            return False

        self._activate(maximize=True)
        user32 = ctypes.windll.user32

        # Use Windows screen metrics only; do not involve pyautogui or the
        # physical pointer.  v2.1 already maximizes this window before query.
        try:
            sw = int(user32.GetSystemMetrics(0)) or REFERENCE_W
            sh = int(user32.GetSystemMetrics(1)) or REFERENCE_H
        except Exception:
            sw, sh = REFERENCE_W, REFERENCE_H
        rx, ry = FALLBACK_POINTS[fallback_name]
        sx = round(rx * sw / REFERENCE_W)
        sy = round(ry * sh / REFERENCE_H)

        pt = wintypes.POINT(sx, sy)
        try:
            target = int(user32.WindowFromPoint(pt) or 0)
        except Exception:
            target = 0

        # Only trust the hit-test child when it belongs to this uploader.
        # Otherwise send to the uploader root using root-client coordinates.
        GA_ROOT = 2
        if target:
            try:
                root = int(user32.GetAncestor(target, GA_ROOT) or 0)
            except Exception:
                root = 0
            if root and root != int(self.hwnd):
                target = 0
        if not target:
            target = int(self.hwnd)

        client_pt = wintypes.POINT(sx, sy)
        try:
            if not user32.ScreenToClient(target, ctypes.byref(client_pt)):
                return False
        except Exception:
            return False

        WM_MOUSEMOVE = 0x0200
        WM_LBUTTONDOWN = 0x0201
        WM_LBUTTONUP = 0x0202
        MK_LBUTTON = 0x0001
        lp = self._make_lparam(client_pt.x, client_pt.y)

        try:
            # Synchronous SendMessage makes the legacy app process the click
            # before we start waiting for its modal Confirm window.
            user32.SendMessageW(target, WM_MOUSEMOVE, 0, lp)
            user32.SendMessageW(target, WM_LBUTTONDOWN, MK_LBUTTON, lp)
            time.sleep(0.06)
            user32.SendMessageW(target, WM_LBUTTONUP, 0, lp)

            cls_buf = ctypes.create_unicode_buffer(128)
            try:
                user32.GetClassNameW(target, cls_buf, len(cls_buf))
                cls = cls_buf.value or "?"
            except Exception:
                cls = "?"
            self.log.write(
                f"已用 Windows 系統訊息點擊左上角『{label}』放大鏡功能"
                f"（不移動實體滑鼠；target HWND={target}, class={cls}）。"
            )
            return True
        except Exception as e:
            self.log.write(f"Windows 系統訊息點擊『{label}』失敗：{e}")
            return False

    def _send_command_for_reference_point(self, fallback_name: str, label: str) -> bool:
        """Last system-only fallback for a standard child control.

        If the hit-test point maps to a child HWND with a control ID, send its
        WM_COMMAND/BN_CLICKED notification to the uploader.  Custom Delphi
        speed-buttons often have no child HWND, so this is only an extra route.
        """
        if os.name != "nt" or not self.hwnd:
            return False
        user32 = ctypes.windll.user32
        try:
            sw = int(user32.GetSystemMetrics(0)) or REFERENCE_W
            sh = int(user32.GetSystemMetrics(1)) or REFERENCE_H
            rx, ry = FALLBACK_POINTS[fallback_name]
            pt = wintypes.POINT(round(rx * sw / REFERENCE_W), round(ry * sh / REFERENCE_H))
            child = int(user32.WindowFromPoint(pt) or 0)
            if not child or child == int(self.hwnd):
                return False
            if int(user32.GetAncestor(child, 2) or 0) != int(self.hwnd):
                return False
            cid = int(user32.GetDlgCtrlID(child))
            if cid <= 0:
                return False
            WM_COMMAND = 0x0111
            BN_CLICKED = 0
            wparam = (BN_CLICKED << 16) | (cid & 0xFFFF)
            user32.SendMessageW(int(self.hwnd), WM_COMMAND, wparam, child)
            self.log.write(f"已用 WM_COMMAND 啟動『{label}』（control id={cid}）。")
            return True
        except Exception:
            return False

    def _wait_confirm(self, seconds: float):
        deadline = time.time() + seconds
        while time.time() < deadline:
            dlg = self._find_dialog(titles=("Confirm",), content_keywords=())
            if dlg:
                return dlg
            time.sleep(0.06)
        return None

    def _send_alt_q_sendinput(self) -> bool:
        """Human-like Alt+Q: hold Alt first, then press Q, then release.

        The user confirmed the legacy Delphi/VCL uploader reacts when Alt is
        physically held before Q is pressed.  Sending four events in one
        SendInput batch was accepted by Windows (4/4) but was too fast for this
        old menu/action handling path.
        """
        if os.name != "nt":
            return False

        user32 = ctypes.WinDLL("user32", use_last_error=True)

        VK_MENU = 0x12
        VK_Q = 0x51
        INPUT_KEYBOARD = 1
        KEYEVENTF_KEYUP = 0x0002

        ULONG_PTR = (
            ctypes.c_ulonglong
            if ctypes.sizeof(ctypes.c_void_p) == 8
            else ctypes.c_ulong
        )

        class MOUSEINPUT(ctypes.Structure):
            _fields_ = [
                ("dx", wintypes.LONG),
                ("dy", wintypes.LONG),
                ("mouseData", wintypes.DWORD),
                ("dwFlags", wintypes.DWORD),
                ("time", wintypes.DWORD),
                ("dwExtraInfo", ULONG_PTR),
            ]

        class KEYBDINPUT(ctypes.Structure):
            _fields_ = [
                ("wVk", wintypes.WORD),
                ("wScan", wintypes.WORD),
                ("dwFlags", wintypes.DWORD),
                ("time", wintypes.DWORD),
                ("dwExtraInfo", ULONG_PTR),
            ]

        class HARDWAREINPUT(ctypes.Structure):
            _fields_ = [
                ("uMsg", wintypes.DWORD),
                ("wParamL", wintypes.WORD),
                ("wParamH", wintypes.WORD),
            ]

        class INPUTUNION(ctypes.Union):
            _fields_ = [
                ("mi", MOUSEINPUT),
                ("ki", KEYBDINPUT),
                ("hi", HARDWAREINPUT),
            ]

        class INPUT(ctypes.Structure):
            _anonymous_ = ("u",)
            _fields_ = [
                ("type", wintypes.DWORD),
                ("u", INPUTUNION),
            ]

        user32.SendInput.argtypes = [
            wintypes.UINT,
            ctypes.POINTER(INPUT),
            ctypes.c_int,
        ]
        user32.SendInput.restype = wintypes.UINT

        def send_one(vk: int, flags: int = 0):
            inp = INPUT()
            inp.type = INPUT_KEYBOARD
            inp.ki = KEYBDINPUT(vk, 0, flags, 0, 0)
            ctypes.set_last_error(0)
            sent = int(user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT)))
            err = int(ctypes.get_last_error())
            return sent == 1, err

        # IMPORTANT: do not write to the tool GUI between foreground activation
        # and finishing the chord; keep the uploader as the foreground window.
        try:
            ok_alt_down, e1 = send_one(VK_MENU, 0)
            if not ok_alt_down:
                self.log.write(f"Alt 按下失敗，GetLastError={e1}；改用 keybd_event。")
                return self._send_alt_q_keybd_event()

            # Mimic the user's real operation: hold Alt noticeably before Q.
            time.sleep(0.35)

            ok_q_down, e2 = send_one(VK_Q, 0)
            if not ok_q_down:
                # Always release Alt to avoid leaving Windows in a stuck state.
                send_one(VK_MENU, KEYEVENTF_KEYUP)
                self.log.write(f"Q 按下失敗，GetLastError={e2}；改用 keybd_event。")
                return self._send_alt_q_keybd_event()

            time.sleep(0.10)

            ok_q_up, e3 = send_one(VK_Q, KEYEVENTF_KEYUP)
            time.sleep(0.15)
            ok_alt_up, e4 = send_one(VK_MENU, KEYEVENTF_KEYUP)

            ok = ok_alt_down and ok_q_down and ok_q_up and ok_alt_up
            self.log.write(
                "已依人工節奏送出 Alt+Q："
                f"Alt↓={int(ok_alt_down)}、Q↓={int(ok_q_down)}、"
                f"Q↑={int(ok_q_up)}、Alt↑={int(ok_alt_up)}；"
                f"errors={e1},{e2},{e3},{e4}。"
            )
            if ok:
                return True

            return self._send_alt_q_keybd_event()

        except Exception as e:
            # Best effort: release Alt if an exception interrupted the chord.
            try:
                send_one(VK_MENU, KEYEVENTF_KEYUP)
            except Exception:
                pass
            self.log.write(f"分段 SendInput Alt+Q 發生例外：{e}")
            return self._send_alt_q_keybd_event()

    def _send_alt_q_keybd_event(self) -> bool:
        """Human-like legacy keybd_event fallback: hold Alt, then press Q."""
        if os.name != "nt":
            return False

        try:
            user32 = ctypes.windll.user32
            VK_MENU = 0x12
            VK_Q = 0x51
            KEYEVENTF_KEYUP = 0x0002

            # Alt down and hold.
            user32.keybd_event(
                VK_MENU,
                user32.MapVirtualKeyW(VK_MENU, 0),
                0,
                0,
            )
            time.sleep(0.35)

            # Q down/up while Alt is still held.
            user32.keybd_event(
                VK_Q,
                user32.MapVirtualKeyW(VK_Q, 0),
                0,
                0,
            )
            time.sleep(0.10)

            user32.keybd_event(
                VK_Q,
                user32.MapVirtualKeyW(VK_Q, 0),
                KEYEVENTF_KEYUP,
                0,
            )
            time.sleep(0.15)

            # Finally release Alt.
            user32.keybd_event(
                VK_MENU,
                user32.MapVirtualKeyW(VK_MENU, 0),
                KEYEVENTF_KEYUP,
                0,
            )

            self.log.write(
                "已使用 keybd_event 依人工節奏送出：Alt 按住 → Q → 放開 Alt。"
            )
            return True
        except Exception as e:
            self.log.write(f"keybd_event Alt+Q 備援失敗：{e}")
            return False

    def _post_alt_q_syskey(self) -> bool:
        """Post WM_SYSKEYDOWN/UP Alt+Q into the uploader's GUI message queue."""
        if os.name != "nt" or not self.hwnd:
            return False

        user32 = ctypes.windll.user32
        WM_SYSKEYDOWN = 0x0104
        WM_SYSKEYUP = 0x0105
        VK_MENU = 0x12
        VK_Q = 0x51
        MAPVK_VK_TO_VSC = 0

        try:
            user32.PostMessageW.argtypes = [
                wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM
            ]
            user32.PostMessageW.restype = wintypes.BOOL
        except Exception:
            pass

        try:
            alt_scan = int(user32.MapVirtualKeyW(VK_MENU, MAPVK_VK_TO_VSC)) & 0xFF
            q_scan = int(user32.MapVirtualKeyW(VK_Q, MAPVK_VK_TO_VSC)) & 0xFF

            # lParam:
            # bits 0-15 repeat count
            # bits 16-23 scan code
            # bit 29 = ALT/context flag for Q while Alt is held
            # bits 30/31 = previous state / transition state on key-up
            alt_down_lp = 1 | (alt_scan << 16)
            q_down_lp = 1 | (q_scan << 16) | (1 << 29)
            q_up_lp = q_down_lp | (1 << 30) | (1 << 31)
            alt_up_lp = alt_down_lp | (1 << 30) | (1 << 31)

            ok1 = bool(user32.PostMessageW(
                int(self.hwnd), WM_SYSKEYDOWN, VK_MENU, alt_down_lp
            ))
            ok2 = bool(user32.PostMessageW(
                int(self.hwnd), WM_SYSKEYDOWN, VK_Q, q_down_lp
            ))
            time.sleep(0.06)
            ok3 = bool(user32.PostMessageW(
                int(self.hwnd), WM_SYSKEYUP, VK_Q, q_up_lp
            ))
            ok4 = bool(user32.PostMessageW(
                int(self.hwnd), WM_SYSKEYUP, VK_MENU, alt_up_lp
            ))

            self.log.write(
                "已直接投遞 WM_SYSKEYDOWN/UP Alt+Q 給 IC卡資料上傳作業"
                f"（{int(ok1)},{int(ok2)},{int(ok3)},{int(ok4)}）。"
            )
            return ok1 and ok2 and ok3 and ok4
        except Exception as e:
            self.log.write(f"WM_SYSKEY Alt+Q 投遞失敗：{e}")
            return False

    def _force_uploader_foreground_for_keyboard(self) -> bool:
        """Make sure BOTH foreground window and keyboard focus belong to uploader.

        Old Delphi/VCL programs can be the foreground top-level window while the
        actual keyboard-focus HWND still belongs to another GUI thread.  Alt+Q
        only works when the keyboard focus is inside ExchNHIMgrDMU.exe.
        """
        if os.name != "nt" or not self.hwnd:
            return False

        user32 = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32

        target_pid = wintypes.DWORD(0)
        target_tid = int(
            user32.GetWindowThreadProcessId(int(self.hwnd), ctypes.byref(target_pid))
            or 0
        )
        if not target_tid or not target_pid.value:
            return False

        cur_tid = int(kernel32.GetCurrentThreadId())
        fg_hwnd = int(user32.GetForegroundWindow() or 0)
        fg_tid = int(user32.GetWindowThreadProcessId(fg_hwnd, None) or 0) if fg_hwnd else 0

        attached_target = False
        attached_fg = False

        try:
            # Temporarily join input queues so SetForegroundWindow/SetFocus can
            # operate on the old Delphi GUI thread reliably.
            if target_tid != cur_tid:
                attached_target = bool(
                    user32.AttachThreadInput(cur_tid, target_tid, True)
                )
            if fg_tid and fg_tid not in (cur_tid, target_tid):
                attached_fg = bool(
                    user32.AttachThreadInput(cur_tid, fg_tid, True)
                )

            try:
                if user32.IsIconic(int(self.hwnd)):
                    user32.ShowWindow(int(self.hwnd), 9)  # SW_RESTORE
            except Exception:
                pass

            # Do not unnecessarily maximize here. The user's manual Alt+Q works
            # in the existing uploader state, so preserve that state.
            user32.ShowWindow(int(self.hwnd), 5)  # SW_SHOW
            user32.BringWindowToTop(int(self.hwnd))

            # SwitchToThisWindow is useful for legacy desktop apps when normal
            # SetForegroundWindow foreground-lock rules are involved.
            try:
                user32.SwitchToThisWindow(int(self.hwnd), True)
            except Exception:
                pass

            user32.SetForegroundWindow(int(self.hwnd))
            user32.SetActiveWindow(int(self.hwnd))
            time.sleep(0.12)

            # Determine whether the target GUI thread already has a focused child.
            class GUITHREADINFO(ctypes.Structure):
                _fields_ = [
                    ("cbSize", wintypes.DWORD),
                    ("flags", wintypes.DWORD),
                    ("hwndActive", wintypes.HWND),
                    ("hwndFocus", wintypes.HWND),
                    ("hwndCapture", wintypes.HWND),
                    ("hwndMenuOwner", wintypes.HWND),
                    ("hwndMoveSize", wintypes.HWND),
                    ("hwndCaret", wintypes.HWND),
                    ("rcCaret", wintypes.RECT),
                ]

            def target_gui_info():
                gi = GUITHREADINFO()
                gi.cbSize = ctypes.sizeof(GUITHREADINFO)
                try:
                    if user32.GetGUIThreadInfo(target_tid, ctypes.byref(gi)):
                        return gi
                except Exception:
                    pass
                return None

            def hwnd_pid(hwnd):
                if not hwnd:
                    return 0
                pid = wintypes.DWORD(0)
                try:
                    user32.GetWindowThreadProcessId(int(hwnd), ctypes.byref(pid))
                    return int(pid.value)
                except Exception:
                    return 0

            gi = target_gui_info()
            focus_hwnd = int(gi.hwndFocus or 0) if gi else 0

            # If VCL did not restore a child focus automatically, pick the first
            # visible/enabled/tab-stop child from the uploader itself.
            if hwnd_pid(focus_hwnd) != int(target_pid.value):
                candidates = []
                WNDENUMPROC = ctypes.WINFUNCTYPE(
                    wintypes.BOOL, wintypes.HWND, wintypes.LPARAM
                )
                WS_TABSTOP = 0x00010000
                GWL_STYLE = -16

                @WNDENUMPROC
                def enum_child(child, lparam):
                    try:
                        if not user32.IsWindowVisible(child):
                            return True
                        if not user32.IsWindowEnabled(child):
                            return True
                        style = int(user32.GetWindowLongW(child, GWL_STYLE))
                        cls = ctypes.create_unicode_buffer(128)
                        user32.GetClassNameW(child, cls, len(cls))
                        class_name = cls.value or ""
                        score = 0
                        if style & WS_TABSTOP:
                            score += 100
                        if class_name.lower() not in (
                            "ttoolbar", "toolbarwindow32", "tpanel", "tstatusbar"
                        ):
                            score += 20
                        # Prefer normal input/grid/client controls over toolbar.
                        if any(x in class_name.lower() for x in (
                            "edit", "combo", "grid", "list", "page", "tab"
                        )):
                            score += 40
                        candidates.append((score, int(child), class_name))
                    except Exception:
                        pass
                    return True

                try:
                    user32.EnumChildWindows(int(self.hwnd), enum_child, 0)
                except Exception:
                    pass

                candidates.sort(reverse=True)
                chosen = candidates[0] if candidates else None
                if chosen:
                    try:
                        user32.SetFocus(int(chosen[1]))
                    except Exception:
                        pass
                else:
                    try:
                        user32.SetFocus(int(self.hwnd))
                    except Exception:
                        pass

                time.sleep(0.10)
                gi = target_gui_info()
                focus_hwnd = int(gi.hwndFocus or 0) if gi else 0

            # Final foreground verification.
            foreground_hwnd = int(user32.GetForegroundWindow() or 0)
            focus_pid = hwnd_pid(focus_hwnd)
            ok = (
                foreground_hwnd == int(self.hwnd)
                and focus_pid == int(target_pid.value)
            )

        finally:
            if attached_fg:
                try:
                    user32.AttachThreadInput(cur_tid, fg_tid, False)
                except Exception:
                    pass
            if attached_target:
                try:
                    user32.AttachThreadInput(cur_tid, target_tid, False)
                except Exception:
                    pass

        if ok:
            try:
                cls = ctypes.create_unicode_buffer(128)
                user32.GetClassNameW(focus_hwnd, cls, len(cls))
                focus_class = cls.value or "?"
            except Exception:
                focus_class = "?"
            self.log.write(
                f"已確認鍵盤焦點真正位於 IC卡上傳程式："
                f"foreground={self.hwnd}；focus HWND={focus_hwnd}；"
                f"class={focus_class}；PID={focus_pid}。"
            )
            return True

        self.log.write(
            f"鍵盤焦點確認失敗：target HWND={self.hwnd}；"
            f"foreground HWND={foreground_hwnd}；focus HWND={focus_hwnd}；"
            f"target PID={int(target_pid.value)}；focus PID={focus_pid}。"
        )
        return False

    def _send_vcl_query_mnemonic(self) -> bool:
        """Trigger &Q查詢 through the same Win32/VCL message path as Alt+Q.

        Real Alt+Q eventually produces WM_SYSCHAR.  VCL handles WM_SYSCHAR and
        broadcasts CM_DIALOGCHAR to controls/actions looking for the '&Q'
        mnemonic.  Sending the message directly avoids SendInput, focus,
        foreground-window rules, and RDP keyboard redirection entirely.
        """
        if os.name != "nt" or not self.hwnd:
            return False

        user32 = ctypes.windll.user32
        WM_SYSCHAR = 0x0106
        CM_DIALOGCHAR = 0xB006
        VK_Q = 0x51
        MAPVK_VK_TO_VSC = 0

        # lParam compatible with a system-character produced while Alt is held:
        # repeat=1, scan code, context bit 29 set.
        try:
            scan = int(user32.MapVirtualKeyW(VK_Q, MAPVK_VK_TO_VSC)) & 0xFF
        except Exception:
            scan = 0
        keydata = 1 | (scan << 16) | (1 << 29)

        # Use SendMessageTimeout rather than PostMessage.  This is synchronous,
        # targeted to the uploader HWND, and does not depend on it being foreground.
        def send(hwnd, msg, wparam, lparam, timeout=1800):
            result = ctypes.c_size_t(0)
            SMTO_ABORTIFHUNG = 0x0002
            try:
                user32e = ctypes.WinDLL("user32", use_last_error=True)
                fn = user32e.SendMessageTimeoutW
                fn.argtypes = [
                    wintypes.HWND, wintypes.UINT, wintypes.WPARAM,
                    wintypes.LPARAM, wintypes.UINT, wintypes.UINT,
                    ctypes.POINTER(ctypes.c_size_t)
                ]
                fn.restype = wintypes.LPARAM
                ctypes.set_last_error(0)
                ok = fn(
                    int(hwnd), int(msg), int(wparam), int(lparam),
                    SMTO_ABORTIFHUNG, int(timeout), ctypes.byref(result)
                )
                err = int(ctypes.get_last_error())
                return bool(ok), int(result.value), err
            except Exception:
                return False, 0, -1

        # 1) The top-level VCL form is the natural WM_SYSCHAR target.
        ok1, r1, e1 = send(self.hwnd, WM_SYSCHAR, ord('Q'), keydata)
        self.log.write(
            f"已直接送 WM_SYSCHAR('Q') 給 IC卡上傳主視窗：ok={int(ok1)} result={r1} error={e1}。"
        )
        if ok1:
            time.sleep(0.10)
            if self._wait_confirm(1.2):
                return True

        # 2) Direct VCL message to the form.  This bypasses the Win32 translation
        # stage and enters VCL's mnemonic-dispatch path directly.
        ok2, r2, e2 = send(self.hwnd, CM_DIALOGCHAR, ord('Q'), keydata)
        self.log.write(
            f"已直接送 VCL CM_DIALOGCHAR('Q')：ok={int(ok2)} result={r2} error={e2}。"
        )
        if ok2:
            time.sleep(0.10)
            if self._wait_confirm(1.2):
                return True

        # 3) Some old VCL forms route mnemonic handling through the currently
        # focused child first.  Find the target GUI thread's focus HWND and send
        # WM_SYSCHAR there too.  This is still message-based, not keyboard input.
        try:
            pid = wintypes.DWORD(0)
            tid = int(user32.GetWindowThreadProcessId(int(self.hwnd), ctypes.byref(pid)) or 0)

            class GUITHREADINFO(ctypes.Structure):
                _fields_ = [
                    ('cbSize', wintypes.DWORD), ('flags', wintypes.DWORD),
                    ('hwndActive', wintypes.HWND), ('hwndFocus', wintypes.HWND),
                    ('hwndCapture', wintypes.HWND), ('hwndMenuOwner', wintypes.HWND),
                    ('hwndMoveSize', wintypes.HWND), ('hwndCaret', wintypes.HWND),
                    ('rcCaret', wintypes.RECT),
                ]

            gi = GUITHREADINFO()
            gi.cbSize = ctypes.sizeof(GUITHREADINFO)
            focus_hwnd = 0
            if tid and user32.GetGUIThreadInfo(tid, ctypes.byref(gi)):
                focus_hwnd = int(gi.hwndFocus or 0)

            if focus_hwnd and focus_hwnd != int(self.hwnd):
                ok3, r3, e3 = send(focus_hwnd, WM_SYSCHAR, ord('Q'), keydata)
                self.log.write(
                    f"已直接送 WM_SYSCHAR('Q') 給 VCL focus HWND={focus_hwnd}："
                    f"ok={int(ok3)} result={r3} error={e3}。"
                )
                if ok3:
                    time.sleep(0.10)
                    if self._wait_confirm(1.2):
                        return True
        except Exception as e:
            self.log.write(f"VCL focus HWND 訊息備援失敗：{e}")

        return False

    def _trigger_query_system_only(self):
        """Q查詢：優先走 VCL/Win32 訊息，不依賴 RDP 鍵盤焦點。"""
        self.log.write(
            "開始執行『Q查詢』：v3.2.0 不再先模擬鍵盤，"
            "直接走 WM_SYSCHAR / CM_DIALOGCHAR 的 VCL 助憶鍵路徑。"
        )

        # Primary: no keyboard, no mouse, no foreground dependency.
        if self._send_vcl_query_mnemonic():
            dlg = self._wait_confirm(0.6)
            if dlg:
                self.log.write(
                    "VCL 訊息已直接觸發 Q查詢，偵測到 Confirm。"
                )
                return dlg

        self.log.write(
            "VCL 訊息路徑未看到 Confirm；最後才使用已驗證焦點後的人工節奏 Alt+Q 備援。"
        )

        # Last-resort compatibility fallback only.
        if self._force_uploader_foreground_for_keyboard():
            time.sleep(0.15)
            self._send_alt_q_sendinput()
            dlg = self._wait_confirm(3.0)
            if dlg:
                self.log.write(
                    "鍵盤備援 Alt+Q 已觸發 Q查詢，偵測到 Confirm。"
                )
                return dlg

        self.log.write(
            "VCL 訊息與鍵盤備援都未看到 Confirm；本次停止，避免誤判為已查詢。"
        )
        return None

    def _trigger_toolbar_system_once(self, keyword: str, fallback_name: str, label: str = "") -> bool:
        """Activate one uploader toolbar command without physical mouse input.

        The uploader appears to be a legacy Delphi/VCL style toolbar.  Its
        buttons are sometimes non-windowed/custom-drawn, so normal UIA
        click_input is unreliable.  We therefore prefer a Windows message
        sent to the icon's owning HWND, then fall back to accessibility/default
        action and WM_COMMAND.
        """
        label = label or keyword
        self._activate(maximize=True)

        # Primary route for this legacy toolbar: send mouse messages directly
        # to the HWND under the icon center.  This does not move the cursor.
        if self._system_click_reference_point(fallback_name, label):
            return True

        # Accessibility/default-action route when the item is exposed.
        ctrl = self._find_keyword_control_any_backend(keyword)
        if ctrl is not None and self._invoke_control_system(ctrl, keyword):
            return True

        # Standard command route for a child control with a control ID.
        if self._send_command_for_reference_point(fallback_name, label):
            return True

        return False

    def _trigger_select_all_system(self) -> bool:
        """執行全選；v3.2.6 只信任真正的 toolbar Click 或舊原生命令。"""
        if self._invoke_toolbar_child_message("全選"):
            return True

        # MSAA/UIA accDoDefaultAction 已在實機證明會「回報成功但沒有勾選」，
        # 因此不再把它當作可用的全選路徑。
        if self._send_native_toolbar_command("全選"):
            self.log.write(
                "工具列直接 Click 不可用，改由舊原生 toolbar command 執行『全選』。"
            )
            return True

        return False

    def _click_toolbar(self, keyword: str, fallback_name: str):
        """Execute uploader toolbar commands through the actual toolbar child."""
        logical = "結束" if "結束" in keyword else keyword

        if logical == "結束":
            if self._invoke_exit_via_syschar():
                return
            if self._invoke_toolbar_child_message("結束"):
                return
        else:
            if self._invoke_toolbar_child_message(logical):
                return

        # Do not trust MSAA/UIA accDoDefaultAction here; on this legacy VCL
        # toolbar it can return success without executing the action.
        if self._send_native_toolbar_command(logical):
            self.log.write(
                f"工具列直接訊息不可用，改由舊原生 WM_COMMAND 執行『{keyword}』。"
            )
            return

        raise RuntimeError(
            f"無法從 IC卡資料上傳作業真正的工具列子項目啟動『{keyword}』。"
        )

    def _dialog_text(self, w) -> str:
        parts = []
        try:
            for c in visible_controls(w):
                n = _safe_name(c).strip()
                if n and n not in parts:
                    parts.append(n)
        except Exception:
            pass
        try:
            hwnd = int(w.handle)
        except Exception:
            hwnd = 0
        if hwnd:
            for n in win32_window_texts(hwnd):
                if n and n not in parts:
                    parts.append(n)
        return " | ".join(parts)

    def _wrap_dialog_hwnd(self, hwnd: int):
        for backend in ("uia", "win32"):
            try:
                return self._desktop(backend).window(handle=hwnd).wrapper_object()
            except Exception:
                continue
        return None

    def _find_dialog(self, titles: Sequence[str] = (), content_keywords: Sequence[str] = ()):
        # UIA and Win32 pywinauto desktop passes.
        for backend in ("uia", "win32"):
            try:
                wins = self._desktop(backend).windows()
            except Exception:
                wins = []
            for w in wins:
                title = _safe_name(w)
                try:
                    if self.hwnd and int(w.handle) == int(self.hwnd):
                        continue
                except Exception:
                    pass
                ntitle = normalize_text(title)
                if titles and any(normalize_text(t) in ntitle for t in titles):
                    return w
                if content_keywords:
                    txt = normalize_text(self._dialog_text(w))
                    if all(normalize_text(k) in txt for k in content_keywords):
                        return w

        # Raw Win32 pass for standard modal dialogs that UIA occasionally misses.
        for x in enum_top_windows():
            hwnd = x.get("hwnd", 0)
            if self.hwnd and int(hwnd or 0) == int(self.hwnd):
                continue
            title = x.get("title", "")
            ntitle = normalize_text(title)
            if titles and any(normalize_text(t) in ntitle for t in titles):
                return self._wrap_dialog_hwnd(hwnd)
            if content_keywords:
                txt = normalize_text(" | ".join(win32_window_texts(hwnd)))
                if all(normalize_text(k) in txt for k in content_keywords):
                    return self._wrap_dialog_hwnd(hwnd)
        return None

    def _accept_dialog(self, dialog, label="OK"):
        """Close a modal dialog without relying on foreground focus or mouse.

        v3.2.3:
        1) find the real OK/確定 child button and BM_CLICK it;
        2) fallback to WM_COMMAND/IDOK on the dialog;
        3) only then use focused Enter as a last resort.
        Success is verified by waiting for the dialog HWND to disappear.
        """
        if not dialog:
            return False

        msg = self._dialog_text(dialog)
        if msg:
            # Only dialog text is logged; never dump the patient grid.
            self.log.write(f"對話框：{msg[:500]}")

        try:
            hwnd = int(dialog.handle)
        except Exception:
            hwnd = 0

        if not hwnd or os.name != "nt":
            try:
                dialog.set_focus()
            except Exception:
                pass
            press_key("enter")
            return True

        user32 = ctypes.windll.user32
        BM_CLICK = 0x00F5
        WM_COMMAND = 0x0111
        IDOK = 1

        def wait_closed(seconds=1.5):
            deadline = time.time() + seconds
            while time.time() < deadline:
                try:
                    if not user32.IsWindow(int(hwnd)):
                        return True
                except Exception:
                    return True
                time.sleep(0.05)
            return False

        def send_click(child_hwnd):
            if not child_hwnd:
                return False
            try:
                result = ctypes.c_size_t(0)
                SMTO_ABORTIFHUNG = 0x0002
                ok = user32.SendMessageTimeoutW(
                    int(child_hwnd), BM_CLICK, 0, 0,
                    SMTO_ABORTIFHUNG, 1200, ctypes.byref(result)
                )
                return bool(ok)
            except Exception:
                try:
                    user32.SendMessageW(int(child_hwnd), BM_CLICK, 0, 0)
                    return True
                except Exception:
                    return False

        # Route 1: standard IDOK child.
        try:
            ok_hwnd = int(user32.GetDlgItem(int(hwnd), IDOK) or 0)
        except Exception:
            ok_hwnd = 0

        if ok_hwnd:
            self.log.write(
                f"直接對 Confirm 的 IDOK 按鈕送 BM_CLICK（HWND={ok_hwnd}）。"
            )
            send_click(ok_hwnd)
            if wait_closed():
                self.log.write("Confirm 已由 BM_CLICK 關閉。")
                return True

        # Route 2: enumerate old Delphi/VCL child controls and locate caption OK/確定.
        candidates = []
        WNDENUMPROC = ctypes.WINFUNCTYPE(
            wintypes.BOOL, wintypes.HWND, wintypes.LPARAM
        )

        wanted = {
            normalize_text(label),
            normalize_text("OK"),
            normalize_text("確定"),
            normalize_text("確認"),
        }

        @WNDENUMPROC
        def enum_child(child, lparam):
            try:
                length = int(user32.GetWindowTextLengthW(child) or 0)
                buf = ctypes.create_unicode_buffer(max(2, length + 2))
                user32.GetWindowTextW(child, buf, len(buf))
                caption = buf.value or ""

                clsbuf = ctypes.create_unicode_buffer(128)
                user32.GetClassNameW(child, clsbuf, len(clsbuf))
                cls = clsbuf.value or ""

                ncap = normalize_text(caption)
                if ncap in wanted or any(x in ncap for x in wanted if x):
                    score = 0
                    if "button" in cls.lower():
                        score += 100
                    if ncap == normalize_text("OK"):
                        score += 50
                    elif ncap == normalize_text(label):
                        score += 40
                    if user32.IsWindowVisible(child):
                        score += 20
                    if user32.IsWindowEnabled(child):
                        score += 20
                    candidates.append((score, int(child), caption, cls))
            except Exception:
                pass
            return True

        try:
            user32.EnumChildWindows(int(hwnd), enum_child, 0)
        except Exception:
            pass

        if candidates:
            candidates.sort(reverse=True)
            _, child_hwnd, caption, cls = candidates[0]
            self.log.write(
                f"找到 Confirm 子按鈕『{caption}』 class={cls} HWND={child_hwnd}，"
                "直接送 BM_CLICK。"
            )
            send_click(child_hwnd)
            if wait_closed():
                self.log.write("Confirm 已由子按鈕 BM_CLICK 關閉。")
                return True

        # Route 3: standard dialog command. This does not require keyboard focus.
        try:
            result = ctypes.c_size_t(0)
            SMTO_ABORTIFHUNG = 0x0002
            ok = user32.SendMessageTimeoutW(
                int(hwnd), WM_COMMAND, IDOK, 0,
                SMTO_ABORTIFHUNG, 1200, ctypes.byref(result)
            )
            self.log.write(
                f"BM_CLICK 未關閉 Confirm；改送 WM_COMMAND/IDOK：ok={int(bool(ok))}。"
            )
        except Exception:
            try:
                user32.SendMessageW(int(hwnd), WM_COMMAND, IDOK, 0)
            except Exception:
                pass

        if wait_closed():
            self.log.write("Confirm 已由 WM_COMMAND/IDOK 關閉。")
            return True

        # Route 4: last resort only.
        try:
            activate_hwnd(hwnd, maximize=False)
            dialog.set_focus()
        except Exception:
            pass
        press_key("enter")

        if wait_closed():
            self.log.write("Confirm 已由 Enter 備援關閉。")
            return True

        self.log.write("已嘗試 BM_CLICK / IDOK / Enter，但 Confirm 仍未關閉。")
        return False

    def _native_text_contains(self, keywords: Sequence[str]) -> bool:
        targets = [normalize_text(k) for k in keywords]
        for scope in (self.win_uia, self.win_win32, self.win):
            if scope is None:
                continue
            try:
                txt = normalize_text(" | ".join(_safe_name(c) for c in visible_controls(scope)))
                if all(t in txt for t in targets):
                    return True
            except Exception:
                pass
        if self.hwnd:
            txt = normalize_text(" | ".join(win32_window_texts(self.hwnd)))
            if all(t in txt for t in targets):
                return True
        return False

    def _scaled_rect(self, rect):
        """Scale a reference 1920x1080 rectangle to the current desktop size."""
        import pyautogui
        sw, sh = pyautogui.size()
        l, t, r, b = rect
        return (
            round(l * sw / REFERENCE_W),
            round(t * sh / REFERENCE_H),
            round(r * sw / REFERENCE_W),
            round(b * sh / REFERENCE_H),
        )

    def _grab_roi(self, rect):
        """Capture an in-memory screenshot ROI; the image is never saved/logged."""
        import pyautogui
        l, t, r, b = self._scaled_rect(rect)
        if r <= l or b <= t:
            return None
        return pyautogui.screenshot(region=(l, t, r - l, b - t))

    @staticmethod
    def _dark_pixel_count(img, threshold=120):
        if img is None:
            return 0
        try:
            hist = img.convert("L").histogram()
            return int(sum(hist[: max(1, min(255, int(threshold))) ]))
        except Exception:
            return 0

    def _query_row_has_visible_data(self):
        """確認查詢結果第一列是否真的有資料。

        v3.2.2 同時檢查目前實機版面與舊版面，避免因表格垂直位置改變
        而把已查到的資料誤判成空白。
        """
        best_dark = 0
        for rect in NATIVE_DATA_ROW_ROIS:
            try:
                img = self._grab_roi(rect)
                dark = self._dark_pixel_count(img, threshold=120)
                best_dark = max(best_dark, dark)
                if dark >= 180:
                    return True, dark
            except Exception:
                pass
        return False, best_dark

    def _grid_signature(self):
        values = []
        for rect in NATIVE_GRID_ROIS:
            try:
                img = self._grab_roi(rect)
                values.append(self._dark_pixel_count(img, threshold=120))
            except Exception:
                pass
        return max(values) if values else 0

    def _visual_busy_present(self):
        """偵測「資料讀取中，請稍候!」自繪提示。"""
        for rect in NATIVE_BUSY_ROIS:
            try:
                img = self._grab_roi(rect)
                if self._dark_pixel_count(img, threshold=120) >= 400:
                    return True
            except Exception:
                pass
        return False

    def _wait_query_results_ready(self, timeout=None, baseline_sig=None):
        """等待查詢結果完成。

        v3.2.4 不再要求整張 Grid 像素長時間完全穩定。
        只要：
        1. 查詢結果資料列已連續出現數次；
        2. 畫面不再真正顯示「資料讀取中」文字；
        就視為查詢完成並進入全選。

        這可避免自繪 Grid 因捲軸/游標/重繪造成像素持續變動而誤判逾時。
        """
        if timeout is None:
            timeout = max(20, min(int(self.s.native_wait_seconds), 60))

        self.log.write(
            "等待查詢結果；資料列一旦持續出現且『資料讀取中』結束，"
            "就立即進入『全選』。"
        )

        started = time.time()
        deadline = started + timeout
        seen_busy_text = False
        row_seen_at = None
        consecutive_rows = 0
        last_blank_sig = None
        blank_stable_since = None
        last_no_data_scan = 0.0

        if baseline_sig is None:
            baseline_sig = self._grid_signature()

        while time.time() < deadline:
            # IMPORTANT:
            # 有資料列後不再用大面積 visual_busy ROI 判斷 busy，
            # 因為表格文字本身會造成大量深色像素而誤判。
            busy_text = self._native_text_contains(("資料讀取中",))

            if busy_text:
                if not seen_busy_text:
                    self.log.write("偵測到『資料讀取中，請稍候!』，等待查詢完成。")
                seen_busy_text = True
                consecutive_rows = 0
                row_seen_at = None

            has_row, row_dark = self._query_row_has_visible_data()
            sig = self._grid_signature()

            if has_row:
                if row_seen_at is None:
                    row_seen_at = time.time()
                    self.log.write(
                        "已偵測到查詢結果資料列；改用資料列持續出現判定完成，"
                        "不再等待整張 Grid 像素完全穩定。"
                    )

                consecutive_rows += 1

                # Once actual data rows are visible, ignore the old visual-busy
                # detector. Only real UI text "資料讀取中" can keep us waiting.
                if not busy_text:
                    visible_for = time.time() - row_seen_at
                    if consecutive_rows >= 3 and visible_for >= 0.55:
                        self.log.write(
                            f"查詢結果已持續顯示 {visible_for:.1f} 秒，"
                            "判定資料已可操作，立即進入『全選』。"
                        )
                        return True

                blank_stable_since = None
                last_blank_sig = None

            else:
                consecutive_rows = 0
                row_seen_at = None

                # Some uploader builds show a modal "查無資料" message. Close
                # that dialog before treating the query as an empty result; the
                # old flow could otherwise wait until timeout or mistake a grid
                # header for a patient row.
                no_data_phrases = (
                    "查無資料", "無符合資料", "沒有任何上傳資料",
                    "沒有上傳資料", "沒有可上傳資料", "沒有資料", "無資料",
                )
                no_data_dialog = None
                if time.time() - last_no_data_scan >= 0.8:
                    last_no_data_scan = time.time()
                    for phrase in no_data_phrases:
                        no_data_dialog = self._find_dialog(content_keywords=(phrase,))
                        if no_data_dialog:
                            break
                if no_data_dialog:
                    self.log.write("偵測到無資料提示，關閉提示並略過全選與上傳。")
                    self._accept_dialog(no_data_dialog, "OK")
                    return False

                if any(self._native_text_contains((phrase,)) for phrase in no_data_phrases):
                    self.log.write(
                        "查詢完成，系統顯示沒有可上傳資料；"
                        "直接關閉上傳程式與本次 PHIS 網頁。"
                    )
                    return False

                # No-data fallback: only when grid remains essentially the same
                # as baseline for a few seconds and no busy text is present.
                if last_blank_sig is None:
                    blank_stable_since = time.time()
                else:
                    tol = max(100, int(max(last_blank_sig, 1) * 0.02))
                    if abs(sig - last_blank_sig) > tol:
                        blank_stable_since = time.time()
                last_blank_sig = sig

                base_tol = max(180, int(max(baseline_sig or 1, 1) * 0.04))
                grid_still_baseline = abs(sig - (baseline_sig or 0)) <= base_tol
                blank_stable = (
                    blank_stable_since is not None
                    and time.time() - blank_stable_since >= 3.0
                )

                if (
                    not busy_text
                    and grid_still_baseline
                    and blank_stable
                    and time.time() - started >= 5.0
                ):
                    self.log.write(
                        "查詢後表格持續空白且沒有資料列，"
                        "判定本次沒有看診資料。"
                    )
                    return False

            time.sleep(0.20)

        if row_seen_at is not None:
            # Fail-open only for the safe transition to Select All: actual data
            # rows are visibly present. Upload is still separately gated by
            # selection verification and final success dialog.
            self.log.write(
                "等待查詢完成已達上限，但資料列仍明確存在；"
                "為避免卡死，允許進入『全選』，後續仍保留勾選與上傳成功驗證。"
            )
            return True

        raise RuntimeError(
            f"查詢後等待 {int(timeout)} 秒仍無法可靠判定有資料或無資料；"
            "為避免誤判，本次停止。"
        )

    def _selection_column_snapshots(self):
        """Capture only the checkbox/selection column; no patient text columns."""
        shots = []
        for rect in NATIVE_SELECTION_COLUMN_ROIS:
            try:
                img = self._grab_roi(rect)
                if img is not None:
                    shots.append(img.convert("RGB"))
            except Exception:
                pass
        return shots

    @staticmethod
    def _image_changed_pixels(before_img, after_img, threshold=35):
        if before_img is None or after_img is None:
            return 0
        if before_img.size != after_img.size:
            return 999999
        changed = 0
        for a, b in zip(before_img.getdata(), after_img.getdata()):
            if (
                abs(int(a[0]) - int(b[0])) >= threshold
                or abs(int(a[1]) - int(b[1])) >= threshold
                or abs(int(a[2]) - int(b[2])) >= threshold
            ):
                changed += 1
        return changed

    def _selection_column_changed(self, before_shots):
        after_shots = self._selection_column_snapshots()
        if not before_shots or not after_shots:
            return False, 0
        best = 0
        for b, a in zip(before_shots, after_shots):
            best = max(best, self._image_changed_pixels(b, a, threshold=30))
        # Checking many boxes changes a substantial number of pixels.
        return best >= 120, best

    def _first_checkbox_state(self):
        """Return True/False when the first result-row checkbox can be verified.

        UIA/Win32 is attempted first.  If this old grid does not expose its
        checkbox, inspect the fixed checkbox ROI.  The selected state has a
        strong colored fill (blue on the user's Windows theme), while the
        unchecked state is essentially gray/white.
        """
        # Route 1: native checkbox controls, if exposed.
        exposed = []
        for scope in (self.win_uia, self.win_win32, self.win):
            if scope is None:
                continue
            try:
                for c in visible_controls(scope, ("CheckBox",)):
                    state = None
                    for meth in ("get_toggle_state", "get_check_state"):
                        try:
                            state = int(getattr(c, meth)())
                            break
                        except Exception:
                            pass
                    if state is not None:
                        exposed.append(state)
            except Exception:
                pass
        if exposed:
            return any(v not in (0, -1) for v in exposed)

        # Route 2: visual verification of the first-row checkbox.
        # Try current and legacy layouts.
        uncertain = False
        for rect in NATIVE_FIRST_CHECKBOX_ROIS:
            try:
                img = self._grab_roi(rect)
                if img is None:
                    continue
                rgb = img.convert("RGB")
                saturated = 0
                blueish = 0
                for r, g, b in rgb.getdata():
                    if max(r, g, b) - min(r, g, b) >= 55:
                        saturated += 1
                    if b >= 115 and b >= g + 14 and b >= r + 35:
                        blueish += 1

                # Selected cells on this PHIS theme have a visibly colored fill/check.
                if blueish >= 18 or saturated >= 45:
                    return True

                # A clean gray/white empty checkbox.
                if blueish <= 4 and saturated <= 12:
                    continue

                uncertain = True
            except Exception:
                pass

        return None if uncertain else False

    def query(self):
        self._activate(maximize=True)
        self.log.write(f"已切換到 IC卡資料上傳作業(2.0)，等待 {ACTION_DELAY_SECONDS:g} 秒後執行『Q查詢』。")
        time.sleep(ACTION_DELAY_SECONDS)
        # v2.1.4 intentionally keeps the fast v2.1 Chrome/login flow, with Chrome maximized before judgement/clicking.
        # Only the native uploader toolbar uses Windows system-message activation.
        baseline_sig = self._grid_signature()

        dlg = self._trigger_query_system_only()
        if not dlg:
            raise RuntimeError(
                "已嘗試兩次 Alt+Q，但『Q查詢』仍未出現 Confirm；"
                "本次停止以避免誤判為已查詢。"
            )

        self.log.write("已偵測到置頂 Confirm，確認『Q查詢』已真正啟動。")
        self._accept_dialog(dlg, "OK")
        self.log.write("已按下 Confirm 的 OK；開始判斷查詢後是否有看診資料。")

        self._activate(maximize=True)
        return self._wait_query_results_ready(baseline_sig=baseline_sig)

    def _wait_busy_disappear(self, timeout=45, min_wait=3.0):
        # 「資料讀取中，請稍候!」可能是自繪文字，UIA 不一定看得到。
        started = time.time()
        deadline = started + timeout
        seen_busy = False
        while time.time() < deadline:
            busy = self._native_text_contains(("資料讀取中",)) or self._visual_busy_present()
            if busy:
                if not seen_busy:
                    self.log.write("偵測到『資料讀取中，請稍候!』，等待完成。")
                seen_busy = True
            elif seen_busy and (time.time() - started) >= min_wait:
                self.log.write("資料讀取完成。")
                return

            if not seen_busy and (time.time() - started) >= min_wait:
                return
            time.sleep(0.25)

    def select_all(self):
        self._activate(maximize=True)

        before_state = self._first_checkbox_state()
        before_column = self._selection_column_snapshots()

        self.log.write(
            "查詢結果已確認有資料；現在執行『全選』，"
            "並以第一筆 checkbox + 整個選取欄畫面變化雙重驗證。"
        )

        if not self._trigger_select_all_system():
            raise RuntimeError(
                "已確認查詢結果有資料，但無法觸發『全選』。"
            )

        deadline = time.time() + 3.5
        last_state = None
        best_changed = 0

        while time.time() < deadline:
            last_state = self._first_checkbox_state()
            changed, changed_pixels = self._selection_column_changed(before_column)
            best_changed = max(best_changed, changed_pixels)

            if last_state is True:
                self.log.write("已確認第一筆選取框為勾選狀態；『全選』完成。")
                break

            if changed:
                self.log.write(
                    f"選取欄已出現明顯變化（變化像素約 {changed_pixels}），"
                    "判定『全選』已執行。"
                )
                break

            time.sleep(0.15)
        else:
            # Toolbar PostMessage can be accepted while a Delphi custom-drawn
            # button ignores it. Prefer the real TAction only when the target
            # EXE hash matches the analyzed binary and its object pointer passes
            # sanity checks; otherwise retain the safe, fail-closed click retry.
            self.log.write(
                "工具列訊息已送出但勾選狀態未變；嘗試已驗證版本的 VCL『全選』Action。"
            )
            action_sent = self._invoke_vcl_action_direct("全選")
            action_deadline = time.time() + (2.5 if action_sent else 0.0)
            action_confirmed = False
            while time.time() < action_deadline:
                last_state = self._first_checkbox_state()
                changed, changed_pixels = self._selection_column_changed(before_column)
                if last_state is True or changed:
                    self.log.write("VCL TAction 後已確認『全選』生效。")
                    action_confirmed = True
                    break
                time.sleep(0.15)

            if not action_confirmed:
                self.log.write(
                    "VCL Action 未確認生效；重新向工具列送出一次 Click 並再次核對。"
                )
                retry_sent = self._invoke_toolbar_child_message("全選")
                retry_deadline = time.time() + (2.0 if retry_sent else 0.0)
                while time.time() < retry_deadline:
                    last_state = self._first_checkbox_state()
                    changed, changed_pixels = self._selection_column_changed(before_column)
                    if last_state is True or changed:
                        self.log.write("第二次工具列訊息後已確認『全選』生效。")
                        action_confirmed = True
                        break
                    time.sleep(0.15)

            if not action_confirmed:
                raise RuntimeError(
                    "已嘗試工具列 Click 與版本驗證的 VCL Action，但未觀察到勾選變化；"
                    "為避免空白上傳，本次停止。"
                )

        self.log.write("全選已確認；短暫等待 0.25 秒後執行『一鍵上傳』。")
        time.sleep(0.25)

    def no_data_after_select_all_failure(self) -> bool:
        """確認全選失敗是否其實是查詢結果已空白。"""
        phrases = (
            "查無資料", "無符合資料", "沒有任何上傳資料",
            "沒有上傳資料", "沒有可上傳資料", "沒有資料", "無資料",
        )
        for phrase in phrases:
            if self._native_text_contains((phrase,)):
                return True
            if self._find_dialog(content_keywords=(phrase,)):
                return True

        # A stale/empty grid can briefly look like a row during repaint. Require
        # multiple empty readings after the failed click before treating it as
        # no cases; real visible records remain a hard failure for safety.
        empty_reads = 0
        for _ in range(4):
            has_row, _ = self._query_row_has_visible_data()
            if has_row:
                return False
            empty_reads += 1
            time.sleep(0.18)
        return empty_reads == 4

    def _native_pid(self) -> int:
        if os.name != "nt" or not self.hwnd:
            return 0
        pid = wintypes.DWORD(0)
        try:
            ctypes.windll.user32.GetWindowThreadProcessId(
                int(self.hwnd), ctypes.byref(pid)
            )
            return int(pid.value)
        except Exception:
            return 0

    def _native_visible_text(self) -> str:
        """Collect only UI-visible text from the uploader window itself."""
        parts = []
        for scope in (self.win_uia, self.win_win32, self.win):
            if scope is None:
                continue
            try:
                for c in visible_controls(scope):
                    n = _safe_name(c).strip()
                    if n and n not in parts:
                        parts.append(n)
            except Exception:
                pass
        if self.hwnd:
            try:
                for n in win32_window_texts(self.hwnd):
                    if n and n not in parts:
                        parts.append(n)
            except Exception:
                pass
        return " | ".join(parts)

    def _find_upload_result_raw(self):
        """Find the final Exchnhimgrdmu upload-result dialog.

        v3.2.9:
        Delphi TLabel text inside this dialog may be windowless, so raw
        GetWindowText can see only the dialog title and OK button.  Therefore:
        - title "Exchnhimgrdmu" is a strong result-dialog signal;
        - use UIA/MSAA wrapper text as a second channel;
        - do not require same PID, because some launcher/runtime builds can put
          modal windows in a related helper process.
        """
        if os.name != "nt":
            return 0, ""

        user32 = ctypes.windll.user32
        found = []

        WNDENUMPROC = ctypes.WINFUNCTYPE(
            wintypes.BOOL, wintypes.HWND, wintypes.LPARAM
        )

        @WNDENUMPROC
        def enum_top(hwnd, lparam):
            try:
                if not user32.IsWindowVisible(hwnd):
                    return True

                if self.hwnd and int(hwnd) == int(self.hwnd):
                    return True

                length = int(user32.GetWindowTextLengthW(hwnd) or 0)
                buf = ctypes.create_unicode_buffer(max(2, length + 2))
                user32.GetWindowTextW(hwnd, buf, len(buf))
                title = (buf.value or "").strip()
                ntitle = normalize_text(title)

                raw_texts = win32_window_texts(int(hwnd))
                combined_parts = [title] + list(raw_texts)

                # UIA/MSAA often exposes Delphi TLabel even when Win32 does not.
                wrapped = self._wrap_dialog_hwnd(int(hwnd))
                if wrapped is not None:
                    try:
                        ui_txt = self._dialog_text(wrapped)
                        if ui_txt:
                            combined_parts.append(ui_txt)
                    except Exception:
                        pass

                combined = " | ".join(
                    p for p in combined_parts if p
                )
                n = normalize_text(combined)

                # A generic OK control is not enough to identify a PHIS result
                # dialog: Explorer and unrelated windows can expose OK through
                # UIA/MSAA. Require the known Delphi form title or explicit
                # upload-completion text before considering the HWND.
                has_result_title = "exchnhimgrdmu" in ntitle
                has_result_phrase = any(
                    phrase in n
                    for phrase in ("執行上傳完成", "一鍵上傳完成")
                )
                if not (has_result_title or has_result_phrase):
                    return True

                score = 0
                if has_result_title:
                    score += 1000
                if "執行上傳完成" in n:
                    score += 600
                elif "一鍵上傳完成" in n:
                    score += 500
                if "成功" in n:
                    score += 120
                if "失敗" in n:
                    score += 80
                if normalize_text("OK") in n:
                    score += 40

                found.append((score, int(hwnd), combined, title))

            except Exception:
                pass
            return True

        try:
            user32.EnumWindows(enum_top, 0)
        except Exception:
            pass

        if not found:
            return 0, ""

        found.sort(reverse=True)
        _, hwnd, combined, title = found[0]

        self.log.write(
            f"已鎖定可能的上傳結果視窗：title={title!r} HWND={hwnd}。"
        )
        return hwnd, combined

    def _resolve_upload_result_text(self, result_hwnd: int, result_text: str):
        """Resolve final upload result via dialog text + main-window status.

        Returns (resolved_text, completed, success_count, fail_count, success).
        """
        pieces = []
        if result_text:
            pieces.append(result_text)

        # Re-read the modal through UIA in case its TLabel appeared slightly later.
        dlg = self._wrap_dialog_hwnd(result_hwnd) if result_hwnd else None
        if dlg is not None:
            try:
                t = self._dialog_text(dlg)
                if t:
                    pieces.append(t)
            except Exception:
                pass

        # The uploader main form itself shows:
        # [執行上傳完成] 已執行...成功54筆、失敗0筆
        # This is an independent confirmation channel.
        try:
            native_text = self._native_visible_text()
            if native_text:
                pieces.append(native_text)
        except Exception:
            native_text = ""

        resolved = " | ".join(p for p in pieces if p)

        completed = (
            "執行上傳完成" in resolved
            or "上傳完成" in resolved
        )

        success_count = None
        fail_count = None

        # Accept forms such as 成功54筆 / 成功 54 筆 / 成功:54筆.
        ms = re.search(r"成功\s*[:：]?\s*(\d+)\s*筆", resolved)
        if ms:
            success_count = int(ms.group(1))

        mf = re.search(r"失敗\s*[:：]?\s*(\d+)\s*筆", resolved)
        if mf:
            fail_count = int(mf.group(1))

        success = bool(
            completed
            and fail_count == 0
            and (success_count is None or success_count > 0)
        )

        return (
            resolved,
            completed,
            success_count,
            fail_count,
            success,
        )

    def _press_enter_raw_hwnd(self, hwnd: int, context="結果視窗") -> bool:
        """Activate a confirmed result dialog and press Enter as the user does."""
        if os.name != "nt" or not hwnd:
            return False
        user32 = ctypes.windll.user32
        VK_RETURN = 0x0D
        KEYEVENTF_KEYUP = 0x0002
        try:
            self.log.write(f"{context}：依使用者操作需求切至視窗並按 Enter。")
            user32.ShowWindow(int(hwnd), 9)  # SW_RESTORE
            user32.SetForegroundWindow(int(hwnd))
            user32.SetActiveWindow(int(hwnd))
            time.sleep(0.12)
            if int(user32.GetForegroundWindow() or 0) != int(hwnd):
                self.log.write(f"{context}未能切至前景；跳過 Enter，改用按鈕訊息備援。")
                return False
            user32.keybd_event(VK_RETURN, 0, 0, 0)
            user32.keybd_event(VK_RETURN, 0, KEYEVENTF_KEYUP, 0)
            deadline = time.time() + 2.0
            while time.time() < deadline:
                if not user32.IsWindow(int(hwnd)):
                    self.log.write(f"{context}已由 Enter 關閉。")
                    return True
                time.sleep(0.05)
        except Exception as exc:
            self.log.write(f"{context}按 Enter 失敗：{exc}")
        return False

    def _click_ok_raw_hwnd(self, hwnd: int, context="結果視窗") -> bool:
        """Close a Delphi/Win32 dialog by clicking its real OK button.

        Uses only target-window messages:
        - BM_CLICK on a child button named OK/確定/確認
        - WM_COMMAND with that button's control ID
        - WM_COMMAND/IDOK fallback
        No foreground focus or physical mouse is required.
        """
        if os.name != "nt" or not hwnd:
            return False

        # The PHIS uploader's completion dialog responds to Enter even when its
        # custom CtrlNotifySink button ignores BM_CLICK/WM_COMMAND.
        if self._press_enter_raw_hwnd(hwnd, context):
            return True

        user32 = ctypes.windll.user32
        BM_CLICK = 0x00F5
        WM_COMMAND = 0x0111
        BN_CLICKED = 0
        IDOK = 1

        def window_gone():
            try:
                return not bool(user32.IsWindow(int(hwnd)))
            except Exception:
                return True

        def wait_gone(timeout=2.0):
            deadline = time.time() + timeout
            while time.time() < deadline:
                if window_gone():
                    return True
                time.sleep(0.05)
            return window_gone()

        # Enumerate candidate button controls.
        candidates = []
        WNDENUMPROC = ctypes.WINFUNCTYPE(
            wintypes.BOOL, wintypes.HWND, wintypes.LPARAM
        )

        @WNDENUMPROC
        def enum_child(child, lparam):
            try:
                length = int(user32.GetWindowTextLengthW(child) or 0)
                buf = ctypes.create_unicode_buffer(max(2, length + 2))
                user32.GetWindowTextW(child, buf, len(buf))
                caption = (buf.value or "").strip()

                clsbuf = ctypes.create_unicode_buffer(128)
                user32.GetClassNameW(child, clsbuf, len(clsbuf))
                cls = clsbuf.value or ""

                ncap = normalize_text(caption)
                score = 0
                if ncap == normalize_text("OK"):
                    score += 300
                elif ncap in (
                    normalize_text("確定"),
                    normalize_text("確認"),
                ):
                    score += 250
                if "button" in cls.lower():
                    score += 120
                if cls.lower().startswith("tbutton"):
                    score += 80
                if user32.IsWindowVisible(child):
                    score += 20
                if user32.IsWindowEnabled(child):
                    score += 20

                if score > 0:
                    candidates.append(
                        (score, int(child), caption, cls)
                    )
            except Exception:
                pass
            return True

        try:
            user32.EnumChildWindows(int(hwnd), enum_child, 0)
        except Exception:
            pass

        candidates.sort(reverse=True)

        # Route 1: direct BM_CLICK on real OK button.
        for _, child, caption, cls in candidates:
            try:
                self.log.write(
                    f"{context}：找到『{caption or 'OK'}』按鈕 "
                    f"class={cls} HWND={child}，直接送 BM_CLICK。"
                )
                user32.SendMessageW(
                    int(child), BM_CLICK, 0, 0
                )
                if wait_gone(1.5):
                    self.log.write(f"{context}已由 BM_CLICK 關閉。")
                    return True
            except Exception:
                pass

            # Route 2: send the exact child control ID to parent.
            try:
                ctrl_id = int(user32.GetDlgCtrlID(int(child)))
                if ctrl_id > 0:
                    wparam = (
                        (BN_CLICKED << 16)
                        | (ctrl_id & 0xFFFF)
                    )
                    self.log.write(
                        f"BM_CLICK 未關閉；改送 WM_COMMAND "
                        f"control_id={ctrl_id}。"
                    )
                    user32.SendMessageW(
                        int(hwnd),
                        WM_COMMAND,
                        wparam,
                        int(child),
                    )
                    if wait_gone(1.5):
                        self.log.write(
                            f"{context}已由 WM_COMMAND 子按鈕關閉。"
                        )
                        return True
            except Exception:
                pass

        # Route 3: standard IDOK.
        try:
            self.log.write(
                f"{context}：改直接送 WM_COMMAND / IDOK。"
            )
            user32.SendMessageW(
                int(hwnd), WM_COMMAND, IDOK, 0
            )
            if wait_gone(1.5):
                self.log.write(f"{context}已由 IDOK 關閉。")
                return True
        except Exception:
            pass

        # Route 4: WM_CLOSE is safe here only because caller has already
        # positively identified the final successful result window.
        try:
            self.log.write(
                f"{context}：OK 訊息皆未關閉，最後送 WM_CLOSE。"
            )
            user32.PostMessageW(
                int(hwnd), 0x0010, 0, 0
            )
            if wait_gone(1.5):
                self.log.write(f"{context}已由 WM_CLOSE 關閉。")
                return True
        except Exception:
            pass

        return False

    def one_click_upload(self):
        self._activate(maximize=True)

        # select_all() already verified the selection state.
        state = self._first_checkbox_state()
        if state is False:
            self.log.write(
                "一鍵上傳前偵測第一筆似乎未勾選；重新執行一次全選。"
            )
            if not self._trigger_select_all_system():
                raise RuntimeError("一鍵上傳前無法重新執行全選。")
            time.sleep(0.25)

        self._click_toolbar("一鍵上傳", "native_one_click")
        self.log.write(
            "『一鍵上傳』Click 已用 PostMessage 非同步送出；"
            "自動化執行緒不再被 Delphi modal 視窗阻塞，"
            "現在開始等待中間 Confirm 與最後『執行上傳完成』結果視窗。"
        )

        # Give the Delphi GUI thread a fraction of a second to dequeue the click
        # and create the first modal/result window.
        time.sleep(0.12)

        deadline = time.time() + self.s.native_wait_seconds
        informational_count = 0

        result_wait_logged = False

        while time.time() < deadline:
            if not result_wait_logged:
                self.log.write(
                    "已進入上傳結果監看迴圈；即使 Exchnhimgrdmu modal 已開啟，"
                    "本執行緒仍會持續偵測並關閉其 OK。"
                )
                result_wait_logged = True

            # -----------------------------------------------------------
            # 1) Final result: raw Win32, same PID, independent of UIA.
            # -----------------------------------------------------------
            result_hwnd, result_text = self._find_upload_result_raw()
            if result_hwnd:
                (
                    resolved_text,
                    completed,
                    success_count,
                    fail_count,
                    success,
                ) = self._resolve_upload_result_text(
                    result_hwnd,
                    result_text,
                )

                if completed:
                    self.log.write(
                        "已由結果視窗/UIA/主程式狀態交叉確認上傳完成："
                        + resolved_text[:500]
                    )

                    if not success:
                        raise RuntimeError(
                            "已偵測到上傳完成，但未確認為「失敗0筆」；"
                            "保留結果視窗供人工查看："
                            + resolved_text[:300]
                        )

                    if not self._click_ok_raw_hwnd(
                        result_hwnd,
                        context="上傳成功結果視窗",
                    ):
                        raise RuntimeError(
                            "已確認上傳成功，但無法關閉最後結果視窗的 OK。"
                        )

                    self.log.write(
                        "已確認上傳成功"
                        + (
                            f"（成功 {success_count} 筆、"
                            f"失敗 {fail_count} 筆）"
                            if success_count is not None
                            and fail_count is not None
                            else "（失敗0筆）"
                        )
                        + "；成功結果視窗已關閉。"
                    )

                    time.sleep(0.15)
                    return resolved_text

                # Result-window title exists but its TLabel/status may not have
                # been exposed yet. Keep polling instead of timing out blindly.
                self.log.write(
                    "已看到 Exchnhimgrdmu 結果視窗，但成功文字尚未由 "
                    "UIA/主程式狀態讀出；繼續短間隔重試。"
                )

            # -----------------------------------------------------------
            # 2) Intermediate informational Confirm.
            # -----------------------------------------------------------
            info = self._find_dialog(
                titles=("Confirm",),
                content_keywords=(),
            )
            if info:
                info_text = self._dialog_text(info)
                ninfo = normalize_text(info_text)

                dangerous = any(
                    k in ninfo
                    for k in (
                        "錯誤",
                        "失敗",
                        "無法",
                        "異常",
                        "未選",
                        "請選",
                        "不可",
                    )
                )

                if dangerous:
                    raise RuntimeError(
                        "一鍵上傳期間出現錯誤/警告 Confirm："
                        + (info_text[:300] or "(無文字)")
                    )

                informational_count += 1
                self.log.write(
                    f"一鍵上傳期間出現第 {informational_count} "
                    "個資訊 Confirm；自動按 OK。"
                )

                if not self._accept_dialog(info, "OK"):
                    raise RuntimeError(
                        "偵測到資訊 Confirm，但無法自動關閉 OK。"
                    )

                if informational_count >= 8:
                    raise RuntimeError(
                        "已連續處理 8 個資訊 Confirm，"
                        "為避免無限循環已停止。"
                    )

                time.sleep(0.08)
                continue

            time.sleep(0.08)

        raise RuntimeError(
            "等待『一鍵上傳』成功結果逾時；"
            "未確認成功前不會自動執行 X結束。"
        )

    def close_after_no_data(self, timeout: float = 2.0) -> bool:
        """Close uploader windows directly after an empty query.

        The normal finish() path is for confirmed uploads and may wait through
        several X-button fallbacks. With no data, close directly and only
        terminate this exact uploader process if its windows remain.
        """
        pid = self._native_pid()
        user32 = ctypes.windll.user32 if os.name == "nt" else None

        def owned_windows():
            if not pid:
                return []
            return [
                int(item.get("hwnd") or 0)
                for item in enum_top_windows()
                if int(item.get("pid") or 0) == pid and int(item.get("hwnd") or 0)
            ]

        windows = owned_windows()
        if self.hwnd and user32 and user32.IsWindow(int(self.hwnd)) and int(self.hwnd) not in windows:
            windows.append(int(self.hwnd))
        for target in windows:
            try:
                user32.PostMessageW(target, 0x0010, 0, 0)  # WM_CLOSE
            except Exception:
                pass

        deadline = time.time() + timeout
        while time.time() < deadline:
            if not owned_windows() and (not self.hwnd or not user32 or not user32.IsWindow(int(self.hwnd))):
                self.log.write("無資料收尾：本次 IC 卡上傳功能視窗已全部關閉。")
                return True
            time.sleep(0.10)

        # Only terminate the exact uploader PID found from its HWND.
        if pid and owned_windows():
            self.log.write(f"無資料收尾：仍有上傳功能視窗，結束本次 ExchNHIMgrDMU PID {pid}。")
            for force, wait_seconds in ((False, 0.8), (True, 1.5)):
                try:
                    cmd = ["taskkill", "/PID", str(pid), "/T"]
                    if force:
                        cmd.append("/F")
                    subprocess.run(cmd, capture_output=True, text=True, timeout=2)
                except Exception:
                    pass
                deadline = time.time() + wait_seconds
                while time.time() < deadline:
                    if not owned_windows() and (not self.hwnd or not user32.IsWindow(int(self.hwnd))):
                        self.log.write("無資料收尾：上傳程式的所有功能視窗已關閉。")
                        return True
                    time.sleep(0.10)

        closed = not owned_windows() and (not self.hwnd or not user32 or not user32.IsWindow(int(self.hwnd)))
        if not closed:
            self.log.write("錯誤：無資料收尾後仍偵測到上傳程式視窗。")
        return closed

    def finish(self):
        if not self.s.auto_close_native:
            self.log.write(
                "設定為保留 IC卡資料上傳作業視窗，不自動結束。"
            )
            return False

        if os.name != "nt" or not self.hwnd:
            return False

        user32 = ctypes.windll.user32

        # Safety: if a successful result dialog somehow still remains,
        # close it before trying to exit the parent.
        residual_hwnd, residual_text = self._find_upload_result_raw()
        if residual_hwnd:
            (
                residual_resolved,
                residual_completed,
                _res_success_count,
                res_fail_count,
                residual_success,
            ) = self._resolve_upload_result_text(
                residual_hwnd,
                residual_text,
            )

            if residual_completed and residual_success:
                self.log.write(
                    "收尾前仍偵測到已成功的上傳結果視窗；先關閉其 OK。"
                )
                self._click_ok_raw_hwnd(
                    residual_hwnd,
                    context="殘留上傳結果視窗",
                )
                time.sleep(0.15)

        def wait_native_closed(timeout):
            deadline = time.time() + timeout
            while time.time() < deadline:
                if not user32.IsWindow(int(self.hwnd)):
                    return True
                time.sleep(0.05)
            return not bool(user32.IsWindow(int(self.hwnd)))

        self.log.write(
            "上傳成功結果已處理；現在執行『X結束』收尾。"
        )

        # Route 1: use the same toolbar-child message mechanism that already
        # succeeded for 全選 / 一鍵上傳.
        try:
            if self._invoke_toolbar_child_message("結束"):
                self.log.write(
                    "已向真正的『X結束』工具列子項目送出 Click。"
                )
                if wait_native_closed(2.5):
                    self.log.write(
                        "IC卡資料上傳作業(2.0) 已由 X結束正常關閉。"
                    )
                    return True
        except Exception as e:
            self.log.write(f"X結束 toolbar 路徑失敗：{e}")

        # Route 2: VCL &X mnemonic.
        try:
            if self._invoke_exit_via_syschar():
                if wait_native_closed(2.0):
                    self.log.write(
                        "IC卡資料上傳作業(2.0) 已由 WM_SYSCHAR('X') 關閉。"
                    )
                    return True
        except Exception as e:
            self.log.write(f"X結束 WM_SYSCHAR 路徑失敗：{e}")

        # Route 3: final safe close, only after upload success was positively
        # confirmed and result OK was closed.
        self.log.write(
            "X結束後視窗仍存在；上傳已確認成功，"
            "最後送 WM_CLOSE 完成原生程式收尾。"
        )
        try:
            user32.PostMessageW(
                int(self.hwnd), 0x0010, 0, 0
            )
        except Exception:
            pass

        if wait_native_closed(3.0):
            self.log.write(
                "IC卡資料上傳作業(2.0) 已關閉。"
            )
            return True

        raise RuntimeError(
            "已確認上傳成功並關閉結果視窗，但 IC卡資料上傳作業仍無法關閉。"
        )



# ----------------------- Visible cycle status -----------------------
class AutomationStatusOverlay:
    """Small non-activating always-on-top banner for scheduled runs.

    Manual GUI runs show the same message inside the main window; scheduled
    --run-once tasks have no main GUI, so this banner lets the user know the
    desktop is currently being controlled by the PHIS automation.
    """

    def __init__(self, text="正在執行自動化健保卡上傳程序"):
        self.text = text
        self._stop = threading.Event()
        self._ready = threading.Event()
        self._thread = None

    def start(self):
        if os.name != "nt":
            return
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        self._ready.wait(2.0)

    def _run(self):
        try:
            import tkinter as tk
            root = tk.Tk()
            root.withdraw()
            root.overrideredirect(True)
            root.attributes("-topmost", True)
            frame = tk.Frame(root, bg="#FFF6CC", bd=2, relief="solid")
            frame.pack(fill="both", expand=True)
            tk.Label(
                frame,
                text=self.text,
                font=("Microsoft JhengHei UI", 15, "bold"),
                bg="#FFF6CC",
                fg="#9A3D00",
                padx=18,
                pady=8,
            ).pack()
            tk.Label(
                frame,
                text="請稍候，程序完成後會自動關閉本次 PHIS 視窗",
                font=("Microsoft JhengHei UI", 10),
                bg="#FFF6CC",
                fg="#444444",
                padx=18,
                pady=4,
            ).pack()
            root.update_idletasks()
            w = max(520, root.winfo_reqwidth())
            h = max(82, root.winfo_reqheight())
            sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
            x = max(10, sw - w - 24)
            y = max(10, sh - h - 90)
            root.geometry(f"{w}x{h}+{x}+{y}")
            root.update_idletasks()
            root.deiconify()
            root.update()

            # Re-show without activating so the automation target keeps focus.
            try:
                hwnd = int(root.winfo_id())
                user32 = ctypes.windll.user32
                SW_SHOWNOACTIVATE = 4
                HWND_TOPMOST = -1
                SWP_NOMOVE = 0x0002
                SWP_NOSIZE = 0x0001
                SWP_NOACTIVATE = 0x0010
                SWP_SHOWWINDOW = 0x0040
                user32.ShowWindow(hwnd, SW_SHOWNOACTIVATE)
                user32.SetWindowPos(
                    hwnd, HWND_TOPMOST, 0, 0, 0, 0,
                    SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_SHOWWINDOW,
                )
            except Exception:
                pass

            def poll_stop():
                if self._stop.is_set():
                    try:
                        root.destroy()
                    except Exception:
                        pass
                    return
                root.after(150, poll_stop)

            self._ready.set()
            root.after(150, poll_stop)
            root.mainloop()
        except Exception:
            self._ready.set()

    def close(self):
        self._stop.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=1.5)


# ----------------------- Main workflow -----------------------
def run_workflow(settings: Settings, logger: Logger, status_callback=None, show_overlay=True):
    require_windows()
    set_dpi_aware()
    ensure_runtime_dependencies(logger)
    # GUI mode runs this function on a background thread. UI Automation uses
    # COM, which must be initialized separately on every worker thread.
    com_token = initialize_com_for_thread(logger)
    mutex = acquire_run_mutex()
    if not mutex:
        uninitialize_com_for_thread(com_token)
        raise RuntimeError("已有一個 PHIS 自動流程正在執行，為避免重複上傳，本次不再啟動。")

    activity_text = "正在執行自動化健保卡上傳程序"
    if status_callback:
        try:
            status_callback(activity_text)
        except Exception:
            pass
    overlay = AutomationStatusOverlay(activity_text) if show_overlay else None
    if overlay:
        overlay.start()

    try:
        logger.write(f"========== 開始 PHIS 自動日上傳 v{APP_VERSION} ==========")
        logger.write(activity_text)
        browser = ChromePHIS(settings, logger)
        startup_started = time.perf_counter()
        browser.start()
        logger.write(f"Chrome 視窗與 DevTools 就緒耗時：{time.perf_counter() - startup_started:.2f} 秒。")

        login_started = time.perf_counter()
        # fill_login already handles a login page, an existing function page,
        # and initial Server Error. Avoid a separate full UIA/visual scan first.
        browser.fill_login()
        browser.wait_login_with_server_retry()
        logger.write(f"PHIS 登入與成功確認耗時：{time.perf_counter() - login_started:.2f} 秒。")
        browser._ensure_maximized(log_once=True)

        # v3.0: after a verified normal PHIS login, replace fragile four-level
        # web-menu clicking with the official local PhisSocket -> InetLoader chain.
        logger.write(
            f"已立即確認 PHIS 正常登入；只等待 {POST_LOGIN_LAUNCH_DELAY:g} 秒後，"
            "立即使用官方 Launcher 啟動健保卡日上傳2.0。"
        )
        time.sleep(POST_LOGIN_LAUNCH_DELAY)
        launcher = PhisSocketLauncher(settings, logger)
        launcher.launch_daily_upload()

        native = NativeUploader(settings, logger)
        native.wait_window(timeout=35)
        has_data = native.query()

        if not has_data:
            logger.write("查詢後沒有任何資料，依設定規則視為本次沒有看診資料；不執行『全選/一鍵上傳』。")
            native_closed = native.close_after_no_data()
            browser_closed = browser.close_opened_window()
            if not native_closed or not browser_closed:
                raise RuntimeError(
                    "今日無待上傳資料，但未能確認所有 PHIS 頁面與功能視窗均已關閉。"
                )
            logger.write("本次循環完成（今日無看診／無待上傳資料）；上傳程式與本次專用 PHIS Chrome 的所有頁面、視窗均已關閉，等待下一個每日排程時間。")
            logger.write("========== PHIS 自動日上傳結束 ==========")
            return True

        try:
            native.select_all()
        except RuntimeError:
            if not native.no_data_after_select_all_failure():
                raise

            logger.write(
                "全選失敗後再次確認查詢區沒有個案；視為無待上傳資料，"
                "關閉提示、健保卡上傳程式與本次 PHIS Chrome。"
            )
            # Reuse the verified Confirm/IDOK/BM_CLICK path for any legacy
            # Delphi informational dialog still open over the empty result.
            no_data_phrases = (
                "查無資料", "無符合資料", "沒有任何上傳資料",
                "沒有上傳資料", "沒有可上傳資料", "沒有資料", "無資料",
            )
            dismissed = False
            for phrase in no_data_phrases:
                dialog = native._find_dialog(content_keywords=(phrase,))
                if dialog:
                    dismissed = native._accept_dialog(dialog, "OK")
                    break
            if not dismissed:
                confirm = native._find_dialog(titles=("Confirm",))
                if confirm:
                    dismissed = native._accept_dialog(confirm, "OK")
            if dismissed:
                logger.write("無個案提示已透過 Confirm 按鈕流程關閉。")

            native_closed = native.close_after_no_data()
            browser_closed = browser.close_opened_window()
            if not native_closed or not browser_closed:
                raise RuntimeError(
                    "已確認無個案，但未能確認健保卡上傳程式與本次 PHIS Chrome 均已關閉。"
                )
            logger.write("無個案收尾完成：健保卡上傳程式及本次 PHIS Chrome 已關閉。")
            logger.write("========== PHIS 自動日上傳結束 ==========")
            return True
        result = native.one_click_upload()

        logger.write(
            "一鍵上傳已確認成功且結果視窗已關閉；"
            "開始執行 X結束與 Chrome 收尾。"
        )

        native_closed = native.finish()
        if not native_closed:
            raise RuntimeError(
                "上傳成功，但 IC卡資料上傳作業未完成關閉。"
            )

        browser_closed = browser.close_opened_window()
        if not browser_closed:
            raise RuntimeError(
                "上傳程式已關閉，但本次 PHIS 專用 Chrome 未完全關閉。"
            )

        logger.write(
            f"流程完成。上傳結果摘要："
            f"{result[:300] if result else '已完成'}"
        )
        logger.write(
            "本次完整循環已完成：成功結果 OK → X結束 → "
            "IC卡上傳程式關閉 → 本次 PHIS Chrome 關閉；"
            "等待下一個排程時間。"
        )
        logger.write("========== PHIS 自動日上傳結束 ==========")
        return True
    except Exception as e:
        logger.write(f"流程失敗：{e}")
        logger.write(traceback.format_exc())
        raise
    finally:
        if overlay:
            overlay.close()
        release_run_mutex(mutex)
        uninitialize_com_for_thread(com_token)


# ----------------------- Task Scheduler -----------------------
class TaskScheduler:
    def __init__(self, logger: Logger):
        self.log = logger

    def _query_names(self):
        if os.name != "nt":
            return []
        proc = subprocess.run(["schtasks", "/Query", "/FO", "CSV", "/NH"], capture_output=True, text=True, encoding="utf-8", errors="ignore")
        rows = []
        try:
            for row in csv.reader(proc.stdout.splitlines()):
                if row:
                    rows.append(row[0])
        except Exception:
            pass
        return rows

    def _runner(self) -> str:
        # This edition always schedules the Python launcher; it never selects an EXE.
        batch = BASE_DIR / "run_scheduled.bat"
        return f'"{batch}"'

    def sync(self, schedule_days: dict[str, Iterable[str]], run_as_admin=True):
        require_windows()
        day_order = ("MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN")
        normalized = {
            t: [day for day in day_order if day in set(days)]
            for t, days in sorted(schedule_days.items())
        }
        empty_times = [t for t, days in normalized.items() if not days]
        if empty_times:
            raise ValueError("以下時段尚未選擇執行星期：" + ", ".join(empty_times))
        # 先清除舊的本工具工作。
        for name in self._query_names():
            short = name.lstrip("\\")
            if short.startswith(TASK_PREFIX):
                subprocess.run(["schtasks", "/Delete", "/TN", name, "/F"], capture_output=True)
        runner = self._runner()
        for t, selected_days in normalized.items():
            hhmm = t.replace(":", "")
            day_tag = "-".join(selected_days)
            task_name = f"\\{TASK_PREFIX}{hhmm}_{day_tag}"
            cmd = [
                "schtasks", "/Create",
                "/TN", task_name,
                "/TR", runner,
                "/SC", "WEEKLY",
                "/D", ",".join(selected_days),
                "/ST", t,
                "/IT",
                "/RL", "HIGHEST" if run_as_admin else "LIMITED",
                "/F",
            ]
            p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="ignore")
            if p.returncode != 0:
                raise RuntimeError(f"建立排程 {t} 失敗：{p.stdout} {p.stderr}")
            level = "系統管理員（最高權限）" if run_as_admin else "目前使用者（一般權限）"
            self.log.write(
                f"已建立每週排程：{t}，執行日 {','.join(selected_days)}；"
                f"權限：{level}；只在使用者登入互動桌面時執行。"
            )


# ----------------------- GUI -----------------------
def launch_gui():
    require_windows()
    hide_console_window()
    set_dpi_aware()
    import tkinter as tk
    import tkinter.font as tkfont
    from tkinter import ttk, messagebox

    settings = Settings()
    root = tk.Tk()
    root.title(f"{APP_NAME} v{APP_VERSION}")
    screen_w = root.winfo_screenwidth()
    screen_h = root.winfo_screenheight()
    # At the reference 1202x876 window size, all tabs and bottom actions fit.
    # Keep that usable size as the resize floor, while choosing a larger start
    # size on larger monitors. The values are Tk client-area pixels.
    min_window_w = 1200
    min_window_h = 842
    start_w = max(min_window_w, min(1600, int(screen_w * 0.72)))
    start_h = max(min_window_h, min(1000, int(screen_h * 0.78)))
    root.geometry(f"{start_w}x{start_h}")
    root.minsize(min_window_w, min_window_h)
    root.configure(bg="#F2F5FA")
    style = ttk.Style(root)
    try:
        style.theme_use("clam")
    except tk.TclError:
        pass
    style.configure(".", font="TkDefaultFont", background="#F2F5FA", foreground="#172B4D")
    style.configure("TFrame", background="#F2F5FA")
    style.configure("Card.TFrame", background="#FFFFFF", relief="solid", borderwidth=1)
    style.configure("TLabel", background="#F2F5FA", foreground="#24364B")
    style.configure("Card.TLabel", background="#FFFFFF", foreground="#24364B")
    style.configure("PageTitle.TLabel", background="#FFFFFF", foreground="#173B68",
                    font=("Microsoft JhengHei UI", 17, "bold"), padding=(0, 0, 0, 8))
    style.configure("PageSub.TLabel", background="#FFFFFF", foreground="#62748A")
    style.configure("TEntry", padding=(8, 7), fieldbackground="#FFFFFF")
    tab_font = tkfont.Font(root=root, family="Microsoft JhengHei UI", size=12, weight="bold")
    action_font = tkfont.Font(root=root, family="Microsoft JhengHei UI", size=12, weight="bold")
    page_title_font = tkfont.Font(root=root, family="Microsoft JhengHei UI", size=17, weight="bold")
    style.configure("PageTitle.TLabel", font=page_title_font)
    style.configure(
        "TNotebook", background="#E8EEF5", borderwidth=0,
    )
    style.configure(
        "TNotebook.Tab", font=tab_font, padding=(14, 9),
        background="#DCE6F1", foreground="#26384B", borderwidth=1,
    )
    style.map(
        "TNotebook.Tab",
        background=[("selected", "#1D4ED8"), ("active", "#BBD4F0")],
        foreground=[("selected", "#FFFFFF"), ("active", "#183A61")],
    )
    style.configure("Help.TLabel", background="#EEF4FA", foreground="#34495E",
                    padding=(12, 9), relief="solid", borderwidth=1)
    style.configure("TButton", font="TkDefaultFont", padding=(12, 8),
                    background="#E8EEF6", foreground="#26384B", borderwidth=0)
    style.configure("Action.TButton", font=action_font, padding=(14, 9),
                    background="#E8EEF6", foreground="#173B68", borderwidth=0)
    style.map("Action.TButton", background=[("active", "#D6E2F1"), ("pressed", "#CBD8E8")])
    for stylename, bg, fg, active in (
        ("SaveAction.TButton", "#1D4ED8", "#FFFFFF", "#1E40AF"),
        ("LogAction.TButton", "#E8EEF6", "#173B68", "#D6E2F1"),
        ("UpdateAction.TButton", "#0F766E", "#FFFFFF", "#115E59"),
        ("CloseAction.TButton", "#FCE8E6", "#9B1C1C", "#F8D7D4"),
    ):
        style.configure(stylename, font=action_font, padding=(14, 9),
                        background=bg, foreground=fg, borderwidth=0)
        style.map(stylename, background=[("active", active), ("pressed", active)],
                  foreground=[("active", fg), ("pressed", fg)])
    style.map("TButton", background=[("active", "#D6E2F1"), ("pressed", "#CBD8E8")])
    style.configure("Primary.TButton", font="TkDefaultFont", padding=(16, 9),
                    background="#1D4ED8", foreground="#FFFFFF", borderwidth=0)
    style.map("Primary.TButton", background=[("active", "#1E40AF"), ("pressed", "#1E3A8A")],
              foreground=[("active", "#FFFFFF"), ("pressed", "#FFFFFF")])
    style.configure("TSpinbox", padding=(6, 5))

    log_widget = None
    ui_log_queue = queue.Queue(maxsize=5000)
    def post_ui(kind, payload=None):
        try:
            ui_log_queue.put_nowait((kind, payload))
        except queue.Full:
            try:
                ui_log_queue.get_nowait()
                ui_log_queue.put_nowait((kind, payload))
            except (queue.Empty, queue.Full):
                pass

    def log_to_ui(line):
        # Logger can be called from automation and scheduler threads. Tk widgets
        # are only touched by the Tk main thread; queueing also batches bursts.
        try:
            ui_log_queue.put_nowait(("log", line))
        except queue.Full:
            try:
                ui_log_queue.get_nowait()
                ui_log_queue.put_nowait(("log", line))
            except (queue.Empty, queue.Full):
                pass
    logger = Logger(log_to_ui)

    # The tray icon is optional: attempt the normal automatic dependency repair
    # at startup, but keep the app usable with ordinary taskbar minimization if
    # installation is unavailable.
    try:
        ensure_runtime_dependencies(logger)
    except Exception as e:
        logger.write(f"系統匣元件無法安裝；最小化時改留在工作列：{e}")

    # Keep the app content scrollable on short screens/high DPI. The action
    # buttons remain inside the content so users can reach them by scrolling.
    viewport = ttk.Frame(root)
    viewport.pack(fill="both", expand=True)
    canvas = tk.Canvas(viewport, bg="#F2F5FA", highlightthickness=0)
    vertical_scroll = ttk.Scrollbar(viewport, orient="vertical", command=canvas.yview)
    canvas.configure(yscrollcommand=vertical_scroll.set)
    canvas.pack(side="left", fill="both", expand=True)
    vertical_scroll.pack(side="right", fill="y")
    main_frame = ttk.Frame(canvas)
    main_window = canvas.create_window((0, 0), window=main_frame, anchor="nw")

    def update_scroll_region(_event=None):
        canvas.configure(scrollregion=canvas.bbox("all"))

    def fit_scroll_content(event):
        canvas.itemconfigure(main_window, width=event.width)

    main_frame.bind("<Configure>", update_scroll_region, add="+")
    canvas.bind("<Configure>", fit_scroll_content, add="+")

    # Branded header creates a clear visual entry point without taking space from the tabs.
    brand = tk.Frame(main_frame, bg="#163B66", padx=18, pady=13)
    brand.pack(fill="x", padx=12, pady=(12, 8))
    badge = tk.Label(brand, text="PHIS", font=("Microsoft JhengHei UI", 13, "bold"),
                     bg="#2F6FED", fg="#FFFFFF", padx=12, pady=7)
    badge.pack(side="left", padx=(0, 14))
    brand_copy = tk.Frame(brand, bg="#163B66")
    brand_copy.pack(side="left", fill="x", expand=True)
    brand_title = tk.Label(brand_copy, text="TimeScheduleAutomation",
                           font=("Microsoft JhengHei UI", 19, "bold"),
                           bg="#163B66", fg="#FFFFFF", anchor="w")
    brand_title.pack(anchor="w")
    brand_subtitle = tk.Label(brand_copy, text="PHIS 自動化管理 · Python 版",
                              font=("Microsoft JhengHei UI", 10),
                              bg="#163B66", fg="#C7D8EF", anchor="w")
    brand_subtitle.pack(anchor="w", pady=(2, 0))
    version_badge = tk.Label(brand, text="v3.4.31", font=("Microsoft JhengHei UI", 10, "bold"),
                             bg="#244F7D", fg="#EAF2FF", padx=10, pady=5)
    version_badge.pack(side="right", anchor="ne")

    nb = ttk.Notebook(main_frame)
    nb.pack(fill="both", expand=True, padx=12, pady=(0, 8))

    activity_var = tk.StringVar(value="待命：等待手動執行或每日排程時間")
    activity_font = tkfont.Font(root=root, family="Microsoft JhengHei UI", size=17, weight="bold")
    activity_banner = tk.Label(
        main_frame,
        textvariable=activity_var,
        font=activity_font,
        bg="#EEF6FF",
        fg="#0A4A8A",
        padx=12,
        pady=10,
        relief="groove",
        bd=2,
        wraplength=820,
    )
    activity_banner.configure(bg="#EAF2FC", fg="#173B68", relief="flat", bd=0)
    activity_banner.pack(fill="x", padx=12, pady=(0, 8))

    # 基本設定
    f1 = ttk.Frame(nb, padding=18, style="Card.TFrame")
    nb.add(f1, text="基本設定")
    ttk.Label(f1, text="連線與帳號", style="PageTitle.TLabel").grid(
        row=0, column=0, columnspan=2, sticky="w", pady=(0, 8))
    ttk.Label(f1, text="PHIS 網址", style="Card.TLabel").grid(row=1, column=0, sticky="w", pady=8)
    url_var = tk.StringVar(value=settings.url)
    url_entry = ttk.Entry(f1, textvariable=url_var, width=62)
    url_entry.grid(row=1, column=1, sticky="ew", pady=8)
    url_entry.bind(
        "<Double-Button-1>",
        lambda _event: url_entry.after_idle(lambda: url_entry.selection_range(0, "end")),
    )

    ttk.Label(f1, text="登入帳號", style="Card.TLabel").grid(row=2, column=0, sticky="w", pady=8)
    user_var = tk.StringVar(value=settings.username)
    ttk.Entry(f1, textvariable=user_var, width=35).grid(row=2, column=1, sticky="ew", pady=8)

    ttk.Label(f1, text="登入密碼", style="Card.TLabel").grid(row=3, column=0, sticky="w", pady=8)
    pass_var = tk.StringVar(value=settings.password)
    password_entry = ttk.Entry(f1, textvariable=pass_var, width=35, show="●")
    password_entry.grid(row=3, column=1, sticky="ew", pady=8)
    show_password_var = tk.BooleanVar(value=False)
    ttk.Checkbutton(
        f1, text="顯示密碼", variable=show_password_var,
        command=lambda: password_entry.configure(show="" if show_password_var.get() else "●"),
    ).grid(row=3, column=2, sticky="w", padx=(12, 0), pady=8)

    ttk.Label(f1, text="PHIS 使用者姓名", style="Card.TLabel").grid(row=4, column=0, sticky="w", pady=8)
    display_name_var = tk.StringVar(value=settings.display_name)
    ttk.Entry(f1, textvariable=display_name_var, width=35).grid(row=4, column=1, sticky="ew", pady=8)

    ttk.Label(f1, text="權限代碼", style="Card.TLabel").grid(row=5, column=0, sticky="w", pady=8)
    permission_var = tk.StringVar(value=settings.permission_level or "5")
    ttk.Entry(f1, textvariable=permission_var, width=10).grid(row=5, column=1, sticky="w", pady=8)
    ttk.Label(f1, text="Server Error 重試間隔(秒)", style="Card.TLabel").grid(row=6, column=0, sticky="w", pady=8)
    retry_var = tk.StringVar(value=str(settings.server_retry_seconds))
    ttk.Entry(f1, textvariable=retry_var, width=10).grid(row=6, column=1, sticky="w", pady=8)

    info = "密碼會以 Windows DPAPI 加密保存於本機。"
    info_label = ttk.Label(f1, text=info, style="Help.TLabel", wraplength=690, justify="left")
    info_label.grid(row=7, column=0, columnspan=3, sticky="ew", pady=(18, 4))
    f1.columnconfigure(1, weight=1)
    f1.columnconfigure(2, weight=0)

    # 流程頁
    f2 = ttk.Frame(nb, padding=18, style="Card.TFrame")
    nb.add(f2, text="自動流程")
    ttk.Label(f2, text="自動上傳流程", style="PageTitle.TLabel").pack(anchor="w")
    ttk.Label(f2, text="依序登入、查詢並完成上傳。", style="PageSub.TLabel").pack(anchor="w", pady=(0, 12))
    steps = (
        "1. 登入 PHIS，啟動健保卡日上傳。\n"
        "2. 查詢資料；無資料時自動結束。\n"
        "3. 有資料時確認後全選並上傳。\n"
        "4. 確認上傳成功後關閉程式。"
    )
    steps_label = ttk.Label(f2, text=steps, style="Help.TLabel", justify="left", wraplength=700)
    steps_label.pack(anchor="w", fill="x", pady=(0,12))

    btn_frame = ttk.Frame(f2)
    btn_frame.pack(fill="x", pady=4)
    run_btn = ttk.Button(btn_frame, text="立即執行", style="Primary.TButton")
    run_btn.pack(side="left")

    status_var = tk.StringVar(value="待命")
    ttk.Label(btn_frame, textvariable=status_var).pack(side="left", padx=14)


    # 排程頁
    f3 = ttk.Frame(nb, padding=18, style="Card.TFrame")
    nb.add(f3, text="每日排程")
    ttk.Label(f3, text="每週執行時間", style="PageTitle.TLabel").pack(anchor="w")
    ttk.Label(f3, text="設定執行時段與星期，排程會在所選日期自動啟動上傳。", style="PageSub.TLabel").pack(anchor="w", pady=(0, 12))
    schedule_info = ttk.Label(
        f3,
        text="新增時段時會套用目前勾選的星期；選取已新增的時段可個別調整星期。執行時請保持 Windows 登入且桌面未鎖定。",
        style="Help.TLabel", wraplength=900,
    )
    schedule_info.pack(anchor="w", fill="x", pady=(0, 12))
    weekday_frame = ttk.Frame(f3)
    weekday_frame.pack(anchor="w", fill="x", pady=(0, 8))
    weekday_labels = (("MON", "週一"), ("TUE", "週二"), ("WED", "週三"),
                      ("THU", "週四"), ("FRI", "週五"), ("SAT", "週六"), ("SUN", "週日"))
    weekday_vars = {}
    for code, label in weekday_labels:
        var = tk.BooleanVar(value=code in settings.weekdays)
        weekday_vars[code] = var
    schedule_days = {
        t: list(settings.schedule_days.get(t, settings.weekdays))
        for t in settings.times
    }
    selected_schedule_time = [None]
    syncing_weekdays = [False]

    def selected_days_now():
        return [code for code, _label in weekday_labels if weekday_vars[code].get()]

    def display_schedule_time(t):
        day_names = [label for code, label in weekday_labels if code in schedule_days.get(t, [])]
        return f"{t}　（{', '.join(day_names) if day_names else '未選星期'}）"

    def refresh_schedule_list(select_time=None):
        if select_time is None:
            select_time = selected_schedule_time[0]
        listbox.delete(0, "end")
        times = sorted(schedule_days)
        for t in times:
            listbox.insert("end", display_schedule_time(t))
        if select_time in times:
            index = times.index(select_time)
            listbox.selection_set(index)
            listbox.activate(index)
            selected_schedule_time[0] = select_time
        elif times:
            listbox.selection_set(0)
            listbox.activate(0)
            selected_schedule_time[0] = times[0]
        else:
            selected_schedule_time[0] = None

    def load_selected_weekdays(_event=None):
        selection = listbox.curselection()
        times = sorted(schedule_days)
        if not selection or selection[0] >= len(times):
            selected_schedule_time[0] = None
            return
        t = times[selection[0]]
        selected_schedule_time[0] = t
        days = set(schedule_days.get(t, []))
        syncing_weekdays[0] = True
        try:
            for code, _label in weekday_labels:
                weekday_vars[code].set(code in days)
        finally:
            syncing_weekdays[0] = False

    def weekday_changed():
        if syncing_weekdays[0]:
            return
        t = selected_schedule_time[0]
        if t is None:
            return
        schedule_days[t] = selected_days_now()
        refresh_schedule_list(t)

    for code, label in weekday_labels:
        # Native Tk checkbox displays a checkmark on Windows.
        tk.Checkbutton(
            weekday_frame, text=label, variable=weekday_vars[code],
            command=weekday_changed,
            font=tkfont.nametofont("TkDefaultFont"),
            bg="#F1F5FB", fg="#173B68",
            activebackground="#F1F5FB", activeforeground="#173B68",
            selectcolor="#FFFFFF", indicatoron=True,
            relief="flat", borderwidth=0, highlightthickness=0,
            padx=3, pady=2,
        ).pack(side="left", padx=(0, 12))
    tf = ttk.Frame(f3)
    tf.pack(fill="x")
    hour_var = tk.StringVar(value="08")
    minute_var = tk.StringVar(value="00")
    ttk.Label(tf, text="小時").pack(side="left", padx=(0, 5))
    hour_spin = tk.Spinbox(
        tf, from_=0, to=23, increment=1, wrap=True, format="%02.0f",
        textvariable=hour_var, width=4, justify="center",
        font=tkfont.nametofont("TkDefaultFont"),
    )
    hour_spin.pack(side="left")
    ttk.Label(tf, text="分").pack(side="left", padx=(12, 5))
    minute_spin = tk.Spinbox(
        tf, from_=0, to=59, increment=1, wrap=True, format="%02.0f",
        textvariable=minute_var, width=4, justify="center",
        font=tkfont.nametofont("TkDefaultFont"),
    )
    minute_spin.pack(side="left")
    listbox = tk.Listbox(f3, height=12, width=44, exportselection=False)
    listbox.pack(anchor="w", pady=8)
    refresh_schedule_list()
    listbox.bind("<<ListboxSelect>>", load_selected_weekdays)
    load_selected_weekdays()

    def parse_time(s: str):
        s = s.strip()
        m = re.fullmatch(r"(\d{1,2}):(\d{2})", s)
        if not m:
            return None
        h, mi = int(m.group(1)), int(m.group(2))
        if 0 <= h <= 23 and 0 <= mi <= 59:
            return f"{h:02d}:{mi:02d}"
        return None

    def add_time():
        t = parse_time(f"{hour_var.get()}:{minute_var.get()}")
        if not t:
            messagebox.showerror("時間格式", "請輸入 HH:MM，例如 08:00、12:30、17:45")
            return
        days = selected_days_now()
        if not days:
            messagebox.showerror("排程日期", "請先勾選此時段要執行的星期。")
            return
        schedule_days[t] = days
        refresh_schedule_list(t)

    def del_time():
        selection = listbox.curselection()
        times = sorted(schedule_days)
        if not selection or selection[0] >= len(times):
            return
        removed_time = times[selection[0]]
        schedule_days.pop(removed_time, None)
        refresh_schedule_list()
        if selected_schedule_time[0] is not None:
            load_selected_weekdays()

    ttk.Button(tf, text="新增／更新時段", command=add_time, style="Primary.TButton").pack(side="left", padx=8)
    ttk.Button(tf, text="刪除選取", command=del_time).pack(side="left")

    # 詳細 LOG 頁
    f4 = ttk.Frame(nb, padding=14, style="Card.TFrame")
    nb.add(f4, text="LOG")
    ttk.Label(f4, text="詳細 LOG", style="PageTitle.TLabel").pack(anchor="w", padx=4, pady=(0, 8))
    log_frame = ttk.Frame(f4)
    log_frame.pack(fill="both", expand=True)
    log_font = tkfont.Font(root=root, family="Microsoft JhengHei UI", size=10)
    # A tall fixed log widget reserves space even on other tabs and pushes the
    # bottom actions below the fold. Keep its requested height compact; the log
    # remains scrollable and the main canvas still scrolls on short screens.
    log_widget = tk.Text(
        log_frame, wrap="word", height=8,
        font=log_font, undo=False, bg="#FBFCFE", fg="#24364B",
        insertbackground="#173B68", selectbackground="#BBD4F0",
        relief="flat", padx=12, pady=10,
    )
    log_scroll = ttk.Scrollbar(log_frame, orient="vertical", command=log_widget.yview)
    log_widget.configure(yscrollcommand=log_scroll.set)
    log_widget.pack(side="left", fill="both", expand=True)
    log_scroll.pack(side="right", fill="y")

    # 每次排程的精簡結果，不包含病患資料或上傳明細。
    f5 = ttk.Frame(nb, padding=14, style="Card.TFrame")
    nb.add(f5, text="每日執行紀錄")
    ttk.Label(f5, text="每日執行紀錄", style="PageTitle.TLabel").pack(anchor="w", padx=4, pady=(0, 8))
    daily_frame = ttk.Frame(f5)
    daily_frame.pack(fill="both", expand=True)
    daily_widget = tk.Text(
        daily_frame, wrap="word", height=8, font=log_font, undo=False,
        bg="#FBFCFE", fg="#24364B", insertbackground="#173B68",
        selectbackground="#BBD4F0", relief="flat", padx=12, pady=10,
    )
    daily_scroll = ttk.Scrollbar(daily_frame, orient="vertical", command=daily_widget.yview)
    daily_widget.configure(yscrollcommand=daily_scroll.set)
    daily_widget.pack(side="left", fill="both", expand=True)
    daily_scroll.pack(side="right", fill="y")

    def refresh_daily_runs(_event=None):
        try:
            content = DAILY_RUN_LOG.read_text(encoding="utf-8") if DAILY_RUN_LOG.exists() else "尚無每日執行紀錄。"
            daily_widget.configure(state="normal")
            daily_widget.delete("1.0", "end")
            daily_widget.insert("end", content)
            daily_widget.see("end")
            daily_widget.configure(state="disabled")
        except Exception as exc:
            daily_widget.configure(state="normal")
            daily_widget.delete("1.0", "end")
            daily_widget.insert("end", f"讀取每日執行紀錄失敗：{exc}")
            daily_widget.configure(state="disabled")

    nb.bind("<<NotebookTabChanged>>", lambda event: refresh_daily_runs() if nb.select() == str(f5) else None)
    refresh_daily_runs()

    def flush_ui_logs():
        if log_widget is None:
            return
        lines = []
        for _ in range(400):
            try:
                kind, payload = ui_log_queue.get_nowait()
            except queue.Empty:
                break
            if kind == "log":
                lines.append(payload)
            elif kind == "activity":
                activity_var.set(payload)
            elif kind == "complete":
                # 成功結果不再跳出需手動確認的視窗；完成時間與耗時已寫入每日執行紀錄。
                refresh_daily_runs()
                nb.select(f5)
                status_var.set("完成")
                activity_var.set("本次循環已完成，等待下一個每日排程時間")
            elif kind == "failed":
                messagebox.showerror("執行失敗", payload)
                status_var.set("失敗")
                activity_var.set("自動化程序失敗，請查看『LOG』")
            elif kind == "update_available":
                manifest = payload
                version = str(manifest.get("version") or "")
                notes = str(manifest.get("notes") or "").strip()
                prompt = f"發現新版 v{version}。\n\n現在下載並更新嗎？"
                if notes:
                    prompt += f"\n\n更新內容：{notes[:500]}"
                if messagebox.askyesno("PHIS 更新", prompt):
                    start_update(manifest)
                else:
                    logger.write(f"新版 v{version} 暫不安裝。")
            elif kind == "update_none":
                if payload:
                    messagebox.showinfo("檢查更新", "目前已是最新版本。")
            elif kind == "update_error":
                messagebox.showerror("檢查更新失敗", str(payload))
            elif kind == "update_started":
                activity_var.set("更新程序已啟動，完成後會重新開啟本程式。")
                root.after(100, root.destroy)
            elif kind == "update_failed":
                messagebox.showerror("更新失敗", str(payload))
            elif kind == "worker_done":
                nonlocal_workflow_active[0] = False
                run_btn.config(state="normal")
        if lines:
            log_widget.insert("end", "\n".join(lines) + "\n")
            # Bound the visible log to keep scrolling and redraw fast. Full logs
            # remain available in the daily file under the logs folder.
            end_line = int(log_widget.index("end-1c").split(".")[0])
            if end_line > 3001:
                log_widget.delete("1.0", f"{end_line - 3000}.0")
            log_widget.see("end")
        try:
            root.after(100, flush_ui_logs)
        except tk.TclError:
            pass

    root.after(100, flush_ui_logs)

    update_button = [None]

    def check_updates(manual=False):
        def worker():
            try:
                manifest = fetch_update_manifest()
                latest = str(manifest.get("version") or "")
                if version_tuple(latest) > version_tuple(APP_VERSION):
                    post_ui("update_available", manifest)
                else:
                    logger.write("更新檢查完成：目前已是最新版本。")
                    post_ui("update_none", bool(manual))
            except Exception as e:
                logger.write(f"更新檢查失敗：{e}")
                if manual:
                    post_ui("update_error", str(e))
        threading.Thread(target=worker, daemon=True).start()

    def start_update(manifest):
        if nonlocal_workflow_active[0]:
            messagebox.showwarning("流程執行中", "請等待 PHIS 流程完成後再更新。")
            return
        if update_button[0] is not None:
            update_button[0].configure(state="disabled")

        def worker():
            try:
                archive = download_update_package(manifest, logger)
                updater = BASE_DIR / "apply_update.py"
                if not updater.is_file():
                    raise RuntimeError("缺少安全更新程式 apply_update.py。")
                flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
                subprocess.Popen(
                    [sys.executable, str(updater), "--pid", str(os.getpid()),
                     "--archive", str(archive), "--target", str(BASE_DIR)],
                    cwd=str(BASE_DIR), creationflags=flags,
                    close_fds=True,
                )
                logger.write("已啟動安全更新程序；更新完成後會重新開啟本工具。")
                post_ui("update_started")
            except Exception as e:
                logger.write(f"下載或啟動更新失敗：{e}")
                post_ui("update_failed", str(e))
                if update_button[0] is not None:
                    try:
                        root.after(0, lambda: update_button[0].configure(state="normal"))
                    except tk.TclError:
                        pass
        threading.Thread(target=worker, daemon=True).start()

    root.after(1600, lambda: check_updates(manual=False))

    def collect_settings():
        raw_url = (url_var.get() or "").strip().replace("\u200b", "") or DEFAULT_URL
        candidate = raw_url if "://" in raw_url else "http://" + raw_url
        parsed_url = urlparse(candidate)
        if parsed_url.scheme not in ("http", "https") or not parsed_url.hostname:
            messagebox.showerror("網址格式錯誤", "請輸入有效的 PHIS 網址，例如 http://192.168.1.2/phis2000/")
            return False
        settings.url = parsed_url.geturl()
        url_var.set(settings.url)
        settings.username = user_var.get().strip()
        settings.password = pass_var.get()
        settings.display_name = display_name_var.get().strip()
        settings.permission_level = permission_var.get().strip() or "5"
        try:
            settings.server_retry_seconds = max(1.0, float(retry_var.get().strip()))
        except Exception:
            settings.server_retry_seconds = 2.0
        settings.auto_close_native = True
        settings.times = sorted(schedule_days)
        settings.schedule_days = {
            t: [code for code, _label in weekday_labels if code in schedule_days.get(t, [])]
            for t in settings.times
        }
        settings.weekdays = [
            code for code, _label in weekday_labels
            if any(code in settings.schedule_days[t] for t in settings.times)
        ]
        empty_times = [t for t in settings.times if not settings.schedule_days[t]]
        if empty_times:
            messagebox.showerror(
                "排程日期",
                "以下時段尚未勾選執行星期：" + ", ".join(empty_times),
            )
            return False
        return True

    def save_only(show=True):
        if not collect_settings():
            return
        settings.save()
        logger.write("設定已儲存。")
        if show:
            messagebox.showinfo("完成", "設定已儲存。")

    def save_and_schedule():
        if not collect_settings():
            return
        if settings.times:
            choice = messagebox.askyesnocancel(
                "排程執行權限",
                "請先設定下次及之後排程的執行權限：\n\n"
                "是：以系統管理員（最高）權限執行\n"
                "否：以目前使用者的一般權限執行\n"
                "取消：不變更排程\n\n"
                "排程只會在此 Windows 使用者登入時執行。",
            )
            if choice is None:
                return
            settings.run_as_admin = bool(choice)
        settings.save()
        try:
            TaskScheduler(logger).sync(settings.schedule_days, settings.run_as_admin)
            messagebox.showinfo("完成", "設定與每週排程已同步完成。")
        except Exception as e:
            messagebox.showerror("排程失敗", str(e))

    sf = ttk.Frame(f3); sf.pack(anchor="w", pady=8)
    ttk.Button(sf, text="同步排程", command=save_and_schedule, style="Primary.TButton").pack(side="left")
    ttk.Button(sf, text="只儲存", command=lambda: save_only(True)).pack(side="left", padx=8)

    nonlocal_workflow_active = [False]
    tray_icon = [None]
    tray_icon_module = [None]

    def restore_from_tray(_icon=None, _item=None):
        def show():
            try:
                root.deiconify()
                root.state("normal")
                root.lift()
            except tk.TclError:
                pass
        try:
            root.after(0, show)
        except tk.TclError:
            pass

    def minimize_to_tray(_event=None):
        # Only intercept a real minimize; withdraw/restore events are ignored.
        try:
            if root.state() != "iconic":
                return
            if tray_icon[0] is None:
                try:
                    import pystray
                    from PIL import Image, ImageDraw
                    icon_img = Image.new("RGBA", (64, 64), (22, 59, 102, 255))
                    draw = ImageDraw.Draw(icon_img)
                    draw.rounded_rectangle((5, 5, 59, 59), radius=12, fill=(47, 111, 237, 255))
                    draw.text((13, 20), "PH", fill="white", stroke_width=1)
                    menu = pystray.Menu(
                        pystray.MenuItem("開啟 PHIS 上傳工具", restore_from_tray, default=True),
                        pystray.MenuItem("結束程式", lambda icon, item: root.after(0, close_app)),
                    )
                    tray_icon_module[0] = pystray
                    tray_icon[0] = pystray.Icon("PHIS_AutoUploader", icon_img, APP_NAME, menu)
                    tray_icon[0].run_detached()
                except Exception as e:
                    logger.write(f"建立系統匣圖示失敗，仍保留工作列視窗：{e}")
                    return
            root.withdraw()
        except tk.TclError:
            pass

    root.bind("<Unmap>", minimize_to_tray, add="+")

    def close_app():
        if nonlocal_workflow_active[0]:
            messagebox.showwarning("流程執行中", "自動上傳流程仍在執行，請等本次流程完成後再關閉視窗。")
            return
        if tray_icon[0] is not None:
            try:
                tray_icon[0].stop()
            except Exception:
                pass
        root.destroy()

    root.protocol("WM_DELETE_WINDOW", close_app)

    def do_run():
        if not collect_settings():
            return
        settings.save()
        if not settings.username or not settings.password:
            messagebox.showerror("缺少資料", "請先填寫登入帳號與密碼。")
            return
        if not settings.display_name:
            messagebox.showerror("缺少資料", "請填寫『PHIS 使用者姓名』；官方 InetLoader 啟動參數需要此欄位。")
            return
        run_btn.config(state="disabled")
        nonlocal_workflow_active[0] = True
        status_var.set("執行中…")
        activity_var.set("正在執行自動化健保卡上傳程序")
        nb.select(f4)

        def set_activity(text):
            post_ui("activity", text)

        def worker():
            started_at = datetime.now()
            started_clock = time.monotonic()
            recorder = DailyRunRecorder()
            try:
                run_workflow(settings, logger, status_callback=set_activity, show_overlay=False)
                elapsed = time.monotonic() - started_clock
                try:
                    recorder.write(started_at, "成功", elapsed, "手動流程完成")
                except Exception as log_error:
                    logger.write(f"每日執行紀錄寫入失敗：{log_error}")
                post_ui("complete", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
            except Exception as e:
                elapsed = time.monotonic() - started_clock
                try:
                    recorder.write(started_at, "失敗", elapsed, f"手動流程失敗（{type(e).__name__}）")
                except Exception as log_error:
                    logger.write(f"每日執行紀錄寫入失敗：{log_error}")
                post_ui("failed", str(e))
            finally:
                post_ui("worker_done")
        threading.Thread(target=worker, daemon=True).start()

    run_btn.config(command=do_run)

    bottom = ttk.Frame(main_frame)
    bottom.pack(fill="x", padx=10, pady=(0,10))
    ttk.Button(bottom, text="儲存設定", command=lambda: save_only(True), style="SaveAction.TButton").pack(side="left", padx=(0, 8))
    ttk.Button(bottom, text="開啟記錄資料夾", command=lambda: os.startfile(LOG_DIR), style="LogAction.TButton").pack(side="left", padx=8)
    update_button[0] = ttk.Button(bottom, text="檢查更新", command=lambda: check_updates(manual=True), style="UpdateAction.TButton")
    update_button[0].pack(side="left", padx=8)
    ttk.Button(bottom, text="關閉", command=close_app, style="CloseAction.TButton").pack(side="right", padx=4)

    # Scale fonts with the window and reflow help text to the available width.
    # Debouncing keeps resize handling light while the border is being dragged.
    named_fonts = []
    for font_name in ("TkDefaultFont", "TkTextFont", "TkMenuFont", "TkHeadingFont"):
        try:
            font_obj = tkfont.nametofont(font_name)
            named_fonts.append((font_obj, abs(int(font_obj.cget("size")))))
        except tk.TclError:
            pass
    wrap_targets = ((info_label, f1), (steps_label, f2), (schedule_info, f3))
    resize_job = [None]

    def resize_ui(_event=None):
        if resize_job[0] is not None:
            try:
                root.after_cancel(resize_job[0])
            except tk.TclError:
                pass

        def apply_resize():
            resize_job[0] = None
            width = max(1, root.winfo_width())
            height = max(1, root.winfo_height())
            scale = min(width / 920.0, height / 720.0)
            scale = max(0.88, min(scale, 1.35))
            # Tk fonts already scale with Windows DPI. Applying the DPI factor
            # again caused oversized labels and clipped URL text at high scale.
            font_scale = scale
            for font_obj, base_size in named_fonts:
                font_obj.configure(
                    family="Microsoft JhengHei UI",
                    size=max(11, round(base_size * font_scale)),
                )
            activity_font.configure(size=max(14, round(17 * font_scale)))
            action_font.configure(size=max(12, round(12 * font_scale)))
            brand_title.configure(font=("Microsoft JhengHei UI", max(17, round(19 * font_scale)), "bold"))
            page_title_font.configure(size=max(15, round(17 * font_scale)))
            tab_font.configure(size=max(12, round(12 * font_scale)))
            activity_banner.configure(wraplength=max(360, width - 80))
            log_font.configure(size=max(10, round(12 * font_scale)))
            style.configure(
                "TNotebook.Tab",
                padding=(max(14, round(14 * scale)), max(9, round(9 * scale))),
            )
            style.configure(
                "Action.TButton",
                padding=(max(12, round(14 * scale)), max(8, round(9 * scale))),
            )
            button_padding = (max(12, round(14 * scale)), max(8, round(9 * scale)))
            for stylename in ("SaveAction.TButton", "LogAction.TButton", "UpdateAction.TButton", "CloseAction.TButton"):
                style.configure(stylename, padding=button_padding)
            for label, parent in wrap_targets:
                label.configure(wraplength=max(300, parent.winfo_width() - 40))

        try:
            resize_job[0] = root.after(120, apply_resize)
        except tk.TclError:
            pass

    root.bind("<Configure>", resize_ui, add="+")
    root.after(150, resize_ui)

    def scroll_page(event):
        try:
            widget = root.winfo_containing(event.x_root, event.y_root)
            if log_widget is not None and widget is not None:
                wpath, logpath = str(widget), str(log_widget)
                if wpath == logpath or wpath.startswith(logpath + "."):
                    return None
            if event.delta:
                canvas.yview_scroll(-1 * int(event.delta / 120), "units")
                return "break"
        except tk.TclError:
            pass
        return None

    root.bind_all("<MouseWheel>", scroll_page, add="+")

    root.mainloop()



def _is_running_as_admin() -> bool:
    if os.name != "nt":
        return True
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def _relaunch_as_admin() -> bool:
    """Relaunch this exact Python/script command through UAC and exit caller.

    The uploader is a legacy Win32/Delphi application.  If InetLoader launches
    it at a higher integrity level, lower-integrity SendMessage/SendInput calls
    can be blocked by UIPI even though HWND discovery still works.  Elevating the
    automation process once at startup avoids that integrity mismatch for all
    later scheduled runs.
    """
    if os.name != "nt" or _is_running_as_admin():
        return True

    try:
        shell32 = ctypes.windll.shell32
        script = os.path.abspath(sys.argv[0])
        params = subprocess.list2cmdline([script] + sys.argv[1:])
        workdir = str(BASE_DIR)
        rc = shell32.ShellExecuteW(
            None,
            "runas",
            sys.executable,
            params,
            workdir,
            1,  # SW_SHOWNORMAL
        )
        if int(rc) > 32:
            return False  # elevated copy launched; current process should exit

        try:
            ctypes.windll.user32.MessageBoxW(
                None,
                "無法取得系統管理員權限。\n\n"
                "IC卡資料上傳程式可能以較高權限執行，若自動化工具權限較低，"
                "Windows UIPI 會阻擋 WM_SYSCHAR / SendInput。\n\n"
                "請允許 UAC 後再試。",
                "PHIS 自動上傳工具",
                0x10,
            )
        except Exception:
            pass
        return None
    except Exception as e:
        try:
            ctypes.windll.user32.MessageBoxW(
                None,
                f"自動提權失敗：{e}",
                "PHIS 自動上傳工具",
                0x10,
            )
        except Exception:
            pass
        return None

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-once", action="store_true", help="依目前設定執行一次完整流程")
    args = parser.parse_args()
    settings = Settings()
    logger = Logger()
    if args.run_once:
        started_at = datetime.now()
        started_clock = time.monotonic()
        recorder = DailyRunRecorder()
        try:
            logger.write(
                f"v{APP_VERSION} 排程啟動；目前權限："
                f"{'系統管理員' if _is_running_as_admin() else '一般使用者'}。"
            )
            run_workflow(settings, logger)
            elapsed = time.monotonic() - started_clock
            recorder.write(started_at, "成功", elapsed, "排程流程完成")
            logger.write(f"排程結果已寫入每日執行紀錄；耗時 {elapsed:.1f} 秒。")
            return 0
        except Exception as exc:
            logger.write(f"排程流程失敗：{exc}")
            elapsed = time.monotonic() - started_clock
            recorder.write(started_at, "失敗", elapsed, f"錯誤類型：{type(exc).__name__}")
            return 1
    # Interactive GUI retains the historical UAC elevation for native PHIS UI.
    elevation = _relaunch_as_admin()
    if elevation is False:
        return 0
    if elevation is None:
        return 1
    logger.write(f"v{APP_VERSION} 權限狀態：自動化工具目前以系統管理員權限執行。")
    launch_gui()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
