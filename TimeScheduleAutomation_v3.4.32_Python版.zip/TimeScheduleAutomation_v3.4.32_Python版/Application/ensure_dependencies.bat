@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" goto create_environment
".venv\Scripts\python.exe" -c "import sys; raise SystemExit(0 if sys.version_info >= (3,12) else 1)" >nul 2>nul
if not errorlevel 1 goto check_packages
echo [REPAIR] The private Python environment is incomplete or too old. Rebuilding it...
rmdir /s /q ".venv"
if exist ".venv" goto environment_failed
:create_environment
echo [SETUP] Checking the default Python runtime...
where py >nul 2>nul
if errorlevel 1 goto use_python
py -c "import sys; raise SystemExit(0 if sys.version_info >= (3,12) else 1)"
if not errorlevel 1 goto create_with_py
echo [SETUP] No compatible runtime found. Installing the Python install manager default (latest stable)...
py install default
if errorlevel 1 goto use_manager
py -c "import sys; raise SystemExit(0 if sys.version_info >= (3,12) else 1)"
if errorlevel 1 goto use_manager
goto create_with_py
:create_with_py
py -m venv .venv
if errorlevel 1 goto environment_failed
goto verify_environment
:use_python
where python >nul 2>nul
if errorlevel 1 goto use_manager
python -c "import sys; raise SystemExit(0 if sys.version_info >= (3,12) else 1)" >nul 2>nul
if not errorlevel 1 goto create_with_python
:use_manager
where pymanager >nul 2>nul
if errorlevel 1 goto python_missing
echo [SETUP] Using Python install manager to install its default latest runtime...
pymanager exec -c "import sys; raise SystemExit(0 if sys.version_info >= (3,12) else 1)"
if not errorlevel 1 goto create_with_manager
pymanager install default
if errorlevel 1 goto python_install_failed
pymanager exec -c "import sys; raise SystemExit(0 if sys.version_info >= (3,12) else 1)"
if errorlevel 1 goto python_install_failed
:create_with_manager
pymanager exec -m venv .venv
if errorlevel 1 goto environment_failed
goto verify_environment
:create_with_python
python -m venv .venv
if errorlevel 1 goto environment_failed
:verify_environment
if not exist ".venv\Scripts\python.exe" goto environment_failed
".venv\Scripts\python.exe" -c "import sys; raise SystemExit(0 if sys.version_info >= (3,12) else 1)" >nul 2>nul
if errorlevel 1 goto version_wrong
:check_packages
echo [CHECK] Checking required packages...
".venv\Scripts\python.exe" -c "import pywinauto, pyautogui, pyperclip, PIL, win32api, pystray" >nul 2>nul
if not errorlevel 1 goto dependencies_ready
echo [SETUP] Installing missing packages. Internet access is required.
".venv\Scripts\python.exe" -m ensurepip --upgrade >nul 2>nul
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check --no-cache-dir --prefer-binary --timeout 20 --retries 2 -r requirements.txt
if errorlevel 1 goto package_failed
".venv\Scripts\python.exe" -c "import pywinauto, pyautogui, pyperclip, PIL, win32api, pystray"
if errorlevel 1 goto verify_failed
:dependencies_ready
echo [OK] Required packages are ready.
exit /b 0
:python_missing
echo [ERROR] Python 3.12 or later and a Python install manager were not found.
echo Install Python 3.12 or later, then run this launcher again.
exit /b 1
:python_install_failed
echo [ERROR] Could not install or start the latest compatible Python runtime.
echo Check Internet access and the Python install manager, then retry.
exit /b 1
:environment_failed
echo [ERROR] Could not create or repair the private Python environment.
exit /b 1
:version_wrong
echo [ERROR] The private Python environment is still below version 3.12.
echo Python launcher locations and versions:
where py
py --version
py list
where python
python --version
exit /b 1
:package_failed
echo [ERROR] Package installation failed. Check Internet access and PyPI availability.
exit /b 1
:verify_failed
echo [ERROR] Package verification failed after installation.
exit /b 1
