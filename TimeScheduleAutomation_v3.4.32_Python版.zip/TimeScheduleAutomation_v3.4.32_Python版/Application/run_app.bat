@echo off
setlocal EnableExtensions
cd /d "%~dp0"
call "%~dp0setup_and_run.bat"
exit /b %errorlevel%
