@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title TimeScheduleAutomation v3.4.32
call "%~dp0ensure_dependencies.bat"
if errorlevel 1 goto setup_failed
if not exist ".venv\Scripts\pythonw.exe" goto pythonw_missing
echo [START] Opening the TimeScheduleAutomation...
start "" ".venv\Scripts\pythonw.exe" "phis_auto.py"
if errorlevel 1 goto launch_failed
exit /b 0
:setup_failed
echo.
echo [ERROR] Setup could not finish. Review the message above, then install Python 3.12 or later and check Internet access.
pause
exit /b 1
:pythonw_missing
echo [ERROR] pythonw.exe is missing from the private Python environment.
pause
exit /b 1
:launch_failed
echo [ERROR] Could not start the application.
pause
exit /b 1
