@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
echo ==============================================
echo   TimeScheduleAutomation - 完全修復自動化環境
echo ==============================================
echo.
echo 此動作只會重建 .venv，自動保留 settings.json、帳號、密碼與排程設定。
echo.
if exist ".venv" (
  echo [1/4] 刪除舊的 .venv ...
  rmdir /s /q ".venv"
)
echo [2/4] 建立新的 .venv ...
where py >nul 2>nul
if not errorlevel 1 (
  py -3 -m venv .venv
) else (
  where python >nul 2>nul
  if errorlevel 1 (
    echo [錯誤] 找不到 Python 3。
    pause
    exit /b 1
  )
  python -m venv .venv
)
if errorlevel 1 goto :fail

echo [3/4] 安裝自動化元件...
".venv\Scripts\python.exe" -m ensurepip --upgrade
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check --prefer-binary --timeout 20 --retries 2 -r requirements.txt
if errorlevel 1 goto :fail

echo [4/4] 驗證...
".venv\Scripts\python.exe" -c "import pywinauto, pyautogui, pyperclip, PIL, win32api, pystray; print('OK - 自動化元件載入成功')"
if errorlevel 1 goto :fail

echo.
echo ==============================================
echo 修復完成。現在可直接執行 run_app.bat
 echo ==============================================
pause
exit /b 0

:fail
echo.
echo [錯誤] 完全修復失敗。請把本視窗最後 20 行截圖傳給 ChatGPT。
pause
exit /b 1
