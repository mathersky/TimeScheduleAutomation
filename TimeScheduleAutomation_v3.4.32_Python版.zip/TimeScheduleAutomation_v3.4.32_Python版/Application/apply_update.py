# -*- coding: utf-8 -*-
"""Verify an update bundle's layout, replace app files, then restart Python app."""
from __future__ import annotations
import argparse
import ctypes
import os
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import tempfile
import zipfile
from ctypes import wintypes

MAX_UNPACKED = 120 * 1024 * 1024


def wait_for_process(pid: int, timeout_ms: int = 90000) -> None:
    if os.name != "nt":
        raise RuntimeError("更新程序僅支援 Windows。")
    kernel32 = ctypes.windll.kernel32
    kernel32.OpenProcess.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
    kernel32.OpenProcess.restype = wintypes.HANDLE
    kernel32.WaitForSingleObject.argtypes = (wintypes.HANDLE, wintypes.DWORD)
    kernel32.WaitForSingleObject.restype = wintypes.DWORD
    kernel32.CloseHandle.argtypes = (wintypes.HANDLE,)
    kernel32.CloseHandle.restype = wintypes.BOOL
    handle = kernel32.OpenProcess(0x00100000, False, int(pid))  # SYNCHRONIZE
    if not handle:
        return
    try:
        result = kernel32.WaitForSingleObject(handle, timeout_ms)
        if result == 0x00000102:
            raise TimeoutError("等待主程式關閉逾時；更新未套用。")
    finally:
        kernel32.CloseHandle(handle)


def safe_extract(archive: Path, stage: Path) -> Path:
    with zipfile.ZipFile(archive) as bundle:
        entries = bundle.infolist()
        total = sum(item.file_size for item in entries)
        if not entries or total > MAX_UNPACKED:
            raise RuntimeError("更新包為空或解壓大小超過限制。")
        roots = set()
        files = []
        for item in entries:
            raw = item.filename.replace("\\", "/")
            rel = PurePosixPath(raw)
            if rel.is_absolute() or ".." in rel.parts or not rel.parts:
                raise RuntimeError("更新包含有不安全的檔案路徑。")
            roots.add(rel.parts[0])
            if not item.is_dir():
                files.append((item, rel))
        if len(roots) != 1:
            raise RuntimeError("更新包資料夾結構不符。")
        root_name = next(iter(roots))
        if not root_name.startswith("TimeScheduleAutomation_v"):
            raise RuntimeError("更新包產品名稱不符。")
        for item, rel in files:
            destination = stage.joinpath(*rel.parts)
            destination.parent.mkdir(parents=True, exist_ok=True)
            with bundle.open(item) as src, destination.open("wb") as dst:
                shutil.copyfileobj(src, dst)
        app_root = stage / root_name
        required = ("phis_auto.py", "apply_update.py", "run_app.bat", "requirements.txt")
        if any(not (app_root / name).is_file() for name in required):
            raise RuntimeError("更新包缺少必要程式檔。")
        return app_root


def apply_files(source: Path, target: Path, backup: Path) -> None:
    protected = {"settings.json", "logs", ".venv", "chrome_auto_profiles"}
    candidates = [p for p in source.rglob("*") if p.is_file()]
    changed = []
    try:
        for src in candidates:
            rel = src.relative_to(source)
            if rel.parts[0] in protected:
                continue
            dst = target / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            old_copy = backup / rel
            if dst.is_file():
                old_copy.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(dst, old_copy)
            temporary = dst.with_name(dst.name + ".update-tmp")
            shutil.copy2(src, temporary)
            os.replace(temporary, dst)
            changed.append((dst, old_copy))
    except Exception:
        for dst, old_copy in reversed(changed):
            try:
                if old_copy.is_file():
                    os.replace(old_copy, dst)
                elif dst.exists():
                    dst.unlink()
            except Exception:
                pass
        raise


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pid", type=int, required=True)
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--target", type=Path, required=True)
    args = parser.parse_args()
    target = args.target.resolve()
    if not (target / "phis_auto.py").is_file():
        raise RuntimeError("找不到目前安裝目錄，已取消更新。")
    wait_for_process(args.pid)
    with tempfile.TemporaryDirectory(prefix="phis-auto-update-") as temp:
        temp_path = Path(temp)
        source = safe_extract(args.archive, temp_path / "stage")
        apply_files(source, target, temp_path / "backup")
    launcher = target / "run_app.bat"
    subprocess.Popen(
        ["cmd.exe", "/c", str(launcher)], cwd=str(target),
        creationflags=getattr(subprocess, "CREATE_NEW_CONSOLE", 0), close_fds=True,
    )
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        try:
            ctypes.windll.user32.MessageBoxW(None, f"更新未完成：\n{exc}", "TimeScheduleAutomation", 0x10)
        except Exception:
            sys.stderr.write(f"更新未完成：{exc}\n")
        raise SystemExit(1)
