@echo off
setlocal EnableExtensions
cd /d "%~dp0"
call "%~dp0ensure_dependencies.bat"
if errorlevel 1 exit /b 1
"%~dp0.venv\Scripts\python.exe" "%~dp0phis_auto.py" --run-once %*
exit /b %errorlevel%
